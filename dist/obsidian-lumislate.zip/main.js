"use strict";var si=Object.create;var ce=Object.defineProperty,ri=Object.defineProperties,li=Object.getOwnPropertyDescriptor,ci=Object.getOwnPropertyDescriptors,di=Object.getOwnPropertyNames,Se=Object.getOwnPropertySymbols,mi=Object.getPrototypeOf,_e=Object.prototype.hasOwnProperty,rt=Object.prototype.propertyIsEnumerable;var lt=Math.pow,st=(i,a,e)=>a in i?ce(i,a,{enumerable:!0,configurable:!0,writable:!0,value:e}):i[a]=e,U=(i,a)=>{for(var e in a||(a={}))_e.call(a,e)&&st(i,e,a[e]);if(Se)for(var e of Se(a))rt.call(a,e)&&st(i,e,a[e]);return i},Q=(i,a)=>ri(i,ci(a));var ct=(i,a)=>{var e={};for(var t in i)_e.call(i,t)&&a.indexOf(t)<0&&(e[t]=i[t]);if(i!=null&&Se)for(var t of Se(i))a.indexOf(t)<0&&rt.call(i,t)&&(e[t]=i[t]);return e};var ui=(i,a)=>{for(var e in a)ce(i,e,{get:a[e],enumerable:!0})},dt=(i,a,e,t)=>{if(a&&typeof a=="object"||typeof a=="function")for(let n of di(a))!_e.call(i,n)&&n!==e&&ce(i,n,{get:()=>a[n],enumerable:!(t=li(a,n))||t.enumerable});return i};var pi=(i,a,e)=>(e=i!=null?si(mi(i)):{},dt(a||!i||!i.__esModule?ce(e,"default",{value:i,enumerable:!0}):e,i)),gi=i=>dt(ce({},"__esModule",{value:!0}),i);var x=(i,a,e)=>new Promise((t,n)=>{var o=l=>{try{r(e.next(l))}catch(c){n(c)}},s=l=>{try{r(e.throw(l))}catch(c){n(c)}},r=l=>l.done?t(l.value):Promise.resolve(l.value).then(o,s);r((e=e.apply(i,a)).next())});var oa={};ui(oa,{LUMISLATE_VIEW_TYPE:()=>ie,LumiSlateView:()=>xe,SLIDE_LAYOUTS:()=>ze,default:()=>Oe});module.exports=gi(oa);var y=require("obsidian");var ke=class{constructor(a,e){this.app=a;this.cacheDir=`${e}/cache`}ensureCacheDir(){return x(this,null,function*(){let a=this.app.vault.adapter;(yield a.exists(this.cacheDir))||(yield a.mkdir(this.cacheDir))})}getCacheFilePath(a){let e=a.replace(/[\\/]/g,"_").replace(/\.md$/i,"");return`${this.cacheDir}/${e}.html`}generateHash(a,e=""){let t=a+"|"+e,n=2166136261;for(let o=0;o<t.length;o++)n^=t.charCodeAt(o),n+=(n<<1)+(n<<4)+(n<<7)+(n<<8)+(n<<24);return(n>>>0).toString(16).padStart(8,"0")}parseCacheHeader(a){let e=a.match(/<!--\s*LUMISLATE-CACHE\s*\n([\s\S]*?)\n\s*-->/);if(!e)return{metadata:null,body:a};let t={},n=e[1].split(`
`);for(let s of n){let r=s.indexOf(":");if(r>0){let l=s.slice(0,r).trim(),c=s.slice(r+1).trim();t[l]=c}}let o=a.slice(e[0].length).trimStart();return{metadata:t,body:o}}buildCacheHeader(a){return`<!-- LUMISLATE-CACHE
hash: ${a.hash}
theme: ${a.theme}
prompt: ${a.prompt}
created: ${a.created}
-->`}extractFrontmatterValue(a,e){let t=new RegExp(`^${e}:\\s*(.*)$`,"m"),n=a.match(t);return n?n[1].trim().replace(/^["']|["']$/g,""):""}readCache(a,e,t=""){return x(this,null,function*(){let n=this.getCacheFilePath(a),o=this.app.vault.adapter;if(!(yield o.exists(n)))return null;let s=yield o.read(n),{metadata:r,body:l}=this.parseCacheHeader(s);if(!r)return null;let c=this.generateHash(e,t);return r.hash!==c?null:l})}writeCache(a,e,t,n="",o=""){return x(this,null,function*(){yield this.ensureCacheDir();let r={hash:this.generateHash(t,o),theme:n,prompt:o,created:new Date().toISOString()},c=`${this.buildCacheHeader(r)}
${e}`,d=this.getCacheFilePath(a);yield this.app.vault.adapter.write(d,c)})}updateCacheText(a,e,t,n,o=""){return x(this,null,function*(){let s=this.getCacheFilePath(a),r=this.app.vault.adapter;if(!(yield r.exists(s)))return;let l=yield r.read(s),{metadata:c,body:d}=this.parseCacheHeader(l);if(!c)return;let u=d.replace(e,t);if(u===d)return;let g=this.generateHash(n,o),m=Q(U({},c),{hash:g,created:new Date().toISOString()}),b=this.buildCacheHeader(m);yield r.write(s,`${b}
${u}`)})}clearCache(a){return x(this,null,function*(){let e=this.app.vault.adapter;if(a){let t=this.getCacheFilePath(a);(yield e.exists(t))&&(yield e.remove(t))}else if(yield e.exists(this.cacheDir)){let t=yield e.list(this.cacheDir);for(let n of t.files)n.endsWith(".html")&&(yield e.remove(n))}})}getCacheDir(){return this.cacheDir}};var ut=require("child_process"),Ee=require("fs"),pt=require("os"),M=pi(require("path"));var Z={id:"default",label:"Default (CLI config)"},gt=[{id:"claude",label:"Claude Code",bin:"claude",fallbackBins:["openclaude"],envOverride:"CLAUDE_BIN",vendor:"Anthropic",fallbackModels:[Z,{id:"sonnet",label:"Sonnet (alias)"},{id:"opus",label:"Opus (alias)"},{id:"haiku",label:"Haiku (alias)"},{id:"claude-opus-4-7",label:"claude-opus-4-7"},{id:"claude-sonnet-4-6",label:"claude-sonnet-4-6"},{id:"claude-haiku-4-5",label:"claude-haiku-4-5"}]},{id:"codex",label:"OpenAI Codex",bin:"codex",envOverride:"CODEX_BIN",vendor:"OpenAI",fallbackModels:[Z,{id:"gpt-5.5",label:"gpt-5.5"},{id:"gpt-5.4",label:"gpt-5.4"},{id:"gpt-5.4-mini",label:"gpt-5.4-mini"},{id:"gpt-5.3-codex",label:"gpt-5.3-codex"},{id:"gpt-5-codex",label:"gpt-5-codex"},{id:"gpt-5",label:"gpt-5"},{id:"o3",label:"o3"},{id:"o4-mini",label:"o4-mini"}]},{id:"gemini",label:"Gemini CLI",bin:"gemini",envOverride:"GEMINI_BIN",vendor:"Google",fallbackModels:[Z,{id:"gemini-2.5-pro",label:"gemini-2.5-pro"},{id:"gemini-2.5-flash",label:"gemini-2.5-flash"}]},{id:"cursor-agent",label:"Cursor Agent",bin:"cursor-agent",envOverride:"CURSOR_AGENT_BIN",vendor:"Cursor",fallbackModels:[Z,{id:"auto",label:"auto"},{id:"sonnet-4",label:"sonnet-4"},{id:"sonnet-4-thinking",label:"sonnet-4-thinking"},{id:"gpt-5",label:"gpt-5"}]},{id:"deepseek",label:"DeepSeek TUI",bin:"deepseek",envOverride:"DEEPSEEK_BIN",vendor:"DeepSeek",protocol:"argv",fallbackModels:[Z,{id:"deepseek-v4-pro",label:"deepseek-v4-pro"},{id:"deepseek-v4-flash",label:"deepseek-v4-flash"}]},{id:"aider",label:"Aider",bin:"aider",vendor:"Aider",fallbackModels:[Z,{id:"claude-sonnet-4-5",label:"claude-sonnet-4-5"},{id:"gpt-5",label:"gpt-5"},{id:"deepseek/deepseek-chat",label:"deepseek/deepseek-chat"}]},{id:"opencode",label:"OpenCode",bin:"opencode-cli",fallbackBins:["opencode"],envOverride:"OPENCODE_BIN",vendor:"Open",fallbackModels:[Z,{id:"anthropic/claude-sonnet-4-5",label:"anthropic/claude-sonnet-4-5"},{id:"openai/gpt-5",label:"openai/gpt-5"},{id:"google/gemini-2.5-pro",label:"google/gemini-2.5-pro"}]},{id:"qwen",label:"Qwen Coder",bin:"qwen",envOverride:"QWEN_BIN",vendor:"Alibaba",fallbackModels:[Z,{id:"qwen3-coder-plus",label:"qwen3-coder-plus"},{id:"qwen3-coder-flash",label:"qwen3-coder-flash"}]},{id:"qoder",label:"Qoder CLI",bin:"qodercli",envOverride:"QODER_BIN",vendor:"Qoder",fallbackModels:[Z,{id:"lite",label:"Lite"},{id:"efficient",label:"Efficient"},{id:"auto",label:"Auto"},{id:"performance",label:"Performance"},{id:"ultimate",label:"Ultimate"}]}];function de(){return typeof process!="undefined"?process.env:{}}function Ue(){return typeof process!="undefined"?process.platform:""}function hi(){var o,s,r,l,c;let i=(0,pt.homedir)(),a=de(),e=[],t=(o=a.VP_HOME)==null?void 0:o.trim();t&&e.push((0,M.join)(t,"bin"));let n=(s=a.NPM_CONFIG_PREFIX)==null?void 0:s.trim();if(n&&e.push((0,M.join)(n,"bin"),n),e.push((0,M.join)(i,".local/bin"),(0,M.join)(i,".vite-plus/bin"),(0,M.join)(i,".opencode/bin"),(0,M.join)(i,".bun/bin"),(0,M.join)(i,".volta/bin"),(0,M.join)(i,".asdf/shims"),(0,M.join)(i,"Library/pnpm"),(0,M.join)(i,".cargo/bin"),(0,M.join)(i,".npm-global/bin"),(0,M.join)(i,".npm-packages/bin"),(0,M.join)(i,".claude/local")),Ue()==="win32"){let d=((r=a.SCOOP)==null?void 0:r.trim())||(0,M.join)(i,"scoop"),u=((l=a.SCOOP_GLOBAL)==null?void 0:l.trim())||"C:\\ProgramData\\scoop",g=(c=a.APPDATA)==null?void 0:c.trim();e.push((0,M.join)(d,"shims"),(0,M.join)(d,"apps","nodejs","current"),(0,M.join)(d,"apps","nodejs-lts","current"),(0,M.join)(u,"shims"),(0,M.join)(u,"apps","nodejs","current")),g&&e.push((0,M.join)(g,"npm"))}else e.push("/opt/homebrew/bin","/usr/local/bin");return e}function Ve(i){var o,s;let a=de(),e=Ue()==="win32"?((o=a.PATHEXT)!=null?o:".EXE;.CMD;.BAT").split(";"):[""],t=new Set,n=[...((s=a.PATH)!=null?s:"").split(M.delimiter),...hi()].filter(r=>r&&!t.has(r)&&(t.add(r),!0));for(let r of n)for(let l of e){let c=M.default.join(r,i+l);try{if((0,Ee.existsSync)(c))return c}catch(d){}}return null}var Ce=null;function Te(){return Ce||qe()}function qe(){return Ce=gt.map(i=>{var o,s;let a=(o=i.protocol)!=null?o:"stdin",e={id:i.id,label:i.label,vendor:i.vendor,protocol:a,models:i.fallbackModels},t=i.envOverride?de()[i.envOverride]:void 0;if(t&&(0,Ee.existsSync)(t))return Q(U({},e),{available:!0,path:t,resolvedBin:i.bin});let n=[i.bin,...(s=i.fallbackBins)!=null?s:[]];for(let r of n){let l=Ve(r);if(l)return Q(U({},e),{available:!0,path:l,resolvedBin:r})}return Q(U({},e),{available:!1})}),Ce}function me(i){return Te().find(a=>a.id===i)}function je(){return Te().filter(i=>i.available)}function fi(i,a){let{model:e}=a;switch(i){case"claude":return["-p","--output-format","stream-json","--verbose","--include-partial-messages","--permission-mode","bypassPermissions",...e?["--model",e]:[]];case"codex":return["exec","--json","--skip-git-repo-check","--sandbox","workspace-write","-c","sandbox_workspace_write.network_access=true",...e?["--model",e]:[]];case"cursor-agent":return["--print","--output-format","stream-json","--stream-partial-output","--force","--trust",...e?["--model",e]:[]];case"gemini":return["--output-format","stream-json","--yolo",...e?["--model",e]:[]];case"copilot":return["--allow-all-tools","--output-format","json",...e?["--model",e]:[]];case"opencode":return["run","--format","json","--dangerously-skip-permissions",...e?["--model",e]:[],"-"];case"qwen":return["--yolo",...e?["--model",e]:[],"-"];case"aider":return["--no-pretty","--no-stream","--yes-always","--message-file","-",...e?["--model",e]:[]];case"qoder":return["-p","--output-format","stream-json","--yolo",...e?["--model",e]:[]];case"deepseek":return["exec","--auto",...e?["--model",e]:[]];default:throw new Error(`unknown agent: ${i}`)}}function bi(i){let a=U({},de());return i==="gemini"&&(a.GEMINI_CLI_TRUST_WORKSPACE="true"),a}function mt(i){var e,t,n,o;if(!Array.isArray(i))return"";let a=[];for(let s of i){if(!s||s.type!=="tool_use")continue;let r=((e=s.name)!=null?e:"").toLowerCase();if(r!=="write"&&r!=="create_file"&&r!=="createfile"&&r!=="writefile"&&r!=="write_file"&&r!=="filewrite")continue;let l=s.input;if(!l||typeof l!="object")continue;let c=String((o=(n=(t=l.file_path)!=null?t:l.path)!=null?n:l.filename)!=null?o:"").toLowerCase();if(c&&!/\.(html?|htm)$/.test(c))continue;let d=typeof l.content=="string"?l.content:typeof l.text=="string"?l.text:typeof l.file_content=="string"?l.file_content:"";d&&a.push(d)}return a.join("")}function yi(i,a,e){var r,l,c,d,u,g;let t=a.trim();if(!t)return[];if(i==="aider"||i==="deepseek")return[{kind:"delta",text:t.endsWith(`
`)?t:t+`
`}];let n;try{n=JSON.parse(t)}catch(m){return[{kind:"noise"}]}if(!n||typeof n!="object")return[];let o=n,s=[];if(i==="claude"||i==="qoder"){if(o.type==="system"&&o.subtype==="init"&&(o.model&&s.push({kind:"meta",key:"model",value:o.model}),o.session_id&&s.push({kind:"meta",key:"session",value:o.session_id}),o.cwd&&s.push({kind:"meta",key:"cwd",value:o.cwd})),o.type==="stream_event"&&o.event&&typeof o.event=="object"){let m=o.event;m.type==="content_block_delta"&&((r=m.delta)==null?void 0:r.type)==="text_delta"&&typeof m.delta.text=="string"?(e.sawStreamEventText=!0,s.push({kind:"delta",text:m.delta.text})):m.type==="content_block_delta"&&((l=m.delta)==null?void 0:l.type)==="thinking_delta"&&s.push({kind:"meta",key:"thinking",value:m.delta.thinking})}if(o.type==="assistant"&&o.message&&typeof o.message=="object"){let m=o.message,b=mt(m.content);if(b&&(s.push({kind:"html",text:b}),e.sawStreamEventText=!0),!e.sawStreamEventText){let h=((c=m.content)!=null?c:[]).filter(p=>(p==null?void 0:p.type)==="text"&&typeof p.text=="string").map(p=>p.text).join("");h&&s.push({kind:"delta",text:h})}m.usage&&s.push({kind:"meta",key:"usage_partial",value:m.usage})}o.type==="result"&&(o.usage&&s.push({kind:"meta",key:"usage",value:o.usage}),typeof o.duration_ms=="number"&&s.push({kind:"meta",key:"duration_ms",value:o.duration_ms}),typeof o.total_cost_usd=="number"&&s.push({kind:"meta",key:"cost_usd",value:o.total_cost_usd}),typeof o.subtype=="string"&&s.push({kind:"meta",key:"result",value:o.subtype})),o.type==="rate_limit_event"&&o.rate_limit_info&&s.push({kind:"meta",key:"rate_limit",value:o.rate_limit_info})}if(i==="codex"){if(o.type==="item.completed"&&o.item&&typeof o.item=="object"){let m=o.item,b=(d=m.item_type)!=null?d:m.type;(b==="assistant_message"||b==="agent_message")&&typeof m.text=="string"&&s.push({kind:"delta",text:m.text})}if(o.type==="item.delta"&&typeof o.text=="string"&&s.push({kind:"delta",text:o.text}),o.msg&&typeof o.msg=="object"){let m=o.msg;m.type==="agent_message"&&typeof m.message=="string"&&s.push({kind:"delta",text:m.message})}(o.type==="task_complete"||o.type==="turn.completed")&&o.usage&&s.push({kind:"meta",key:"usage",value:o.usage})}if(i==="cursor-agent"||i==="gemini"){if(o.type==="stream_event"&&o.event&&typeof o.event=="object"){let m=o.event;((u=m.delta)==null?void 0:u.type)==="text_delta"&&typeof m.delta.text=="string"&&(e.sawStreamEventText=!0,s.push({kind:"delta",text:m.delta.text}))}if(o.type==="assistant"&&o.message&&typeof o.message=="object"){let m=o.message,b=mt(m.content);if(b&&(s.push({kind:"html",text:b}),e.sawStreamEventText=!0),!e.sawStreamEventText){let h=((g=m.content)!=null?g:[]).filter(p=>(p==null?void 0:p.type)==="text"&&typeof p.text=="string").map(p=>p.text).join("");h&&s.push({kind:"delta",text:h})}}typeof o.text=="string"&&!e.sawStreamEventText&&o.type!=="assistant"&&s.push({kind:"delta",text:o.text})}return i==="copilot"&&(typeof o.response=="string"&&s.push({kind:"delta",text:o.response}),typeof o.text=="string"&&s.push({kind:"delta",text:o.text})),(i==="opencode"||i==="qwen")&&(typeof o.text=="string"&&s.push({kind:"delta",text:o.text}),typeof o.content=="string"&&s.push({kind:"delta",text:o.content}),typeof o.message=="string"&&s.push({kind:"delta",text:o.message})),s}function vi(i){let a={};return e=>yi(i,e,a)}function xi(i,a){var t;let e=n=>{if(!n)return null;let o=n.trim();return o?/^([a-zA-Z]:[\\/]|[\\/])/.test(o)?(0,Ee.existsSync)(o)?o:null:Ve(o):null};if(a&&a.trim()){let n=e(a);return n?{kind:"ok",bin:n}:{kind:"override-missing",tried:a.trim()}}if(i.envOverride){let n=e(de()[i.envOverride]);if(n)return{kind:"ok",bin:n}}for(let n of[i.bin,...(t=i.fallbackBins)!=null?t:[]]){let o=Ve(n);if(o)return{kind:"ok",bin:o}}return{kind:"not-found"}}function ht(i,a,e,t){return x(this,null,function*(){let n=gt.find(b=>b.id===i);if(!n){e.onError(`unknown agent: ${i}`),e.onDone();return}let o=xi(n,t==null?void 0:t.binOverride);if(o.kind==="override-missing"){e.onError(`${n.label}: custom path \`${o.tried}\` does not exist.`),e.onDone();return}if(o.kind==="not-found"){e.onError(`${n.label} (\`${n.bin}\`) is not installed or not on PATH.`),e.onDone();return}let s=o.bin,r=n.protocol==="argv",l=n.protocol==="argv-message",c;try{c=fi(i,{model:t==null?void 0:t.model})}catch(b){e.onError(b instanceof Error?b.message:String(b)),e.onDone();return}r&&(c=[...c,a]),l&&(c=[...c,"--message",a]);let d=bi(i),u;try{u=(0,ut.spawn)(s,c,{cwd:typeof process!="undefined"?process.cwd():".",env:d,stdio:["pipe","pipe","pipe"],shell:Ue()==="win32"})}catch(b){e.onError(b instanceof Error?b.message:String(b)),e.onDone();return}e.onMeta("bin",s),e.onMeta("argv",c),u.stdin.on("error",()=>{});try{!r&&!l&&u.stdin.write(a,"utf8"),u.stdin.end()}catch(b){}let g=vi(i),m="";u.stdout.setEncoding("utf8"),u.stdout.on("data",b=>{m+=b;let h;for(;(h=m.indexOf(`
`))!==-1;){let p=m.slice(0,h);if(m=m.slice(h+1),!!p)for(let f of g(p))f.kind==="delta"?e.onDelta(f.text):f.kind==="html"?e.onHtml(f.text):f.kind==="meta"&&e.onMeta(f.key,f.value)}}),u.stderr.setEncoding("utf8"),u.stderr.on("data",b=>{e.onStderr(b)}),yield new Promise(b=>{var h;u.on("error",p=>{e.onError(p.message),b()}),u.on("close",()=>{if(m)for(let p of g(m))p.kind==="delta"?e.onDelta(p.text):p.kind==="html"?e.onHtml(p.text):p.kind==="meta"&&e.onMeta(p.key,p.value);e.onDone(),b()}),(h=t==null?void 0:t.signal)==null||h.addEventListener("abort",()=>{try{u.kill("SIGTERM")}catch(p){}b()},{once:!0})})})}function ft(i){return x(this,null,function*(){var a;try{let e=yield fetch(i.baseURL,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${i.apiKey}`},body:JSON.stringify({model:i.model,messages:[{role:"user",content:"hi"}],max_tokens:1})});if(e.ok)return{success:!0,message:"\u8FDE\u63A5\u6210\u529F"};let t=yield e.text().catch(()=>e.statusText);return{success:!1,message:`HTTP ${e.status}: ${t}`}}catch(e){return{success:!1,message:String((a=e==null?void 0:e.message)!=null?a:e)}}})}function Ae(i,a,e){return x(this,null,function*(){var t,n,o,s;if(a.provider==="local"&&a.agentId){let r={onDelta:e.onDelta,onHtml:(t=e.onHtml)!=null?t:(()=>{}),onMeta:(n=e.onMeta)!=null?n:(()=>{}),onStderr:(o=e.onStderr)!=null?o:(()=>{}),onError:e.onError,onDone:e.onDone};yield ht(a.agentId,i,r,{model:a.model,binOverride:a.binOverride,signal:a.signal})}else{if(!a.llmConfig){e.onError("HTTP API \u914D\u7F6E\u7F3A\u5931"),e.onDone();return}try{yield wi(i,a.llmConfig,e,a.signal)}catch(r){e.onError(String((s=r==null?void 0:r.message)!=null?s:r)),e.onDone()}}})}function wi(i,a,e,t){return x(this,null,function*(){var l,c,d,u;let n=yield fetch(a.baseURL,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${a.apiKey}`},body:JSON.stringify({model:a.model,messages:[{role:"system",content:"You are a world-class visual designer and senior frontend engineer."},{role:"user",content:i}],stream:!0,temperature:.3}),signal:t});if(!n.ok||!n.body){let g=yield n.text().catch(()=>n.statusText);throw new Error(`HTTP ${n.status}: ${g}`)}let o=n.body.getReader(),s=new TextDecoder,r="";try{for(;;){let{value:g,done:m}=yield o.read();if(m)break;r+=s.decode(g,{stream:!0});let b;for(;(b=r.indexOf(`
`))!==-1;){let h=r.slice(0,b).trim();if(r=r.slice(b+1),!h||!h.startsWith("data:"))continue;let p=h.slice(5).trim();if(p==="[DONE]"){e.onDone();return}let f;try{f=JSON.parse(p)}catch(v){continue}let w=(d=(c=(l=f.choices)==null?void 0:l[0])==null?void 0:c.delta)==null?void 0:d.content;typeof w=="string"&&e.onDelta(w)}}e.onDone()}catch(g){if((g==null?void 0:g.name)==="AbortError"){e.onDone();return}e.onError(String((u=g==null?void 0:g.message)!=null?u:g))}})}function Le(i){if(!i)return"";let a=i.match(/```(?:html|HTML)?\s*([\s\S]*?)```/);if(a){let n=a[1].trim();if(n.startsWith("<"))return n}let e=i.search(/<!DOCTYPE\s+html/i);if(e!==-1){let n=i.lastIndexOf("</html>");return n!==-1?i.slice(e,n+7):i.slice(e)}let t=i.search(/<html[\s>]/i);if(t!==-1){let n=i.lastIndexOf("</html>");return n!==-1?i.slice(t,n+7):i.slice(t)}return i.trimStart().startsWith("<")?i:`<!DOCTYPE html><html><head><meta charset="utf-8"><script src="https://cdn.tailwindcss.com"></script></head><body class="p-8 font-sans"><pre class="whitespace-pre-wrap">${Si(i)}</pre></body></html>`}function bt(i){let a=Le(i);return a?/<\/html>/i.test(a)?a:a+`
</body>
</html>`:""}function Si(i){return i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function F(i){let a=i.match(/^---\s*\n([\s\S]*?)\n---\s*\n([\s\S]*)$/);return a?{frontmatter:a[1],body:a[2]}:{frontmatter:"",body:i}}function D(i,a){let e=new RegExp(`^${a}:\\s*(.*)$`,"m"),t=i.match(e);return t?t[1].trim().replace(/^["']|["']$/g,""):""}var yt=[{id:"blog-post",name:"\u535A\u5BA2\u957F\u6587",icon:"\u{1F4F0}",description:"\u6742\u5FD7\u611F\u957F\u6587, \u542B masthead\u3001hero\u3001figures\u3001pull quote\u3001\u4F5C\u8005\u7F72\u540D",category:"article",body:`\u3010\u6A21\u677F: \u535A\u5BA2\u957F\u6587 / Blog Post\u3011
\u3010\u610F\u56FE\u3011\u2265 600 \u5B57\u7684\u771F\u6B63\u7684\u957F\u6587\u7AE0, \u6392\u7248\u4EE5 typography \u4E3A\u4E3B, 70% \u6587\u5B57 20% \u56FE 10% chrome\u3002
\u3010\u5E03\u5C40\u3011
- Masthead (publication name + date)
- Hero (\u5927\u6807\u9898 + \u526F\u6807 + \u4F5C\u8005\u7F72\u540D + \u9605\u8BFB\u65F6\u95F4)
- \u6B63\u6587 (\u5355\u680F 65ch, \u542B figures, pull quotes, \u884C\u5185\u5F15\u7528)
- Author bio \u5361\u7247
- Related posts (3 \u5F20\u5361)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- Pull quote \u7528\u5927\u53F7 serif \u659C\u4F53 + \u5DE6\u4FA7\u8272\u6761
- Figures \u81EA\u5E26 caption (italic, smaller)
- \u4EE3\u7801\u5757: \u5706\u89D2 + \u6DF1\u8272 + \u8BED\u8A00\u6807\u7B7E`,enName:"Blog Post",scenario:"marketing",aspectHint:"\u957F\u9875\u9762",tags:["blog","essay","case study","\u957F\u6587"]},{id:"digital-eguide",name:"\u7535\u5B50\u6307\u5357",icon:"\u{1F4DA}",description:"\u4E24\u9875\u8DE8\u9875\u7535\u5B50\u6307\u5357, \u5C01\u9762 + \u8BFE\u7A0B\u9875 + pull-quote + \u6B65\u9AA4\u5217\u8868",category:"article",body:`\u3010\u6A21\u677F: \u7535\u5B50\u6307\u5357\u53CC\u9875\u9884\u89C8\u3011
\u3010\u610F\u56FE\u3011creator brand \u7684 lead-magnet \u98CE\u683C, \u4E00\u5C01\u9762\u4E00\u5185\u9875\u8DE8\u9875\u6392\u5217\u3002
\u3010\u5E03\u5C40\u3011
- Page 1 \u5C01\u9762: display title + \u4F5C\u8005 + 'What's inside' \u6570\u636E + TOC teaser
- Page 2 \u5185\u9875: lesson body + pull-quote + step list
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- lifestyle / creator brand \u8C03\u5B50, \u67D4\u548C\u7C73\u8272
- \u4E24\u9875 side-by-side \u6A2A\u5411, \u50CF\u7FFB\u5F00\u7684\u4E66`,enName:"Digital E-Guide",scenario:"marketing",aspectHint:"\u53CC\u9875\u9884\u89C8",tags:["eguide","lookbook","lead magnet","playbook"]},{id:"article-magazine",name:"\u6742\u5FD7\u6587\u7AE0",icon:"\u{1F4D6}",description:"Substack / Medium \u9AD8\u7EA7\u611F\u957F\u6587\u6392\u7248, \u9002\u5408\u516C\u4F17\u53F7\u3001\u535A\u5BA2\u53D1\u5E03",category:"article",body:`\u3010\u6A21\u677F: \u6742\u5FD7\u6587\u7AE0\u3011
- \u9876\u90E8 hero: \u5927\u6807\u9898 (text-5xl/6xl) + \u53EF\u9009\u526F\u6807\u9898 + \u4F5C\u8005 / \u9605\u8BFB\u65F6\u95F4 / \u65E5\u671F\u5143\u6570\u636E\u3002
- \u6B63\u6587: \u5355\u680F, \u6700\u5927\u5BBD\u5EA6\u7EA6 700px, \u5C45\u4E2D\u3002\u6BB5\u843D \`text-lg leading-relaxed text-neutral-700 dark:text-neutral-300\`\u3002
- H2 / H3 \u6807\u9898\u7528 serif \u5B57\u4F53, \u8BA9\u6B63\u6587\u4E0E\u6807\u9898\u6709\u89C6\u89C9\u5BF9\u6BD4\u3002
- \u5F15\u7528\u5757\u4F7F\u7528\u5DE6\u4FA7\u7C97 accent \u8272\u8FB9\u7EBF + \u659C\u4F53\u3002
- \u4EE3\u7801\u5757: \u5706\u89D2 + \u6DF1\u8272\u80CC\u666F + \u6D45\u8272\u6587\u5B57, \u663E\u793A\u8BED\u8A00\u6807\u7B7E\u3002
- \u5217\u8868\u9879\u4F7F\u7528\u81EA\u5B9A\u4E49 bullet\uFF08\u5C0F\u65B9\u5757 / accent \u5706\u70B9\uFF09\u3002
- \u7AE0\u8282\u4E4B\u95F4\u7528 \`<hr>\` \u5206\u9694, \u4F46\u6837\u5F0F\u505A\u6210\u4E2D\u592E\u5C45\u4E2D\u7684\u5C0F ornament\u3002
- \u6587\u672B\u52A0\u4E00\u4E2A\u7B80\u5355\u7684 "\u5982\u679C\u89C9\u5F97\u6709\u7528\uFF0C\u6B22\u8FCE\u8F6C\u53D1" \u884C\u52A8\u5361\u7247\u3002`,enName:"Magazine Article",scenario:"marketing",aspectHint:"A4 / \u957F\u9875\u9762",tags:["blog","essay","newsletter","\u516C\u4F17\u53F7","\u535A\u5BA2","\u6587\u7AE0"]},{id:"social-carousel",name:"\u793E\u4EA4\u5A92\u4F53\u4E09\u8054",icon:"\u{1F3A0}",description:"\u4E09\u5F20\u65B9\u5F62\u5361\u7247\u8F6E\u64AD, \u6807\u9898\u4E32\u8054, \u54C1\u724C mark + \u7F16\u53F7",category:"card",body:`\u3010\u6A21\u677F: \u4E09\u8054\u793E\u4EA4\u8F6E\u64AD / Social Carousel\u3011
\u3010\u610F\u56FE\u30113 \u5F20 1080\xD71080 \u65B9\u5F62\u5361\u7247, headline \u8DE8\u5F20\u4E32\u8054\u3002
\u3010\u5E03\u5C40\u3011
- Card 1: display headline (\u5F00\u5934) + \u54C1\u724C mark + 1/3
- Card 2: display headline (\u4E2D\u6BB5) + \u89C6\u89C9\u91CD\u70B9 + 2/3
- Card 3: display headline (\u7ED3\u5C3E) + CTA + loop icon + 3/3
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u989C\u8272\u7EDF\u4E00\u4E00\u5957\u8C03\u8272\u677F, \u5361\u7247\u4E4B\u95F4\u6E10\u8FDB\u5207\u6362
- \u4E09\u4E2A headline \u62FC\u8D77\u6765\u662F\u5B8C\u6574\u4E00\u53E5\u8BDD`,enName:"Social Carousel",scenario:"marketing",aspectHint:"1080\xD71080 \xD73",tags:["instagram","linkedin","thread","carousel","\u4E09\u8054"]},{id:"card-xiaohongshu",name:"\u5C0F\u7EA2\u4E66\u56FE\u6587\u5361\u7247",icon:"\u{1F4F1}",description:"\u5C0F\u7EA2\u4E66\u98CE\u683C\u77E5\u8BC6\u5361\u7247, \u591A\u5F20\u8054\u6392\u53EF\u6ED1\u52A8\u6D4F\u89C8",category:"card",body:`\u3010\u6A21\u677F: \u5C0F\u7EA2\u4E66\u56FE\u6587\u5361\u7247\u3011
- \u8F93\u51FA N \u5F20\u8FDE\u7EED\u5361\u7247, \u6BCF\u5F20 \`w-[1080px] h-[1440px]\`, \u7528 flex \u7EB5\u5411\u6392\u5217\u65B9\u4FBF\u6574\u4F53\u622A\u56FE\u4E5F\u65B9\u4FBF\u5355\u5F20\u622A\u56FE\u3002N \u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u4FE1\u606F\u91CF\u51B3\u5B9A: \u77ED\u5185\u5BB9 3-6 \u5F20\u8D77\u6B65, \u957F\u5185\u5BB9\u5E94\u66F4\u591A (\u5C0F\u7EA2\u4E66\u5E73\u53F0\u5355\u5E16\u6700\u591A 18 \u56FE, \u901A\u5E38 9 \u5F20\u4EE5\u5185\u6700\u4F73); \u4E00\u5F20\u5361\u53EA\u627F\u8F7D\u4E00\u4E2A\u6838\u5FC3\u89C2\u70B9\u3002
- \u7B2C\u4E00\u5F20\u662F\u5C01\u9762: \u5DE8\u5927\u7684\u6807\u9898 + 1 \u884C\u526F\u6807\u9898 + \u4E00\u4E2A\u5438\u5F15\u4EBA\u7684\u6807\u7B7E (\u7C7B\u4F3C "\u5E72\u8D27\u9884\u8B66" / "\u5EFA\u8BAE\u6536\u85CF")\u3002
- \u4E2D\u95F4\u51E0\u5F20\u5C55\u5F00\u6B63\u6587, \u6BCF\u5F20\u4E00\u4E2A\u6838\u5FC3\u89C2\u70B9, \u914D emoji + \u77ED\u53E5 + 1-2 \u4E2A\u4F8B\u5B50\u3002
- \u6700\u540E\u4E00\u5F20\u662F\u603B\u7ED3 + \u884C\u52A8\u53F7\u53EC (\u5173\u6CE8 / \u6536\u85CF / \u8BC4\u8BBA)\u3002
- \u914D\u8272: \u9009\u62E9\u67D4\u548C\u7684\u83AB\u5170\u8FEA\u8272\u6216\u7C89\u8272\u7CFB; \u5143\u7D20\u5706\u6DA6, \u5927\u91CF\u7559\u767D\u3002
- \u5B57\u53F7\u5927\u3001\u884C\u8DDD\u5BBD\u3001\u5BF9\u6BD4\u5F3A\uFF08\u5C0F\u7EA2\u4E66\u5728\u624B\u673A\u4E0A\u770B, \u5C0F\u5B57\u6839\u672C\u770B\u4E0D\u6E05\uFF09\u3002
- \u6BCF\u5F20\u5361\u7247\u53F3\u4E0B\u89D2\u5C0F\u6C34\u5370 (\u4F5C\u8005\u540D / \u65E5\u671F)\u3002`,enName:"Xiaohongshu Card",scenario:"marketing",aspectHint:"1080\xD71440 (3:4)",tags:["xhs","\u5C0F\u7EA2\u4E66","carousel","\u56FE\u6587"]},{id:"frame-macos-notification",name:"macOS \u901A\u77E5\u6A2A\u5E45",icon:"\u{1F514}",description:"\u62DF\u771F macOS \u901A\u77E5 banner + app icon + \u6807\u9898\u6B63\u6587, \u9002\u5408 video overlay / \u4EA7\u54C1\u53D1\u5E03\u9884\u544A",category:"card",body:'\u3010\u6A21\u677F: macOS \u901A\u77E5\u6A2A\u5E45\u3011\n\u3010\u610F\u56FE\u3011\u628A\u4E00\u6BB5\u516C\u544A / \u6D88\u606F / \u63D0\u793A\u6E32\u67D3\u6210 macOS Big Sur+ \u98CE\u683C\u7684\u901A\u77E5\u6A2A\u5E45, \u9002\u5408\u89C6\u9891\u89D2\u843D\u53E0\u52A0\u3001\u4EA7\u54C1\u53D1\u5E03\u9884\u544A\u3001\u793E\u5A92\u56FE\u3002Inspired by hyperframes macos-notification\u3002\n\n\u3010\u753B\u5E03\u3011\u4E24\u79CD\u7528\u6CD5:\n- \u89C6\u9891\u53E0\u52A0 1920\xD71080, \u901A\u77E5\u653E\u53F3\u4E0A\u89D2, \u5468\u56F4\u900F\u660E\u3002\n- \u5355\u72EC banner 480\xD7120, \u5C45\u4E2D\u8F93\u51FA\u3002\n\n\u3010\u6A2A\u5E45\u7ED3\u6784\u3011\n- \u5916\u6846: \u5706\u89D2 14px (macOS Big Sur \u6807\u51C6), 480\xD7120 (\u6216\u66F4\u957F 480\xD7180 \u542B\u6B63\u6587), 12-16px \u5185\u8FB9\u8DDD\u3002\n- \u80CC\u666F: **frosted glass** \u6548\u679C \u2014 `background: rgba(245,245,247,0.78)` + `backdrop-filter: blur(40px) saturate(180%)`; \u6697\u8272\u7248 `rgba(28,28,30,0.78)`\u3002\n- \u8FB9\u6846: 1px `rgba(0,0,0,0.06)` (light) / `rgba(255,255,255,0.08)` (dark); \u9876\u90E8\u52A0 1px \u4EAE highlight `rgba(255,255,255,0.5)`\u3002\n- \u9634\u5F71: `0 10px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.08)`\u3002\n\n\u3010\u5185\u5BB9\u3011\n- \u5DE6\u4FA7: **App icon** (44\xD744, \u5706\u89D2 10px, CSS gradient + 1 \u4E2A emoji \u6216 monogram \u5B57\u6BCD, **\u4E0D\u7528\u5916\u94FE\u56FE\u7247**)\u3002\n- \u4E2D\u95F4:\n  - \u9876\u90E8 row: App \u540D (SF Pro 13px, weight 600) + `now` \u6216\u5177\u4F53\u65F6\u95F4 (12px, opacity 0.6) \u2014 \u4E24\u7AEF\u5BF9\u9F50\u3002\n  - \u6807\u9898 (15px, weight 600, 1 \u884C\u622A\u65AD)\u3002\n  - \u6B63\u6587 (13px, weight 400, 1-2 \u884C\u622A\u65AD, line-height 1.35)\u3002\n- \u53F3\u4FA7 (\u53EF\u9009): action button "Open" \u6216 "Reply" (capsule, \u6D45\u7070\u5E95)\u3002\n\n\u3010\u5B57\u4F53\u3011\n- \u4E3B: `SF Pro Text` \u2192 fallback `Inter` / `system-ui`; \u4E2D\u6587\u7528 `PingFang SC` / `Noto Sans SC`\u3002\n\n\u3010\u53EF\u9009\u9644\u52A0\u3011\n- \u591A\u6761\u901A\u77E5\u5806\u53E0: \u7B2C\u4E00\u6761\u5728\u524D, \u540E\u9762 2 \u6761\u5411\u540E\u5411\u4E0B\u9012\u7F29 (scale 0.96 + opacity 0.6 + translateY)\u3002\n- \u5165\u573A\u52A8\u6548: \u4ECE\u5C4F\u5E55\u5916\u53F3\u4FA7\u6ED1\u5165 `transform: translateX(110%)\u21920`, 200ms ease-out; \u53EF\u88AB `prefers-reduced-motion` \u5173\u95ED\u3002\n- \u53F3\u4E0A\u89D2\u63A7\u5236 chip "Clear" (hover \u663E\u793A, opacity \u9ED8\u8BA4 0)\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- light mode \u80CC\u666F\u767D\u78E8\u7802, dark mode (\u63A8\u8350 video) \u51E0\u4E4E\u9ED1\u78E8\u7802\u3002\n- icon \u4E0D\u80FD\u7528\u5916\u94FE emoji \u56FE\u7247, \u7528 unicode emoji \u6216 CSS \u7ED8\u5236\u51E0\u4F55\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u63D0\u4F9B\u7684\u5185\u5BB9; \u6807\u9898 + \u6B63\u6587\u6E05\u6670\u6765\u81EA\u7528\u6237\u8F93\u5165\u3002\n- \u5355\u6587\u4EF6 HTML, \u6CE8\u610F `backdrop-filter` Safari \u9700\u8981 `-webkit-` \u524D\u7F00\u3002',enName:"macOS Notification Banner",scenario:"video",aspectHint:"1920\xD71080 \u89C6\u9891\u6216 480\xD7120 \u6A2A\u5E45",tags:["macos","notification","banner","overlay","frame"]},{id:"social-reddit-card",name:"Reddit \u5E16\u5B50\u5361",icon:"\u{1F53A}",description:"\u62DF\u771F Reddit \u5E16\u5B50\u5361 + \u4E0A\u4E0B\u6295\u7968 + \u8BC4\u8BBA\u6570, \u9002\u5408\u89C6\u9891\u53E0\u52A0 / \u6545\u4E8B\u5206\u4EAB",category:"card",body:"\u3010\u6A21\u677F: Reddit \u5E16\u5B50\u5361\u3011\n\u3010\u610F\u56FE\u3011\u628A\u4E00\u6BB5\u6545\u4E8B / \u63D0\u95EE / \u6BB5\u5B50, \u6E32\u67D3\u6210 Reddit \u5E16\u5B50\u5361\u7247, \u7528\u4E8E\u89C6\u9891\u53E0\u52A0\u3001\u793E\u5A92\u6545\u4E8B\u5206\u4EAB\u3002Inspired by hyperframes reddit-post\u3002\n\n\u3010\u753B\u5E03\u30111280\xD7720 (\u89C6\u9891\u53E0\u52A0) \u6216 800\xD7600 (\u5355\u5361\u5206\u4EAB); \u80CC\u666F\u900F\u660E\u6216\u6697\u8272 `#0b1416`\u3002\n\n\u3010\u5361\u7247\u7ED3\u6784\u3011\n- \u5916\u6846: \u5706\u89D2 16px, bg \u767D `#ffffff` (light) \u6216 `#1a1a1b` (dark, \u63A8\u8350 video overlay), border 1px `#edeff1` / `#343536`\u3002\n- \u5DE6\u4FA7 **vote rail** (40-56px \u5BBD):\n  - \u4E0A\u7BAD\u5934 \u25B2 (16px, `#878a8c`, hover \u53D8\u6A59 `#ff4500`)\u3002\n  - \u7968\u6570 (Inter, 17px, weight 700, \u5C45\u4E2D, \u989C\u8272: 0 \u7070 / \u6B63\u6A59 / \u8D1F\u84DD); \u5927\u6570\u5B57\u7528 `12.3k` \u683C\u5F0F\u3002\n  - \u4E0B\u7BAD\u5934 \u25BC (hover \u53D8\u84DD `#7193ff`)\u3002\n- \u4E3B\u4F53\u533A:\n  - \u9876\u90E8 meta row: \u5B50\u7248\u5757\u56FE\u6807 (CSS \u5706\u5F62 + \u5B57\u6BCD) + `r/subreddit` (\u7C97) + `\xB7 Posted by u/username \xB7 3h` (\u5C0F\u5B57\u7070)\u3002\n  - **\u6807\u9898** (Inter / IBM Plex Sans, 22-28px, weight 500, dark text)\u3002\n  - \u5185\u5BB9: 16px body \u6216 \u5F15\u7528\u5757\u6216 1 \u5F20\u56FE (CSS \u6E10\u53D8\u5360\u4F4D)\u3002\n  - \u5E95\u90E8 action row: \u{1F4AC} `1.2k Comments` \xB7 \u{1F3C6} Awards \xB7 \u2934\uFE0F Share \xB7 \u22EF icon\u3002\n- \u9876\u90E8\u53F3\u4E0A\u89D2 Reddit Snoo logo (\u5185\u8054 SVG, \u6A59\u8272 `#ff4500`)\u3002\n\n\u3010\u5B57\u4F53\u3011\n- \u4E3B: `IBM Plex Sans` \u2192 fallback `Inter`, weight 400/500/700\u3002\n- \u6570\u5B57: \u540C\u4E3B\u5B57\u4F53\u3002\n- \u4E2D\u6587: `Noto Sans SC`\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- Light mode: bg `#fff`, text `#1c1c1c`, secondary `#7c7c7c`\u3002\n- Dark mode (\u63A8\u8350): bg `#1a1a1b`, text `#d7dadc`, secondary `#818384`, border `#343536`\u3002\n- \u7968\u6570\u989C\u8272: \u6B63 = `#ff4500`, \u8D1F = `#7193ff`, 0 = `#878a8c`\u3002\n- \u6807\u9898\u70B9\u51FB\u533A\u53EF\u52A0\u5FAE\u5999\u80CC\u666F hover\u3002\n- \u4E25\u7981\u5916\u94FE\u56FE\u7247; \u56FE\u7247\u5360\u4F4D\u7528 CSS \u6E10\u53D8 + \u63CF\u8FF0\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u63D0\u4F9B\u7684\u5185\u5BB9; \u81EA\u52A8\u751F\u6210\u5408\u7406\u7684 subreddit / username / \u7968\u6570\u3002\n- \u5355\u6587\u4EF6 HTML; icon \u5185\u8054 SVG (\u4E0A\u4E0B\u7BAD\u5934\u3001\u8BC4\u8BBA\u6C14\u6CE1\u3001\u5956\u676F)\u3002",enName:"Reddit Post Card",scenario:"marketing",aspectHint:"1280\xD7720 \u6216 800\xD7600",tags:["reddit","social","card","overlay","story"]},{id:"social-spotify-card",name:"Spotify \u6B63\u5728\u64AD\u653E\u5361",icon:"\u{1F3B5}",description:"Spotify Now Playing \u98CE\u683C\u5361: \u4E13\u8F91\u5C01\u9762 + \u8FDB\u5EA6\u6761 + \u64AD\u653E\u63A7\u5236, \u9002\u914D\u89C6\u9891\u53E0\u52A0 / \u4E2A\u4EBA\u4E3B\u9875",category:"card",body:'\u3010\u6A21\u677F: Spotify Now-Playing \u5361\u3011\n\u3010\u610F\u56FE\u3011\u628A\u4E00\u9996\u6B4C\u3001\u4E00\u6BB5\u64AD\u5BA2\u3001\u6216\u4E00\u6BB5\u4E2A\u4EBA\u4ECB\u7ECD\u6E32\u67D3\u6210 Spotify \u6B63\u5728\u64AD\u653E\u5361, \u9002\u5408 video overlay / \u4E2A\u4EBA about page / \u521B\u4F5C\u8005 hero\u3002Inspired by hyperframes spotify-card\u3002\n\n\u3010\u753B\u5E03\u3011\u4E24\u4E2A\u5C3A\u5BF8:\n- \u6A2A\u7248\u89C6\u9891\u53E0\u52A0: 1280\xD7720, \u5361\u7247\u5C45\u4E2D\u6216\u5DE6\u4E0B\u89D2\u6D6E\u52A8\u3002\n- \u7D27\u51D1\u6A2A\u6761 widget: 600\xD7200, \u53EF\u5D4C\u5165\u5230\u4EFB\u4F55 hero\u3002\n\n\u3010\u5361\u7247\u7ED3\u6784\u3011\n- \u5916\u6846: \u5706\u89D2 12-16px; bg \u7528\u4E13\u8F91\u5C01\u9762\u8272\u63D0\u53D6\u7684\u6697\u6E10\u53D8 (e.g. `linear-gradient(135deg, #1e3264 0%, #0d1f3d 100%)`) \u6216 Spotify \u7ECF\u5178 `#121212`; \u8FB9\u7F18\u6709 1px subtle border\u3002\n- \u5DE6\u4FA7: **\u4E13\u8F91\u5C01\u9762** (CSS \u6E10\u53D8 + \u5927\u5B57 monogram \u6216\u62BD\u8C61\u51E0\u4F55\u63CF\u7ED8, \u4E0D\u80FD\u5916\u94FE\u56FE\u7247), \u5706\u89D2 6px, 60-200px \u65B9\u5F62\u3002\n- \u53F3\u4FA7:\n  - \u9876\u90E8 `NOW PLAYING` (uppercase letterspace 0.14em, 11px, \u7EFF\u8272 `#1DB954`)\u3002\n  - **\u6B4C\u540D / \u6807\u9898** (Inter / Spotify Circular, 22-28px, weight 700, \u767D\u8272)\u3002\n  - **\u827A\u4EBA / \u526F\u6807** (16px, weight 400, opacity 0.7)\u3002\n  - \u8FDB\u5EA6\u6761: 4px \u9AD8, \u5706\u89D2, \u7070\u8272\u80CC\u666F + \u767D\u8272 fill (`width: 38%`); \u4E24\u7AEF\u65F6\u95F4\u6233 `1:24 / 3:42` (mono, 11px, \u7070)\u3002\n  - \u63A7\u5236\u884C: \u23EE \u23EF \u23ED icon (inline SVG, 24px, \u767D\u8272 fill), shuffle / repeat icon \u8F83\u5C0F\u3002\n- \u53F3\u4E0A\u89D2: Spotify logo (\u5185\u8054 SVG, \u7EFF\u8272 `#1DB954` \u5706 + \u4E09\u9053\u767D\u8272\u6CE2\u7EB9)\u3002\n- \u53EF\u9009: \u53F3\u4E0B\u89D2\u5C0F\u578B\u97F3\u6CE2\u52A8\u6548 (3 \u4E2A bar `@keyframes`)\u3002\n\n\u3010\u5B57\u4F53\u3011\n- \u4E3B: `Spotify Circular` \u2192 fallback `Inter` / `Inter Tight`, weight 400 / 700\u3002\n- \u6570\u5B57: \u540C\u4E3B\u5B57\u4F53, \u4E0D\u7528 mono \u592A\u591A\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- Spotify \u7ECF\u5178 dark mode: `#121212` bg, `#1DB954` accent, `#b3b3b3` secondary text\u3002\n- \u82E5\u7528\u6237\u8F93\u5165\u662F\u6587\u672C/\u6807\u9898 \u2192 \u628A "\u6807\u9898" \u5F53\u6B4C\u540D, "\u526F\u6807/\u4F5C\u8005" \u5F53\u827A\u4EBA, \u4F30\u7B97"\u65F6\u957F" 3:42 \u9ED8\u8BA4\u3002\n- \u82E5\u7528\u6237\u8F93\u5165\u662F\u97F3\u4E50\u76F8\u5173 \u2192 \u76F4\u63A5\u5BF9\u5E94\u3002\n- \u4E25\u7981\u5916\u94FE\u56FE\u7247; \u5C01\u9762\u7528 CSS \u6E10\u53D8 + \u6587\u5B57 logo / \u51E0\u4F55\u63CF\u7ED8\u3002\n- \u5FAE\u52A8\u6548: \u97F3\u6CE2\u52A8\u6548\u7528 `@keyframes`, \u53EF\u88AB `prefers-reduced-motion` \u5173\u95ED\u3002\n- \u5355\u6587\u4EF6 HTML\u3002',enName:"Spotify Now-Playing Card",scenario:"personal",aspectHint:"1280\xD7720 \u6216 600\xD7200",tags:["spotify","music","now-playing","card","overlay"]},{id:"card-twitter",name:"Twitter \u5206\u4EAB\u5361",icon:"\u{1F426}",description:"\u63A8\u7279\u91D1\u53E5 / \u6570\u636E\u5361, \u9002\u5408\u914D\u63A8\u6587",category:"card",body:`\u3010\u6A21\u677F: Twitter \u5206\u4EAB\u5361\u3011
- \u5BB9\u5668 \`w-[1600px] h-[900px]\`, \u6697\u8272 / \u4EAE\u8272\u4E8C\u9009\u4E00\u6839\u636E\u5185\u5BB9\u60C5\u7EEA\u3002
- \u4E2D\u592E\u4E00\u53E5 hero \u91D1\u53E5 (text-6xl, font-semibold, \u9650 2-3 \u884C)\u3002
- \u4E0B\u65B9\u4F5C\u8005\u7F72\u540D + \u5934\u50CF\u5360\u4F4D + handle\u3002
- \u5DE6\u4E0A\u89D2\u5C0F\u6807\u7B7E (\u7C7B\u578B: "Insight" / "Data" / "Quote")\u3002
- \u53F3\u4E0B\u89D2\u54C1\u724C\u6C34\u5370\u3002
- \u6574\u5F20\u5361\u7247\u6709\u5FAE\u5999\u7684\u7EB9\u7406 (grid \u7F51\u683C / noise / dot pattern)\u3002
- \u622A\u56FE\u540E\u53EF\u76F4\u63A5\u914D\u63A8\u6587\u53D1\u51FA, \u89C6\u89C9\u7B80\u6D01\u6709\u529B\u3002`,enName:"Twitter Share Card",scenario:"marketing",aspectHint:"1600\xD7900 (16:9)",tags:["twitter","x","quote","\u91D1\u53E5"]},{id:"social-x-post-card",name:"X (Twitter) \u5E16\u5B50\u5361",icon:"\u{1D54F}",description:"\u62DF\u771F X \u63A8\u6587\u5361\u7247 + \u4E92\u52A8\u6570\u636E (likes/reposts/views), \u9002\u914D\u89C6\u9891\u53E0\u52A0\u6216\u56FE\u5361\u5206\u4EAB",category:"card",body:'\u3010\u6A21\u677F: X (Twitter) \u5E16\u5B50\u5361\u3011\n\u3010\u610F\u56FE\u3011\u628A\u4E00\u6BB5\u63A8\u6587\u5185\u5BB9 (\u6216\u7528\u6237\u7684\u91D1\u53E5) \u6E32\u67D3\u6210\u4E00\u5F20\u62DF\u771F\u5EA6\u6781\u9AD8\u7684 X \u5E16\u5B50\u5361\u7247, \u7528\u4E8E\u89C6\u9891\u53E0\u52A0\u3001\u63A8\u7279\u53D1\u56FE\u3001\u77E5\u8BC6\u6C89\u6DC0\u3002Inspired by hyperframes x-post\u3002\n\n\u3010\u753B\u5E03\u30111280\xD7720 \u6216 1080\xD71080, \u6697\u80CC\u666F `#0f1419` \u6216\u4EAE\u80CC\u666F `#ffffff` (\u6309 X \u4E3B\u9898); \u5361\u7247\u5C45\u4E2D, \u9634\u5F71\u67D4\u548C\u3002\n\n\u3010\u5361\u7247\u7ED3\u6784\u3011\n- \u5916\u6846: \u5706\u89D2 16px, 1px border `#2f3336` (dark) / `#eff3f4` (light), \u5185\u8FB9\u8DDD 16px\u3002\n- \u9876\u90E8 row: \u5934\u50CF (48\xD748 \u5706\u5F62, \u7528 CSS gradient \u5360\u4F4D) + \u7528\u6237\u540D + handle `@username` + verified \u84DD\u52FE + \u65F6\u95F4 (mono, 12px, \u7070)\u3002\n- \u6B63\u6587: 17-22px, \u5B57\u91CD 400; \u94FE\u63A5\u7528 X \u84DD `#1d9bf0`; hashtag \u540C\u8272; mention \u540C\u8272; \u6BB5\u843D\u95F4\u7A7A 0.6em\u3002\n- \u53EF\u9009: \u5F15\u7528\u5361 (\u5C0F\u5361\u5185\u5D4C, \u7070\u5E95, \u5706\u89D2 12px)\u3002\n- \u53EF\u9009: 1 \u5F20\u56FE (CSS \u6E10\u53D8 + \u63CF\u8FF0\u5360\u4F4D, \u4E0D\u80FD\u5916\u94FE\u56FE\u7247), \u6BD4\u4F8B 16:9, \u5706\u89D2 12px\u3002\n- \u4E92\u52A8 row: 4 \u4E2A icon + \u6570\u5B57 (\u56DE\u590D / \u8F6C\u63A8 / \u5F15\u7528 / \u70B9\u8D5E), icon \u7528 inline SVG (X \u5B98\u65B9\u98CE\u683C), \u7070\u8272, hover \u65F6\u53D8\u8272\u3002\n- \u9876\u90E8\u53F3\u4E0A X logo \u5355\u7EBF SVG\u3002\n- \u6D4F\u89C8\u91CF row: \u{1F441}\uFE0F + \u6570\u5B57 (\u5C0F\u5B57)\u3002\n\n\u3010\u5B57\u4F53\u3011\n- \u897F\u6587: `Chirp` (X \u7684\u5B57\u4F53) \u2192 fallback `Inter` \u6216 `Segoe UI`\u3002\n- \u4E2D\u6587: `Noto Sans SC` / `PingFang SC`\u3002\n- \u6570\u5B57: \u540C\u4E3B\u5B57\u4F53, \u4E0D\u7528 mono\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- \u914D\u8272 light: bg `#fff`, text `#0f1419`, secondary `#536471`, border `#eff3f4`, accent `#1d9bf0`\u3002\n- \u914D\u8272 dark (\u63A8\u8350, \u89C6\u9891\u53E0\u52A0\u7528): bg `#000`, text `#e7e9ea`, secondary `#71767b`, border `#2f3336`, accent `#1d9bf0`\u3002\n- \u6570\u5B57\u683C\u5F0F\u5316: 1.2K / 4.5M (\u4E0D\u8981\u539F\u59CB 1234)\u3002\n- \u5185\u5BB9\u5FC5\u987B\u6765\u81EA\u7528\u6237\u8F93\u5165, \u4E0D\u80FD\u7F16\u9020\u63A8\u6587\u3002\n- \u82E5\u7528\u6237\u8F93\u5165\u662F\u6570\u636E \u2192 \u81EA\u52A8\u603B\u7ED3\u6210\u4E00\u53E5"\u91D1\u53E5"\u63A8\u6587 (\u2264 280 \u5B57\u7B26)\u3002\n- \u5355\u6587\u4EF6 HTML; icon \u5185\u8054 SVG; \u4E0D\u8981\u4EFB\u4F55\u5916\u90E8\u56FE\u7247 URL\u3002\n- \u53EF\u9009: \u5361\u7247\u80CC\u540E\u52A0\u5FAE\u5999\u5F84\u5411\u9AD8\u5149 `radial-gradient(...)` \u589E\u52A0\u89C6\u9891\u53E0\u52A0\u7684\u53EF\u8BFB\u6027\u3002',enName:"X / Twitter Post Card",scenario:"marketing",aspectHint:"1280\xD7720 \u6216 1080\xD71080",tags:["twitter","x","social","card","overlay"]},{id:"dashboard",name:"\u7BA1\u7406\u540E\u53F0\u4EEA\u8868\u677F",icon:"\u{1F39B}\uFE0F",description:"\u56FA\u5B9A\u4FA7\u680F + \u9876\u680F + KPI \u7F51\u683C + 1-2 \u5F20\u56FE",category:"dashboard",body:`\u3010\u6A21\u677F: \u7BA1\u7406\u540E\u53F0 Dashboard\u3011
\u3010\u610F\u56FE\u3011\u6807\u51C6 admin/analytics \u4EEA\u8868\u677F\u5355\u9875\u3002
\u3010\u5E03\u5C40\u3011
- Fixed left sidebar (logo + \u5BFC\u822A + \u7528\u6237 footer)
- Top bar (search + \u901A\u77E5 + avatar)
- Main: KPI cards \u7F51\u683C (3-5 \u4E2A)
- 1-2 \u5F20\u4E3B\u56FE\u8868 (\u6298\u7EBF / \u67F1 / \u533A\u57DF)
- \u5E95\u90E8 recent activity \u5217\u8868`,enName:"Admin Dashboard",scenario:"operations",aspectHint:"\u684C\u9762 1440",tags:["dashboard","admin","analytics"]},{id:"kanban-board",name:"\u770B\u677F / Kanban",icon:"\u{1F4CC}",description:"To do / In progress / In review / Done \u56DB\u5217, \u5361\u7247 + \u5934\u50CF + \u6CF3\u9053",category:"dashboard",body:`\u3010\u6A21\u677F: Kanban \u770B\u677F\u3011
\u3010\u610F\u56FE\u3011\u7C7B Trello \u7684 Kanban \u5355\u9875\u3002
\u3010\u5E03\u5C40\u3011
- \u9876\u90E8 filter bar (assignee / label / search)
- 4 \u5217: To do / In progress / In review / Done
- \u5361\u7247\u542B: \u6807\u9898 / labels / due / avatar / \u8BC4\u8BBA\u6570
- \u53EF\u9009 swimlanes (\u6309 epic / assignee \u5206\u7EC4)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u4E0D\u9700\u8981\u771F drag, \u4F46\u89C6\u89C9\u4E0A\u8981\u50CF\u53EF\u62D6`,enName:"Kanban Board",scenario:"operations",aspectHint:"\u684C\u9762 1440",tags:["kanban","trello","sprint","\u770B\u677F"]},{id:"social-media-dashboard",name:"\u793E\u5A92\u521B\u4F5C\u8005\u4EEA\u8868\u677F",icon:"\u{1F4E1}",description:"\u5E73\u53F0\u5207\u6362 + \u7C89\u4E1D/\u4E92\u52A8 KPI + \u589E\u957F\u66F2\u7EBF + Top post + \u70ED\u95E8\u8BDD\u9898",category:"dashboard",body:`\u3010\u6A21\u677F: \u793E\u5A92\u521B\u4F5C\u8005\u4EEA\u8868\u677F\u3011
\u3010\u610F\u56FE\u3011\u9762\u5411\u535A\u4E3B / \u521B\u4F5C\u8005\u7684\u793E\u5A92\u6570\u636E\u770B\u677F\u3002
\u3010\u5E03\u5C40\u3011
- \u9876\u90E8\u5E73\u53F0 switcher (X / LinkedIn / YouTube / Instagram / TikTok)
- KPI \u5361\u7247 (followers / engagement / likes / reposts)
- Follower-growth chart
- Top post this week \u9884\u89C8
- Side: trending topics / top comments`,enName:"Social Media Dashboard",scenario:"creator",aspectHint:"\u684C\u9762 1440",tags:["social","creator","analytics","x","linkedin","tiktok"]},{id:"social-media-matrix",name:"\u793E\u5A92\u77E9\u9635\u8FFD\u8E2A\u9762\u677F",icon:"\u{1F6F0}\uFE0F",description:"\u7535\u5F71\u611F\u591A\u5E73\u53F0\u793E\u5A92\u5206\u6790: \u4E92\u52A8\u56FE\u3001\u60AC\u6D6E\u6D1E\u5BDF\u3001\u533A\u95F4\u5BF9\u6BD4\u3001\u660E\u6697\u4E3B\u9898",category:"dashboard",body:`\u3010\u6A21\u677F: \u793E\u5A92\u77E9\u9635\u8FFD\u8E2A (Social Matrix Tracker)\u3011
\u3010\u610F\u56FE\u3011\u7535\u5F71\u611F\u3001\u6570\u636E\u5BC6\u96C6\u7684\u591A\u5E73\u53F0\u793E\u5A92\u770B\u677F\u3002
\u3010\u5E03\u5C40\u3011
- Hero header (\u7EDF\u4E00\u54C1\u724C + \u65F6\u95F4\u7A97 + \u4E3B\u9898\u5207\u6362)
- Multi-platform KPI matrix (\u6A2A platform \xD7 \u7EB5 metric)
- \u4EA4\u4E92\u5F0F charts (hover tooltip + range compare)
- Insights drawer (\u53F3\u62BD\u5C49, \u6587\u5B57\u6D1E\u5BDF)
- Top posts grid
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- dark / light \u5207\u6362; \u6570\u636E\u7528 seed \u515C\u5E95`,enName:"Social Media Matrix Tracker",scenario:"creator",aspectHint:"\u684C\u9762\u957F\u9875",tags:["matrix","tracker","multi-platform"]},{id:"dating-web",name:"\u793E\u533A / \u914D\u5BF9\u6570\u636E\u5899",icon:"\u{1F49E}",description:"\u6D88\u8D39\u611F\u914D\u5BF9\u4EEA\u8868\u677F: \u4FE1\u53F7 ticker + KPI + 30 \u5929\u67F1\u72B6 + \u8D8B\u52BF",category:"dashboard",body:`\u3010\u6A21\u677F: \u793E\u533A / \u914D\u5BF9 Dashboard\u3011
\u3010\u610F\u56FE\u3011\u6D88\u8D39\u4EA7\u54C1\u611F\u7684\u6570\u636E\u5899, editorial typography + \u514B\u5236\u7684\u9AD8\u4EAE\u8272\u3002
\u3010\u5E03\u5C40\u3011
- Left rail \u5BFC\u822A
- Ticker bar \u5B9E\u65F6\u4FE1\u53F7
- Headline KPIs
- 30-day mutual-matches \u67F1\u72B6\u56FE
- Match-rate \u8D8B\u52BF block`,enName:"Dating / Community Dashboard",scenario:"personal",aspectHint:"\u684C\u9762 1440",tags:["dating","community","consumer"]},{id:"team-okrs",name:"\u56E2\u961F OKR \u8FFD\u8E2A",icon:"\u{1F3AF}",description:"\u5B63\u5EA6 banner + 3 \u4E2A\u76EE\u6807 + KR \u8FDB\u5EA6\u6761 + owner + \u72B6\u6001 pill",category:"dashboard",body:`\u3010\u6A21\u677F: Team OKRs\u3011
\u3010\u610F\u56FE\u3011OKR \u8FFD\u8E2A\u9875, \u4E00\u773C\u770B\u51FA\u8FDB\u5EA6\u3002
\u3010\u5E03\u5C40\u3011
- Quarter banner (Q? + \u4E3B\u9898)
- 3 \u4E2A objectives \u5217, \u6BCF\u4E2A\u542B\u4E00\u7EC4 KR
- \u6BCF\u4E2A KR \u4E00\u6761\u8FDB\u5EA6\u6761 + \u6570\u503C + owner avatar + \u72B6\u6001 pill
- \u53F3\u4FA7 'this quarter at a glance' \u6458\u8981`,enName:"Team OKRs",scenario:"product",aspectHint:"\u684C\u9762 1440",tags:["okr","objectives","key results","\u76EE\u6807"]},{id:"flowai-team-dashboard",name:"FlowAI \u56E2\u961F\u7BA1\u7406",icon:"\u{1F30A}",description:"\u4E09\u4E2A tab \u7684\u56E2\u961F\u7BA1\u7406\u540E\u53F0: \u6210\u5458\u3001\u8BE6\u60C5\u3001\u6D3B\u52A8\u65E5\u5FD7, \u542B\u56FE\u8868 + CSV \u5BFC\u51FA",category:"dashboard",body:`\u3010\u6A21\u677F: FlowAI \u56E2\u961F\u7BA1\u7406 Dashboard\u3011
\u3010\u610F\u56FE\u3011FlowAI \u7F8E\u5B66\u7684\u56E2\u961F\u7BA1\u7406 admin \u5355\u9875\u3002
\u3010\u5E03\u5C40\u3011
- Tabs: Team Members / Team Details / Activity Log
- KPI stat row
- Member table (avatar + \u89D2\u8272 + \u72B6\u6001)
- Role distribution bar chart
- Online presence + activity sparklines
- Top contributors panel
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- light/dark \u5207\u6362, hover tooltip, click-to-zoom panels
- CSV export \u6309\u94AE (\u524D\u7AEF\u5B9E\u73B0)`,enName:"FlowAI Team Dashboard",scenario:"operations",aspectHint:"\u684C\u9762 1440",tags:["flowai","team","members"]},{id:"live-dashboard",name:"Notion \u98CE\u56E2\u961F\u4EEA\u8868\u677F",icon:"\u{1F4C8}",description:"Notion \u98CE\u56E2\u961F\u4EEA\u8868\u677F, KPI + 7 \u65E5 sparkline + activity feed + \u4EFB\u52A1\u8868",category:"dashboard",body:`\u3010\u6A21\u677F: Live Team Dashboard\u3011
\u3010\u610F\u56FE\u3011Notion \u98CE\u7684\u56E2\u961F\u52A8\u6001\u603B\u89C8, \u5373\u4F7F\u6CA1\u6709\u6570\u636E\u6E90\u4E5F\u7528 seed \u6570\u636E\u515C\u5E95\u3002
\u3010\u5E03\u5C40\u3011
- Header (\u56E2\u961F + \u65F6\u95F4\u7A97)
- KPI \u5361\u7247\u7F51\u683C
- 7 \u5929 sparkline \u8D8B\u52BF
- Real-time activity feed (avatar + \u52A8\u4F5C + \u65F6\u95F4)
- Linked database task table (zebra + \u72B6\u6001 pill)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- Notion-callout / toggle / \u6570\u636E\u5E93\u8868\u914D\u8272\u98CE\u683C`,enName:"Live Team Dashboard",scenario:"operations",aspectHint:"\u684C\u9762\u957F\u9875",tags:["notion","team","live","dashboard"]},{id:"experiment-readout",name:"\u5B9E\u9A8C\u590D\u76D8",icon:"\u{1F9EA}",description:"\u5047\u8BBE + \u6307\u6807 + \u7ED3\u679C + \u89E3\u91CA + \u51B3\u7B56, \u628A A/B \u6216\u4EA7\u54C1\u5B9E\u9A8C\u8F6C\u6210\u884C\u52A8\u5EFA\u8BAE",category:"data",body:`\u3010\u6A21\u677F: \u5B9E\u9A8C\u590D\u76D8 / Experiment Readout\u3011
\u3010\u610F\u56FE\u3011\u8FD9\u4E0D\u662F\u666E\u901A\u6570\u636E\u62A5\u544A\u3001\u4E0D\u662F dashboard\u3002\u76EE\u6807\u662F\u56DE\u7B54: "\u8FD9\u4E2A\u5B9E\u9A8C\u8BF4\u660E\u4E86\u4EC0\u4E48, \u6211\u4EEC\u4E0B\u4E00\u6B65\u5E94\u8BE5\u4E0A\u7EBF\u3001\u505C\u6B62\u3001\u7EE7\u7EED\u8DD1, \u8FD8\u662F\u91CD\u65B0\u8BBE\u8BA1?"

\u3010\u9002\u5408\u8F93\u5165\u3011
- A/B test\u3001\u589E\u957F\u5B9E\u9A8C\u3001\u5B9A\u4EF7\u5B9E\u9A8C\u3001onboarding \u6539\u7248\u3001\u529F\u80FD\u7070\u5EA6\u3001\u90AE\u4EF6\u5B9E\u9A8C
- \u53EF\u4EE5\u662F markdown\u3001CSV\u3001\u8868\u683C\u7C98\u8D34\u6216\u6DF7\u5408\u8BB0\u5F55

\u3010\u5FC5\u987B\u8F93\u51FA\u7684\u7ED3\u6784\u3011
1. Header: \u5B9E\u9A8C\u540D\u79F0\u3001owner\u3001\u65E5\u671F\u3001\u5B9E\u9A8C\u72B6\u6001\u3001decision\u3002
2. Hypothesis: \u539F\u59CB\u5047\u8BBE, \u5FC5\u987B\u6539\u5199\u6210\u53EF\u9A8C\u8BC1\u53E5\u5F0F\u3002
3. Setup: audience\u3001variant\u3001duration\u3001sample size\u3001primary metric\u3001guardrail metrics\u3002
4. Result snapshot: primary metric lift\u3001absolute delta\u3001sample\u3001confidence / caveat\u3002
5. Metric table: Control vs Variant, primary + secondary + guardrail\u3002
6. Interpretation: \u89E3\u91CA\u7ED3\u679C\u4E3A\u4EC0\u4E48\u53D1\u751F, \u533A\u5206 signal\u3001noise\u3001unknown\u3002
7. Decision: Ship / iterate / extend / stop \u56DB\u9009\u4E00, \u5E76\u7ED9\u7406\u7531\u3002
8. Follow-up experiments: 2-4 \u4E2A\u4E0B\u4E00\u6B65\u5B9E\u9A8C, \u6BCF\u4E2A\u5305\u542B hypothesis\u3001expected impact\u3001effort\u3002
9. Instrumentation notes: \u6570\u636E\u7F3A\u53E3\u3001\u57CB\u70B9\u95EE\u9898\u3001\u6837\u672C\u504F\u5DEE\u3002

\u3010\u8BBE\u8BA1\u8981\u6C42\u3011
- \u4EA7\u54C1\u6570\u636E\u56E2\u961F\u98CE\u683C: \u6E05\u695A\u3001\u53EF\u4FE1\u3001\u884C\u52A8\u5BFC\u5411\u3002
- \u9996\u5C4F\u5FC5\u987B\u6709\u5927\u53F7 decision badge \u548C primary metric delta\u3002
- \u56FE\u8868\u53EF\u4EE5\u7528 CSS/SVG/Chart.js; \u5982\u679C\u7528 Chart.js, canvas \u5916\u5C42\u5FC5\u987B\u56FA\u5B9A\u9AD8\u5EA6\u3002
- \u4E0D\u8981\u628A\u7ED3\u679C\u5305\u88C5\u5F97\u8FC7\u5EA6\u786E\u5B9A; \u5C0F\u6837\u672C\u6216\u7F3A\u5C11\u663E\u8457\u6027\u65F6\u5FC5\u987B\u660E\u786E caveat\u3002

\u3010\u53EF\u9009\u98CE\u683C\u6A21\u677F \u2014 \u53C2\u8003 assets/\u3011
\u6839\u636E\u5B9E\u9A8C\u8BED\u5883\u9009\u62E9\u4E00\u79CD, \u4E0D\u8981\u4E09\u79CD\u6DF7\u7528:
- \`assets/product-readout.html\`: \u9ED8\u8BA4\u98CE\u683C\u3002\u6D45\u8272\u4EA7\u54C1\u5B9E\u9A8C\u590D\u76D8, \u9002\u5408 PM / growth / leadership readout\u3002
- \`assets/lab-notebook.html\`: \u7814\u7A76\u5B9E\u9A8C\u5BA4 notebook, \u9002\u5408 early-stage experiment\u3001\u5B9A\u6027 + \u5B9A\u91CF\u6DF7\u5408\u3001\u9700\u8981\u4FDD\u7559 caveat \u7684\u63A2\u7D22\u5B9E\u9A8C\u3002
- \`assets/growth-console.html\`: \u6DF1\u8272 growth analytics console, \u9002\u5408\u589E\u957F\u56E2\u961F\u3001\u5B9E\u65F6\u6307\u6807\u3001\u6F0F\u6597 / activation / conversion readout\u3002

\u5982\u679C\u7528\u6237\u6CA1\u6709\u6307\u5B9A\u98CE\u683C, \u4F18\u5148\u4F7F\u7528 \`product-readout\`; \u5982\u679C\u6750\u6599\u5F3A\u8C03\u7814\u7A76\u8FC7\u7A0B\u548C\u4E0D\u786E\u5B9A\u6027, \u4F7F\u7528 \`lab-notebook\`; \u5982\u679C\u6750\u6599\u5F3A\u8C03\u589E\u957F\u6307\u6807\u3001\u6F0F\u6597\u3001\u5B9E\u65F6\u76D1\u63A7\u6216\u8FD0\u8425\u8282\u594F, \u4F7F\u7528 \`growth-console\`\u3002

\u3010\u5185\u5BB9\u771F\u5B9E\u6027\u3011
- \u53EA\u4F7F\u7528\u7528\u6237\u63D0\u4F9B\u7684\u6570\u636E\u3002\u4E0D\u8981\u634F\u9020 p-value\u3001confidence\u3001\u6837\u672C\u91CF\u3002
- \u5982\u679C\u6CA1\u6709\u7EDF\u8BA1\u663E\u8457\u6027\u4FE1\u606F, \u7528 "directional" / "inconclusive" / "needs more data" \u8868\u8FBE\u3002`,enName:"Experiment Readout",scenario:"product",aspectHint:"\u4EA7\u54C1\u5B9E\u9A8C\u62A5\u544A",tags:["experiment","ab-test","growth","product","data","\u5B9E\u9A8C","\u590D\u76D8"]},{id:"data-report",name:"\u6570\u636E\u53EF\u89C6\u5316\u62A5\u544A",icon:"\u{1F4CA}",description:"\u628A CSV/Excel/JSON \u6570\u636E\u8F6C\u6210\u6F02\u4EAE\u7684\u53EF\u89C6\u5316\u62A5\u544A\u9875",category:"data",body:'\u3010\u6A21\u677F: \u6570\u636E\u53EF\u89C6\u5316\u62A5\u544A\u3011\n- \u5934\u90E8: \u62A5\u544A\u6807\u9898 + \u65F6\u95F4\u533A\u95F4 + \u6570\u636E\u6765\u6E90\u8BF4\u660E\u3002\n- KPI \u5361\u7247\u7F51\u683C: 3-5 \u4E2A\u6700\u91CD\u8981\u6307\u6807, \u6BCF\u4E2A\u5361\u7247\u663E\u793A\u6570\u503C + \u540C\u6BD4\u53D8\u5316 + \u5FAE\u578B\u8D8B\u52BF\u7EBF\u3002\n- \u4E3B\u56FE\u8868\u533A: \u81F3\u5C11 2 \u4E2A\u56FE\u8868 (\u67F1\u72B6 / \u6298\u7EBF / \u997C / \u6563\u70B9), \u4F7F\u7528 Chart.js \u6216 ECharts (jsdelivr CDN \u5F15\u5165), \u6570\u636E\u4ECE\u7528\u6237\u8F93\u5165\u89E3\u6790\u5F97\u5230\u3002\n- **\u56FE\u8868\u5BB9\u5668\u5FC5\u987B\u6709\u56FA\u5B9A\u9AD8\u5EA6**: \u6BCF\u4E2A `<canvas>` \u5916\u5C42\u5305\u4E00\u4E2A `<div style="position:relative;height:NNNpx">` (KPI \u8FF7\u4F60\u56FE ~40px, \u4E3B\u56FE\u8868 ~240\u2013280px)\u3002Chart.js \u7528 `responsive:true, maintainAspectRatio:false` \u65F6\u82E5\u7236\u5BB9\u5668\u6CA1\u6709\u663E\u5F0F\u9AD8\u5EA6, \u4F1A\u9677\u5165 ResizeObserver \u6B7B\u5FAA\u73AF, \u56FE\u8868\u65E0\u9650\u589E\u9AD8\u76F4\u81F3\u5361\u6B7B\u6D4F\u89C8\u5668\u3002**\u7EDD\u5BF9\u4E0D\u8981**\u76F4\u63A5\u7ED9 canvas \u5199 `height=` \u5C5E\u6027\u5F53\u5E03\u5C40, \u90A3\u4E2A\u53EA\u662F\u521D\u59CB\u503C\u3002\n- \u6570\u636E\u8868\u683C: \u7528\u6237\u539F\u59CB\u6570\u636E\u8282\u9009, \u4F7F\u7528 `<table>` + \u73B0\u4EE3\u5316\u6837\u5F0F (zebra stripe, hover, sticky header)\u3002\n- \u6D1E\u5BDF\u5757: 3-5 \u6761\u6587\u5B57\u6D1E\u5BDF, \u7528 emoji \u5F00\u5934, \u50CF\u4EA7\u54C1\u5468\u62A5\u3002\n- \u5E95\u90E8"\u65B9\u6CD5\u8BBA"\u6298\u53E0\u533A\u3002\n- \u914D\u8272\u514B\u5236\u4E13\u4E1A: \u4E3B\u8272 1 + \u4E2D\u6027\u8272\u9636, \u56FE\u8868\u7528\u8C03\u8272\u677F\u3002\n- **\u5FC5\u987B\u89E3\u6790\u7528\u6237\u63D0\u4F9B\u7684\u5B9E\u9645\u6570\u636E**, \u4E0D\u8981\u634F\u9020\u3002',enName:"Data Visualization Report",scenario:"finance",aspectHint:"\u684C\u9762\u957F\u9875\u9762",tags:["data","report","chart","\u6570\u636E","\u62A5\u544A"]},{id:"exec-briefing-memo",name:"\u9AD8\u7BA1\u51B3\u7B56\u7B80\u62A5",icon:"\u2696\uFE0F",description:"Decision needed + recommendation + evidence + tradeoffs, \u628A\u590D\u6742\u6750\u6599\u538B\u6210\u53EF\u62CD\u677F\u7684\u4E00\u9875",category:"doc",body:`\u3010\u6A21\u677F: \u9AD8\u7BA1\u51B3\u7B56\u7B80\u62A5 / Executive Briefing Memo\u3011
\u3010\u610F\u56FE\u3011\u8FD9\u4E0D\u662F\u4F1A\u8BAE\u7EAA\u8981\u3001\u4E0D\u662F\u5468\u62A5\u3001\u4E0D\u662F PRD\u3002\u5B83\u7684\u552F\u4E00\u76EE\u6807\u662F\u5E2E\u52A9\u51B3\u7B56\u8005\u5728 3 \u5206\u949F\u5185\u7406\u89E3\u95EE\u9898\u5E76\u62CD\u677F\u3002

\u3010\u9002\u5408\u8F93\u5165\u3011
- \u957F\u4F1A\u8BAE\u8BB0\u5F55\u3001\u8C03\u7814\u6750\u6599\u3001\u6218\u7565\u8BA8\u8BBA\u3001\u9500\u552E\u53CD\u9988\u3001\u4EA7\u54C1\u6570\u636E\u3001\u6295\u8D44\u5907\u5FD8
- \u7528\u6237\u53EF\u80FD\u7ED9\u5F88\u591A\u788E\u7247\u4FE1\u606F; \u4F60\u8981\u63D0\u70BC\u6210\u4E00\u4E2A\u660E\u786E decision frame

\u3010\u5FC5\u987B\u8F93\u51FA\u7684\u7ED3\u6784\u3011
1. Memo header: \u4E3B\u9898\u3001owner\u3001audience\u3001date\u3001decision deadline\u3002
2. Decision needed: \u7528\u4E00\u53E5\u8BDD\u5199\u6E05\u695A\u9700\u8981\u62CD\u677F\u7684\u95EE\u9898\u3002
3. Recommendation: \u660E\u786E\u5EFA\u8BAE, \u4E0D\u8981\u5199 "\u53EF\u4EE5\u8003\u8651"\u3002\u5FC5\u987B\u5305\u542B confidence level\u3002
4. Why now: \u4E3A\u4EC0\u4E48\u73B0\u5728\u9700\u8981\u51B3\u5B9A, \u4E0D\u51B3\u5B9A\u7684\u4EE3\u4EF7\u662F\u4EC0\u4E48\u3002
5. Key facts: 5-7 \u4E2A\u4E8B\u5B9E\u8BC1\u636E, \u6BCF\u6761\u6807\u6CE8\u6765\u6E90\u7C7B\u578B (sales / product / finance / customer / ops)\u3002
6. Tradeoff table: Option A / Option B / Option C, \u5BF9\u6BD4 upside\u3001cost\u3001risk\u3001reversibility\u3002
7. Risks & mitigations: 3-5 \u4E2A\u98CE\u9669, \u6BCF\u4E2A\u7ED9\u7F13\u89E3\u52A8\u4F5C\u3002
8. Decision path: approve / reject / ask for more evidence \u4E09\u79CD\u8DEF\u5F84\u5404\u81EA\u4E0B\u4E00\u6B65\u3002
9. Next actions: owner\u3001due date\u3001expected artifact\u3002

\u3010\u8BBE\u8BA1\u8981\u6C42\u3011
- \u50CF\u9876\u7EA7\u54A8\u8BE2\u516C\u53F8\u7684 one-page decision memo: \u514B\u5236\u3001\u6E05\u695A\u3001\u5BC6\u5EA6\u9AD8\u3002
- \u9996\u5C4F\u5FC5\u987B\u76F4\u63A5\u5448\u73B0 decision + recommendation, \u4E0D\u8981\u5148\u94FA\u9648\u80CC\u666F\u3002
- \u4F7F\u7528\u5F3A\u5C42\u7EA7: \u5927\u53F7\u7ED3\u8BBA\u3001\u7D27\u51D1\u8BC1\u636E\u5361\u3001\u5BF9\u6BD4\u8868\u3001\u72B6\u6001 pill\u3002
- \u4E0D\u8981\u505A\u6210\u957F\u6587\u7AE0; \u4E0D\u8981\u505A\u6210 deck; \u4E0D\u8981\u5199\u7A7A\u6CDB\u5546\u4E1A\u9ED1\u8BDD\u3002

\u3010\u53EF\u9009\u98CE\u683C\u6A21\u677F \u2014 \u53C2\u8003 assets/\u3011
\u6839\u636E\u51B3\u7B56\u573A\u666F\u9009\u62E9\u4E00\u79CD, \u4E0D\u8981\u4E09\u79CD\u6DF7\u7528:
- \`assets/board-memo.html\`: \u9ED8\u8BA4\u98CE\u683C\u3002\u6D45\u8272\u9AD8\u7BA1 memo, \u9002\u5408 CEO/CFO/CRO\u3001\u8FD0\u8425\u3001\u4EA7\u54C1\u51B3\u7B56\u3002
- \`assets/decision-command.html\`: \u6DF1\u8272 command center, \u9002\u5408\u7D27\u6025\u51B3\u7B56\u3001\u98CE\u9669\u5904\u7F6E\u3001incident\u3001go/no-go\u3001launch gate\u3002
- \`assets/board-paper.html\`: \u6B63\u5F0F board paper / \u8463\u4E8B\u4F1A\u7EB8\u8D28\u8BAE\u6848, \u9002\u5408\u8463\u4E8B\u4F1A\u3001\u6295\u8D44\u4EBA\u3001\u5408\u89C4\u3001\u9884\u7B97\u5BA1\u6279\u3002

\u5982\u679C\u7528\u6237\u6CA1\u6709\u6307\u5B9A\u98CE\u683C, \u4F18\u5148\u4F7F\u7528 \`board-memo\`; \u5982\u679C\u6750\u6599\u5F3A\u8C03\u7D27\u6025\u3001\u98CE\u9669\u3001\u884C\u52A8\u6307\u6325, \u4F7F\u7528 \`decision-command\`; \u5982\u679C\u6750\u6599\u9762\u5411\u8463\u4E8B\u4F1A\u6216\u6B63\u5F0F\u5BA1\u6279, \u4F7F\u7528 \`board-paper\`\u3002

\u3010\u5185\u5BB9\u771F\u5B9E\u6027\u3011
- \u4E0D\u8981\u634F\u9020\u6570\u5B57\u3001\u5BA2\u6237\u3001\u9884\u7B97\u3001\u65E5\u671F\u3002
- \u5982\u679C\u7F3A\u5C11\u5173\u952E\u4FE1\u606F, \u5728 Evidence gaps \u4E2D\u5217\u51FA, \u4F46\u4ECD\u7ED9\u51FA\u57FA\u4E8E\u73B0\u6709\u8BC1\u636E\u7684 provisional recommendation\u3002`,enName:"Executive Briefing Memo",scenario:"operations",aspectHint:"\u4E00\u9875\u51B3\u7B56 memo",tags:["executive","briefing","memo","decision","strategy","\u7B80\u62A5","\u51B3\u7B56"]},{id:"eng-runbook",name:"\u5DE5\u7A0B Runbook",icon:"\u{1F4D5}",description:"\u670D\u52A1\u6982\u8FF0 + alerts \u8868 + dashboards + \u64CD\u4F5C\u547D\u4EE4 + on-call + \u4E8B\u6545\u6E05\u5355",category:"doc",body:`\u3010\u6A21\u677F: Engineering Runbook\u3011
\u3010\u610F\u56FE\u3011\u5DE5\u7A0B oncall \u7528\u7684\u53EF\u62F7\u8D1D\u547D\u4EE4\u7684 runbook \u5355\u9875\u3002
\u3010\u5E03\u5C40\u3011
- Service overview (\u62D3\u6251 + \u4F9D\u8D56)
- Alerts table (severity / threshold / runbook link)
- Dashboards links \u5361\u7247
- Common procedures (mono \u4EE3\u7801\u5757, \u4E00\u952E\u590D\u5236)
- On-call rotation (\u672C\u5468 + \u4E0B\u5468)
- Incident response checklist`,enName:"Engineering Runbook",scenario:"engineering",aspectHint:"\u957F\u9875\u9762",tags:["runbook","ops","oncall","sre"]},{id:"meeting-notes",name:"\u4F1A\u8BAE\u7EAA\u8981",icon:"\u{1F5D2}\uFE0F",description:"\u6807\u9898 + \u51FA\u5E2D + \u8BAE\u7A0B + \u51B3\u8BAE + action items + \u4E0B\u6B21",category:"doc",body:`\u3010\u6A21\u677F: \u4F1A\u8BAE\u7EAA\u8981\u3011
\u3010\u610F\u56FE\u3011\u73B0\u4EE3\u4F1A\u8BAE\u7EAA\u8981, \u5F3A action items\u3002
\u3010\u5E03\u5C40\u3011
- Title bar (\u4F1A\u8BAE\u540D + \u65F6\u95F4 + \u51FA\u5E2D avatars)
- Agenda checklist
- Decisions block (\u5706\u89D2\u5361\u7247)
- Action items table (Owner / Due / Status)
- Next meeting footer`,enName:"Meeting Notes",scenario:"operations",aspectHint:"\u957F\u9875\u9762",tags:["minutes","meeting","1:1","\u7EAA\u8981"]},{id:"docs-page",name:"\u6280\u672F\u6587\u6863\u9875",icon:"\u{1F4D8}",description:"\u4E09\u680F\u6587\u6863\u9875: \u4FA7\u5BFC\u822A + \u6B63\u6587 + \u53F3 TOC",category:"doc",body:`\u3010\u6A21\u677F: \u6280\u672F\u6587\u6863\u9875\u3011
\u3010\u610F\u56FE\u3011API / \u6559\u7A0B\u6587\u6863\u5355\u9875, \u957F\u8BFB\u4F53\u9A8C\u4F18\u5148\u3002
\u3010\u5E03\u5C40\u3011
- Inline-start nav (sections + sticky)
- Article body (\u542B\u4EE3\u7801\u5757, callouts, \u8868\u683C)
- Inline-end TOC (sticky, scroll-spy)
- \u9876\u680F search + version + \u4E3B\u9898\u5207\u6362
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u4EE3\u7801\u5757: \u5706\u89D2 + dark + \u8BED\u8A00\u6807\u7B7E + \u590D\u5236\u6309\u94AE
- callout: info / warn / danger \u4E09\u8272`,enName:"Docs Page",scenario:"engineering",aspectHint:"\u684C\u9762 1440",tags:["docs","api","tutorial","guide"]},{id:"competitive-teardown",name:"\u7ADE\u54C1\u62C6\u89E3",icon:"\u{1F9E9}",description:"\u5B9A\u4F4D\u56FE + \u529F\u80FD\u77E9\u9635 + \u4EF7\u683C\u5BF9\u6BD4 + \u673A\u4F1A\u7A97\u53E3, \u628A\u7ADE\u54C1\u8D44\u6599\u8F6C\u6210\u4EA7\u54C1\u51B3\u7B56\u62A5\u544A",category:"doc",body:`\u3010\u6A21\u677F: \u7ADE\u54C1\u62C6\u89E3 / Competitive Teardown\u3011
\u3010\u610F\u56FE\u3011\u8FD9\u4E0D\u662F\u6587\u7AE0\u3001\u4E0D\u662F PRD\u3001\u4E0D\u662F pitch deck\u3002\u76EE\u6807\u662F\u628A\u591A\u4E2A\u7ADE\u54C1\u7684\u6742\u4E71\u8D44\u6599\u8F6C\u6210\u4E00\u4EFD\u53EF\u51B3\u7B56\u7684\u4EA7\u54C1\u6218\u7565\u62A5\u544A, \u5E2E\u56E2\u961F\u56DE\u7B54: "\u6211\u4EEC\u548C\u5B83\u4EEC\u5230\u5E95\u5DEE\u5728\u54EA\u91CC, \u4E0B\u4E00\u6B65\u8BE5\u600E\u4E48\u6253?"

\u3010\u9002\u5408\u8F93\u5165\u3011
- \u7ADE\u54C1\u5B98\u7F51 / \u5B9A\u4EF7\u9875 / changelog / \u7528\u6237\u8BC4\u8BBA / \u9500\u552E\u53CD\u9988 / \u5185\u90E8\u8C03\u7814\u7B14\u8BB0
- 2-6 \u4E2A\u7ADE\u54C1\u6700\u5408\u9002; \u5982\u679C\u7528\u6237\u53EA\u7ED9\u4E00\u4E2A\u7ADE\u54C1, \u8F93\u51FA\u5355\u7ADE\u54C1 deep dive
- \u53EF\u4EE5\u5305\u542B\u8868\u683C\u3001bullet\u3001\u94FE\u63A5\u6458\u5F55\u3001\u8BBF\u8C08\u8BB0\u5F55\u3001\u622A\u56FE\u8BF4\u660E

\u3010\u5FC5\u987B\u8F93\u51FA\u7684\u7ED3\u6784\u3011
1. Header: \u5E02\u573A / \u4EA7\u54C1\u7C7B\u522B / \u62A5\u544A\u65E5\u671F / \u7ED3\u8BBA\u4E00\u53E5\u8BDD\u3002
2. Executive takeaway: 3 \u6761\u6700\u91CD\u8981\u5224\u65AD, \u6BCF\u6761\u5FC5\u987B\u5305\u542B "so what"\u3002
3. Positioning map: \u7528 2\xD72 \u8C61\u9650\u6216\u5750\u6807\u56FE\u8868\u73B0\u7ADE\u54C1\u5B9A\u4F4D\u3002\u5750\u6807\u8F74\u5FC5\u987B\u6765\u81EA\u7528\u6237\u5185\u5BB9, \u4E0D\u8981\u5957\u6A21\u677F\u8BCD\u3002
4. Competitor cards: \u6BCF\u4E2A\u7ADE\u54C1\u4E00\u5F20\u5361, \u5305\u542B target user\u3001core promise\u3001pricing signal\u3001primary strength\u3001visible weakness\u3002
5. Feature matrix: \u884C\u662F\u5173\u952E\u80FD\u529B, \u5217\u662F\u7ADE\u54C1 + "Us / Opportunity"; \u7528 \u2713 / \u25B3 / \u2014 \u8868\u8FBE\u8986\u76D6\u5EA6, \u5E76\u7528\u77ED\u6CE8\u91CA\u8BF4\u660E\u3002
6. Pricing / packaging read: \u4EF7\u683C\u5C42\u7EA7\u3001\u514D\u8D39\u8BD5\u7528\u3001\u9650\u5236\u9879\u3001\u4F01\u4E1A\u9500\u552E\u52A8\u4F5C\u3002
7. UX / messaging notes: \u4ECE\u7528\u6237\u6750\u6599\u4E2D\u62BD\u53D6 4-6 \u6761\u53EF\u89C2\u5BDF\u7EC6\u8282, \u4E0D\u8981\u6CDB\u6CDB\u800C\u8C08\u3002
8. Opportunity windows: 3 \u4E2A\u673A\u4F1A\u7A97\u53E3, \u6BCF\u4E2A\u5305\u542B why now\u3001target segment\u3001first move\u3001risk\u3002
9. Recommended moves: \u8FD1\u671F 30 \u5929 / 90 \u5929 / 180 \u5929\u884C\u52A8\u5EFA\u8BAE\u3002

\u3010\u8BBE\u8BA1\u8981\u6C42\u3011
- \u6218\u7565\u54A8\u8BE2 + \u4EA7\u54C1\u6218\u60C5\u5BA4\u98CE\u683C: \u4FE1\u606F\u5BC6\u5EA6\u9AD8\u3001\u626B\u63CF\u5FEB\u3001\u56FE\u8868\u6E05\u695A\u3002
- \u4F7F\u7528 restrained palette: ink / paper / muted blue / signal amber \u6216\u7C7B\u4F3C\u4E13\u4E1A\u8272\u3002
- Feature matrix \u5FC5\u987B\u6A2A\u5411\u53EF\u8BFB; \u5C0F\u5C4F\u53EF\u53D8\u6210 stacked cards\u3002
- \u4E0D\u8981\u505A\u6210\u8425\u9500\u843D\u5730\u9875, \u4E0D\u8981\u505A\u6210\u666E\u901A\u6587\u7AE0\u3002

\u3010\u53EF\u9009\u98CE\u683C\u6A21\u677F \u2014 \u53C2\u8003 assets/\u3011
\u6839\u636E\u7528\u6237\u5185\u5BB9\u9009\u62E9\u6700\u8D34\u5408\u7684\u4E00\u79CD, \u4E0D\u8981\u4E09\u79CD\u6DF7\u7528:
- \`assets/war-room-grid.html\`: \u9ED8\u8BA4\u98CE\u683C\u3002\u6D45\u8272\u6218\u60C5\u5BA4 / \u54A8\u8BE2\u62A5\u544A, \u9002\u5408\u4EA7\u54C1\u56E2\u961F\u3001PM\u3001\u666E\u901A\u5546\u4E1A\u8BFB\u8005\u3002
- \`assets/radar-map.html\`: \u6DF1\u8272\u96F7\u8FBE\u56FE / market intelligence console, \u9002\u5408\u5B89\u5168\u3001AI\u3001\u5F00\u53D1\u8005\u5DE5\u5177\u3001\u5E73\u53F0\u578B\u7ADE\u54C1\u3002
- \`assets/analyst-dossier.html\`: \u7EB8\u8D28\u5206\u6790\u6863\u6848 / investment research dossier, \u9002\u5408\u6295\u7814\u3001\u884C\u4E1A\u5206\u6790\u3001\u6B63\u5F0F\u6218\u7565\u5907\u5FD8\u3002

\u5982\u679C\u7528\u6237\u6CA1\u6709\u6307\u5B9A\u98CE\u683C, \u4F18\u5148\u4F7F\u7528 \`war-room-grid\`; \u5982\u679C\u8F93\u5165\u5F3A\u8C03\u5E02\u573A\u683C\u5C40\u3001\u6280\u672F\u96F7\u8FBE\u3001\u653B\u9632\u6001\u52BF, \u4F7F\u7528 \`radar-map\`; \u5982\u679C\u8F93\u5165\u50CF\u7814\u7A76\u7B14\u8BB0\u3001\u6295\u8D44\u5907\u5FD8\u6216\u884C\u4E1A\u62A5\u544A, \u4F7F\u7528 \`analyst-dossier\`\u3002

\u3010\u5185\u5BB9\u771F\u5B9E\u6027\u3011
- \u53EA\u4F7F\u7528\u7528\u6237\u63D0\u4F9B\u7684\u7ADE\u54C1\u3001\u4EF7\u683C\u3001\u529F\u80FD\u3001\u8BC4\u8BBA\u3002\u7F3A\u5931\u4FE1\u606F\u7528 "not found in source" \u6216 "unknown" \u6807\u6CE8\u3002
- \u4E0D\u8981\u53D1\u660E\u5E02\u573A\u4EFD\u989D\u3001ARR\u3001\u5BA2\u6237\u540D\u3001\u5B9A\u4EF7\u6570\u5B57\u3002
- \u5982\u679C\u7528\u6237\u8D44\u6599\u660E\u663E\u4E0D\u8DB3, \u4ECD\u7136\u8F93\u51FA\u62A5\u544A, \u4F46\u5728 "Evidence gaps" \u4E2D\u5217\u51FA\u7F3A\u53E3\u3002`,enName:"Competitive Teardown",scenario:"product",aspectHint:"\u6218\u7565\u957F\u9875\u9762",tags:["competitive","teardown","strategy","product","\u7ADE\u54C1","\u62C6\u89E3"]},{id:"hr-onboarding",name:"\u65B0\u5458\u5DE5\u5165\u804C\u9875",icon:"\u{1F44B}",description:"\u9996\u5468\u65E5\u7A0B + buddy + \u5B66\u4E60\u8DEF\u5F84 + \u8BBE\u5907 + \u5B8C\u6210\u6807\u51C6",category:"doc",body:`\u3010\u6A21\u677F: \u65B0\u5458\u5DE5\u5165\u804C\u3011
\u3010\u610F\u56FE\u3011\u65B0\u5458\u5DE5\u9996\u5468\u770B\u4E00\u773C\u5C31\u77E5\u9053\u600E\u4E48\u8FC7\u7684\u5355\u9875\u3002
\u3010\u5E03\u5C40\u3011
- Welcome hero (\u59D3\u540D + \u5165\u804C\u65E5 + \u56E2\u961F)
- First-week schedule (5 \u5929 timeline)
- Manager + Buddy \u5361\u7247
- Learning track \u5217\u8868
- Equipment checklist
- \u201C\u4F60\u8BBE\u7F6E\u597D\u4E86\u5F53\u4E14\u4EC5\u5F53\u2026\u201D outcomes \u533A`,enName:"HR Onboarding",scenario:"hr",aspectHint:"\u957F\u9875\u9762",tags:["onboarding","\u5165\u804C","first week"]},{id:"doc-kami-parchment",name:"Kami \u7F8A\u76AE\u7EB8\u6587\u6863",icon:"\u{1F4DC}",description:"\u6696\u7F8A\u76AE\u7EB8\u5E95 (#f5f4ed) + \u58A8\u84DD\u5355\u8272 accent (#1B365D) + \u5355\u4E00\u886C\u7EBF\u5B57\u4F53, \u7F16\u8F91\u7EA7\u6392\u5370",category:"doc",body:'\u3010\u6A21\u677F: Kami \u7F8A\u76AE\u7EB8\u6587\u6863\u3011\n\u3010\u610F\u56FE\u3011\u4E25\u8083\u6392\u7248\u6587\u6863: one-pager / \u957F\u62A5\u544A / \u4FE1\u51FD / \u7B80\u5386 / \u8D22\u62A5 / changelog / portfolio\u3002Inspired by tw93/kami\u3002\u5F3A\u8C03"\u5199\u5F97\u50CF\u88AB\u6392\u8FC7\u7248\u7684\u7EB8", \u4E0D\u662F dashboard, \u4E0D\u662F\u7F51\u9875\u3002\n\n\u3010\u786C\u6027\u89C6\u89C9\u7B7E\u540D \u2014 \u4E0D\u8BB8\u6539\u3011\n- **\u753B\u5E03**: \u6696\u7F8A\u76AE\u7EB8 `#f5f4ed` (\u6C38\u8FDC\u4E0D\u7528\u7EAF\u767D `#fff`)\u3002\u6B21\u7EA7\u80CC\u666F `#efeee5`\u3002\n- **\u58A8\u8272**: \u4E3B\u6587\u5B57 `#1f1d18` (\u8FD1\u9ED1\u6696\u7070, \u4E0D\u7528\u7EAF\u9ED1 `#000`)\u3002\u6B21\u6587\u5B57 `#6b665b`\u3002\n- **\u552F\u4E00\u8272\u5F69**: \u58A8\u84DD `#1B365D` \u2014\u2014\u6240\u6709 accent (\u94FE\u63A5\u3001tag \u63CF\u8FB9\u3001\u91CD\u70B9\u6570\u5B57\u3001\u5F15\u7528\u5DE6 rule) \u53EA\u80FD\u7528\u8FD9\u4E00\u4E2A\u8272, \u4E25\u7981\u591A\u8272\u3002\n- **\u5B57\u4F53**: \u4E00\u79CD\u8BED\u8A00\u4E00\u79CD\u886C\u7EBF, \u5168\u6587\u4E0D\u6DF7\u7528:\n  - \u82F1\u6587: `Charter` (fallback: `Source Serif Pro`, `Iowan Old Style`)\n  - \u4E2D\u6587: `TsangerJinKai02 W04` (fallback: `Noto Serif SC`)\n  - \u65E5\u6587: `YuMincho` (fallback: `Noto Serif JP`)\n  - Body 400, Heading 500 (\u4E0D\u8981 700/800/900)\u3002\n- **\u884C\u9AD8**: \u6807\u9898 1.1\u20131.3, \u7D27\u51D1\u6B63\u6587 1.4\u20131.45, \u9605\u8BFB\u578B\u6B63\u6587 1.5\u20131.55\u3002\n- **\u7EDD\u4E0D**: drop-shadow / blur / \u5706\u89D2 \u2265 8px / \u6E10\u53D8 / \u9713\u8679\u8272 / rgba (\u7528 solid hex)\u3002\n- **\u7EC6\u8282**: tag \u7528 solid hex \u80CC\u666F\u65B9\u5757 (\u56E0\u4E3A WeasyPrint \u4E0D\u6E32\u67D3 rgba \u597D); \u5355\u7EBF\u51E0\u4F55 icon; \u8FB9\u7F18 1px hairline `#d4d1c5` rule, \u957F\u5EA6\u53D7\u63A7\u4E0D\u5230\u8FB9\u3002\n\n\u3010\u53EF\u9009\u6587\u6863\u7C7B\u578B \u2014 \u6309\u7528\u6237\u5185\u5BB9\u5224\u65AD\u3011\n- **One-Pager** \u2014 \u9876 logotype (Charter italic) + \u6807\u9898 + lede + 3 \u5217\u8981\u70B9 + \u5E95\u811A metadata\u3002\n- **Long Doc** \u2014 \u5C01\u9762\u9875 (\u5927\u6807\u9898 + \u526F\u6807 + \u4F5C\u8005 + \u65E5\u671F) \u2192 \u76EE\u5F55 (kicker + page no.) \u2192 \u7AE0\u8282 (folio \u9876\u89D2 + section rule + body) \u2192 \u6CE8\u91CA\u811A\u6CE8 + \u6587\u672B colophon\u3002\n- **Letter** \u2014 \u62AC\u5934\u5730\u5740 + \u65E5\u671F + \u6536\u4EF6\u4EBA + \u6B63\u6587 (\u5DE6\u5BF9\u9F50, \u6BB5\u95F4\u7A7A 1.5em) + \u7F72\u540D + \u7B7E\u540D\u5360\u4F4D\u7EBF\u3002\n- **Portfolio** \u2014 \u9879\u76EE hero (\u5927\u6807\u9898 + sub) + 1 \u5F20\u5168\u5E45\u56FE (\u7528 CSS \u5757\u7ED8\u5236\u5360\u4F4D) + \u9879\u76EE\u63CF\u8FF0 + \u89D2\u8272 / \u65F6\u95F4 / stack \u5143\u6570\u636E row\u3002\n- **Resume** \u2014 \u9876\u90E8\u59D3\u540D (\u5927\u5B57) + tagline \u4E00\u884C + contact row + \u4E3B\u8981 section: experience (\u516C\u53F8 / \u65F6\u95F4 / \u804C\u4F4D / bullets) + skills + education\u3002\n- **Slides** \u2014 keynote \u98CE, \u9875\u6570\u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u51B3\u5B9A (\u77ED\u5185\u5BB9 6 \u9875\u8D77\u6B65, \u957F\u5185\u5BB9\u5E94\u66F4\u591A), \u6BCF\u9875\u6EE1\u94FA\u7F8A\u76AE\u7EB8, \u5927\u6807\u9898 + lede + \u89D2\u6807 page no., \u7B80\u6D01\u5230\u53EA\u6709"\u88AB\u5370\u51FA\u6765"\u7684\u611F\u89C9\u3002\n- **Equity Report** \u2014 \u516C\u53F8\u540D + ticker + Q \xD7 \u5E74\u4EFD + key metrics row (revenue / margin / yoy) + body \u5206\u6790 + \u56FE\u8868 (SVG \u5355\u8272\u6298\u7EBF)\u3002\n- **Changelog** \u2014 \u7248\u672C\u53F7 (Charter italic \u5927\u5B57) + \u65E5\u671F + \u6539\u52A8\u5217\u8868 (Added / Changed / Fixed), \u5355 rule \u5206\u9694\u3002\n\n\u3010\u8BBE\u8BA1\u51C6\u5219\u3011\n- "Composed pages, not dashboards." \u4E0D\u8981\u5806 KPI \u5361, \u4E0D\u8981\u5806 emoji \u56FE\u6807, \u4E0D\u8981 hero gradient\u3002\n- "Ring or whisper only, no hard drop shadows." \u9634\u5F71\u53EA\u80FD\u662F `0 0 0 1px #d4d1c5` \u8FD9\u79CD hairline \u63CF\u8FB9\u3002\n- \u6587\u5B57\u5C42\u7EA7\u9760**\u886C\u7EBF\u5BF9\u6BD4 + \u5B57\u53F7 + \u7559\u767D**, \u4E0D\u9760\u989C\u8272\u3002\n- \u5355\u6587\u4EF6 HTML, \u7528 Tailwind CDN; \u5168\u6587\u4E2D\u82F1\u6DF7\u6392\u65F6\u52A0\u76D8\u53E4\u4E4B\u767D; \u4E0D\u8981\u5916\u94FE\u56FE\u7247, \u5360\u4F4D\u7528 paper-tint \u8272\u5757 + 1px ink \u63CF\u8FB9\u3002',enName:"Kami Parchment Document",scenario:"personal",aspectHint:"A4 / Letter \u957F\u9875",tags:["kami","parchment","serif","editorial","report","letter","one-pager"]},{id:"pm-spec",name:"PRD / \u4EA7\u54C1 Spec",icon:"\u{1F9ED}",description:"\u95EE\u9898 + \u6210\u529F\u6307\u6807 + \u8303\u56F4 + user stories + \u8BBE\u8BA1 + \u53D1\u5E03 + \u5F85\u89E3\u51B3",category:"doc",body:`\u3010\u6A21\u677F: PRD / Product Spec\u3011
\u3010\u610F\u56FE\u3011\u4EA7\u54C1\u9700\u6C42\u6587\u6863\u5355\u9875, \u7ED3\u6784\u6E05\u6670\u3002
\u3010\u5E03\u5C40\u3011
- Title bar + \u72B6\u6001 pill (draft/approved/shipped)
- Problem & Why now
- Success metrics (3-5 \u4E2A KPI)
- Scope (in / out)
- User stories (Given/When/Then)
- Design notes (\u542B\u5360\u4F4D mockup)
- Rollout plan + Open questions`,enName:"Product Spec / PRD",scenario:"product",aspectHint:"\u957F\u9875\u9762",tags:["prd","spec","\u9700\u6C42","product"]},{id:"email-marketing",name:"\u8425\u9500\u90AE\u4EF6",icon:"\u{1F4E7}",description:"\u4EA7\u54C1\u53D1\u5E03\u90AE\u4EF6, \u542B masthead\u3001hero\u3001CTA\u3001\u89C4\u683C\u8868, table-fallback",category:"email",body:`\u3010\u6A21\u677F: \u54C1\u724C\u4EA7\u54C1\u53D1\u5E03\u90AE\u4EF6\u3011
\u3010\u610F\u56FE\u3011\u7EAF HTML \u90AE\u4EF6, 600px \u5355\u680F, \u517C\u5BB9\u90AE\u4EF6\u5BA2\u6237\u7AEF\u3002
\u3010\u5E03\u5C40\u3011
- Masthead (wordmark \u5C45\u4E2D)
- Hero \u56FE\u5757 (SVG \u5360\u4F4D)
- Headline lockup (\u542B skewed-italic accent)
- Body copy + primary CTA \u6309\u94AE
- Specifications grid (3 \u5217)
- Footer (\u793E\u4EA4 + \u9000\u8BA2)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u4F7F\u7528 \`<table role='presentation'>\` \u505A\u5E03\u5C40\u515C\u5E95
- \u989C\u8272\u7528 inline style (\u4E0D\u8981\u4F9D\u8D56 class)`,enName:"Marketing Email",scenario:"marketing",aspectHint:"600 \u90AE\u4EF6\u5BBD",tags:["email","newsletter","mjml"]},{id:"finance-report",name:"\u5B63\u5EA6\u8D22\u62A5",icon:"\u{1F4BC}",description:"Masthead + KPI + \u6536\u5165/\u70E7\u94B1\u56FE + P&L \u8868 + \u91CD\u70B9 + \u5C55\u671B",category:"finance",body:`\u3010\u6A21\u677F: \u5B63\u5EA6\u8D22\u62A5 / Finance Report\u3011
\u3010\u610F\u56FE\u3011\u8D22\u52A1\u5411\u5355\u9875\u62A5\u544A, \u6570\u5B57 + \u56FE\u8868 + \u6587\u5B57\u6D1E\u5BDF\u3002
\u3010\u5E03\u5C40\u3011
- Masthead (\u516C\u53F8 + Q + \u62A5\u544A\u6807\u9898) + 4 \u4E2A hero KPI
- Revenue chart + Burn chart (Chart.js / ECharts)
- P&L \u6982\u8981\u8868 (zebra + sticky header)
- Top-line highlights (5 \u6761 bullet)
- Outlook \u6BB5\u843D
- Methodology \u6298\u53E0\u533A`,enName:"Finance Report",scenario:"finance",aspectHint:"\u957F\u9875\u9762",tags:["financial","p&l","mrr","\u8D22\u62A5"]},{id:"invoice",name:"\u53EF\u6253\u5370\u53D1\u7968",icon:"\u{1F9FE}",description:"\u6807\u51C6\u53D1\u7968: \u5BC4\u4EF6/\u6536\u4EF6 + \u660E\u7EC6 + \u7A0E + \u603B\u989D + \u4ED8\u6B3E\u6307\u5F15",category:"finance",body:`\u3010\u6A21\u677F: \u53EF\u6253\u5370\u53D1\u7968\u3011
\u3010\u610F\u56FE\u3011A4 \u53EF\u6253\u5370\u7684\u53D1\u7968\u5355\u9875\u3002
\u3010\u5E03\u5C40\u3011
- Header: \u53D1\u7968\u53F7 / \u65E5\u671F / \u622A\u6B62\u65E5
- From / Bill to \u4E24\u5757
- Line items table (\u63CF\u8FF0 / \u6570\u91CF / \u5355\u4EF7 / \u91D1\u989D)
- Tax breakdown + Totals (\u53F3\u5BF9\u9F50)
- Payment instructions \u533A
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- @media print \u6837\u5F0F; \u989C\u8272\u5BF9\u6BD4\u4FDD\u7559`,enName:"Printable Invoice",scenario:"finance",aspectHint:"A4",tags:["invoice","bill","\u53D1\u7968"]},{id:"gamified-app",name:"\u6E38\u620F\u5316 App \u591A\u5C4F",icon:"\u{1F579}\uFE0F",description:"\u4E09\u5C4F: \u5C01\u9762 / \u4ECA\u65E5\u4EFB\u52A1\u5E26 XP / \u4EFB\u52A1\u8BE6\u60C5, \u6697\u8272\u821E\u53F0",category:"mobile",body:`\u3010\u6A21\u677F: \u6E38\u620F\u5316 App / Quest UI\u3011
\u3010\u610F\u56FE\u3011\u7C7B RPG \u4E60\u60EF\u517B\u6210 app, dark showcase stage \u4E0A\u4E09\u4E2A phone frame\u3002
\u3010\u5E03\u5C40\u3011
- Frame 1: Cover / Poster
- Frame 2: Today's quests + XP ribbon + level bar
- Frame 3: Quest detail (\u5B50\u4EFB\u52A1 + \u5956\u52B1)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u9192\u76EE\u7684 quest tile \u6E10\u53D8 + \u7B49\u7EA7 ribbon + \u5E95\u90E8 tab bar`,enName:"Gamified App",scenario:"personal",aspectHint:"3 \xD7 iPhone",tags:["gamified","habit","rpg","quest","xp"]},{id:"mobile-onboarding",name:"App \u5F15\u5BFC\u591A\u5C4F",icon:"\u{1FA82}",description:"\u4E09\u4E2A\u624B\u673A\u6846\u5E76\u6392: splash / value-prop / sign-in",category:"mobile",body:`\u3010\u6A21\u677F: App \u5F15\u5BFC\u4E09\u5C4F\u3011
\u3010\u610F\u56FE\u3011\u5E76\u6392\u5C55\u793A\u4E09\u4E2A mobile onboarding \u5173\u952E\u5C4F\u3002
\u3010\u5E03\u5C40\u3011
- Phone 1: Splash (logo + tagline)
- Phone 2: Value-prop (illustration + 1 \u53E5 + dot indicators)
- Phone 3: Sign-in (email / Apple / Google + \u4E3B CTA)`,enName:"Mobile Onboarding",scenario:"design",aspectHint:"3 \xD7 iPhone",tags:["onboarding","ios","signup","\u5F15\u5BFC"]},{id:"mobile-app",name:"iPhone App \u5355\u5C4F",icon:"\u{1F4F2}",description:"\u50CF\u7D20\u7EA7 iPhone 15 Pro \u8FB9\u6846, \u4E00\u5C4F app \u622A\u56FE",category:"mobile",body:`\u3010\u6A21\u677F: iPhone \u5355\u5C4F App\u3011
\u3010\u610F\u56FE\u3011\u4E00\u4E2A\u5C4F\u5E55\u7684 mobile app \u8BBE\u8BA1, \u653E\u5728\u50CF\u7D20\u7EA7 iPhone 15 Pro frame \u91CC\u3002
\u3010\u5E03\u5C40\u3011
- Status bar (\u65F6\u95F4 + \u7535\u6C60 + \u4FE1\u53F7)
- App header (\u6807\u9898 / \u5934\u50CF / \u641C\u7D22)
- Main content (\u4E00\u4E2A\u6E05\u6670\u7684 archetype: feed / list / detail / form)
- Bottom tab bar (4-5 tab)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u771F\u5B9E\u7684 dynamic island; safe-area \u7559\u767D`,enName:"Mobile App Screen",scenario:"design",aspectHint:"iPhone 15 Pro frame",tags:["mobile","ios","app","phone"]},{id:"frame-liquid-bg-hero",name:"\u6D41\u4F53\u80CC\u666F Hero \u5E27",icon:"\u{1F30A}",description:"WebGL \u98CE\u6D41\u4F53\u7F6E\u6362\u80CC\u666F + \u9876\u90E8\u53E0\u52A0\u91D1\u53E5, \u9002\u5408\u89C6\u9891\u7247\u5934 / landing hero / \u6D77\u62A5",category:"poster",body:"\u3010\u6A21\u677F: \u6D41\u4F53\u80CC\u666F Hero\u3011\n\u3010\u610F\u56FE\u3011\u53EF\u4F5C\u4E3A\u89C6\u9891\u7247\u5934\u5E27\u3001SaaS landing \u9876\u90E8 hero\u3001\u6D77\u62A5\u5E95\u56FE\u3002WebGL \u6D41\u4F53\u611F, \u4F46\u7528 CSS / canvas \u9000\u5316\u7ED8\u5236, \u786E\u4FDD\u5355\u6587\u4EF6\u53EF\u53CC\u51FB\u6253\u5F00\u3002Inspired by hyperframes vfx-liquid-background\u3002\n\n\u3010\u753B\u5E03\u30111920\xD71080 (\u6A2A) \u6216 1080\xD71920 (\u7AD6), \u4E8C\u9009\u4E00\u3002\u80CC\u666F\u5360\u6EE1\u3002\n\n\u3010\u6D41\u4F53\u80CC\u666F \u2014 3 \u79CD\u5B9E\u73B0, \u6309\u7528\u6237\u504F\u597D\u9009\u3011\n1. **CSS \u591A\u5C42 radial-gradient \u9519\u4F4D\u547C\u5438** (\u6700\u7A33, \u9ED8\u8BA4\u63A8\u8350):\n   - 3-5 \u4E2A\u5927\u692D\u5706 `radial-gradient(...)`, \u989C\u8272\u53D6\u81EA\u8C03\u8272\u677F\u3002\n   - \u6BCF\u4E2A\u692D\u5706\u5957 `@keyframes` \u5E73\u79FB + scale + hue-rotate, \u5468\u671F 8-14s, \u9519\u5CF0; \u6574\u4E2A\u753B\u9762\u53E0 `mix-blend-mode: screen` \u6216 `overlay`\u3002\n   - \u9876\u5C42\u52A0 1 \u5C42 `backdrop-filter: blur(80px)` \u8BA9\u8FB9\u7F18\u66F4\u7CCA\u3002\n2. **Canvas + simple perlin noise** (\u4E2D\u9636):\n   - 80 \u884C inline JS, \u7528 `requestAnimationFrame` \u753B metaballs \u6216 simplex noise field\u3002\n   - \u6027\u80FD\u5141\u8BB8\u65F6\u542F\u7528, `prefers-reduced-motion` \u65F6\u964D\u56DE\u9759\u6001\u622A\u56FE\u3002\n3. **WebGL fragment shader** (\u9AD8\u9636, \u614E\u7528):\n   - \u7528 jsdelivr CDN \u5F15 `regl` \u6216 inline plain WebGL\u3002\n   - shader \u5199 domain-warp noise; \u5355\u4E2A quad, \u4E00\u4E2A uniform `u_time`\u3002\n\n\u3010\u9876\u5C42\u6587\u5B57\u5C42\u3011\n- \u5C45\u4E2D\u6216\u5DE6\u4E0B: \u4E00\u53E5\u5DE8\u578B\u91D1\u53E5 (5-7vw, \u886C\u7EBF\u6216\u7C97 sans), \u5B57\u4F53: `Source Serif Pro` / `Inter Tight` / `Manrope Black`\u3002\n- \u6587\u5B57\u8272\u7528 paper white `#fafaf8` \u6216 ink, \u53D6\u51B3\u4E8E\u80CC\u666F\u660E\u6697; \u52A0 `mix-blend-mode: difference` \u8BA9\u5B83\u5728\u4EFB\u4F55\u6D41\u4F53\u989C\u8272\u4E0A\u90FD\u53EF\u8BFB\u3002\n- \u526F\u6807 (\u5C0F sans, opacity 0.7) \u4E00\u884C\u3002\n- \u5E95\u90E8\u53EF\u9009 CTA chip \u6216 hairline + \u5143\u6570\u636E row\u3002\n\n\u3010\u8C03\u8272 \u2014 4 \u9009 1, \u4E0D\u8981\u5F69\u8679\u3011\n- \u{1F305} **Solar Peach** \u2014 `#ffb18a` + `#f78b4c` + `#d97757`, \u6696\u6A59\u6843\u3002\n- \u{1F30A} **Ocean Aqua** \u2014 `#5ac8fa` + `#0a84ff` + `#1e3a8a`, \u6D77\u84DD\u3002\n- \u{1F30C} **Aurora Violet** \u2014 `#a78bfa` + `#7c5cff` + `#1e1b4b`, \u6781\u5149\u7D2B\u3002\n- \u{1F33F} **Forest Mint** \u2014 `#86efac` + `#34d399` + `#065f46`, \u82D4\u68EE\u6797\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- \u4E25\u7981: \u591A\u8272\u5F69\u8679 (>4 \u4E2A\u8272\u76F8)\u3001PowerPoint \u6E10\u53D8\u3001\u9713\u8679\u8367\u5149\u53E0\u52A0\u3002\n- \u5B57\u4F53: \u4E2D\u6587\u7528 `Noto Serif SC` (display) / `Noto Sans SC` (\u526F\u6807)\u3002\n- \u4E25\u7981\u5916\u94FE\u56FE\u7247; \u5168\u90E8 CSS + SVG + \u53EF\u9009 canvas\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u63D0\u4F9B\u7684\u91D1\u53E5 / \u6807\u9898; \u5982\u679C\u7528\u6237\u8F93\u5165\u662F\u6570\u636E \u2192 \u63D0\u70BC\u4E00\u53E5 \u2264 18 \u5B57\u7684\u91D1\u53E5\u3002\n- \u5355\u6587\u4EF6 HTML, \u53EF\u88AB `prefers-reduced-motion` \u5173\u52A8\u6548\u3002",enName:"Liquid Background Hero",scenario:"video",aspectHint:"1920\xD71080 (16:9) \u6216 1080\xD71920 (9:16)",tags:["liquid","fluid","background","hero","html-in-canvas","vfx"]},{id:"sprite-animation",name:"\u50CF\u7D20\u52A8\u753B\u89E3\u8BF4",icon:"\u{1F579}\uFE0F",description:"\u50CF\u7D20\u7F8E\u672F + kinetic \u5B57\u4F53\u7684\u89E3\u8BF4\u5E27, \u7EAF CSS \u5FAA\u73AF, \u53EF\u5F55\u89C6\u9891",category:"poster",body:`\u3010\u6A21\u677F: \u50CF\u7D20 / 8-bit \u52A8\u753B\u89E3\u8BF4\u3011
\u3010\u610F\u56FE\u3011\u6559\u80B2\u578B\u52A8\u753B\u7684\u5355\u5E27\u6D77\u62A5, \u7EAF CSS keyframes \u5FAA\u73AF, \u4E0D\u7528 JS\u3002
\u3010\u5E03\u5C40\u3011
- Full-bleed cream stage
- Bold display year / \u5927\u5B57\u6570\u5B57
- \u4E2D\u5FC3\u4E00\u4E2A\u50CF\u7D20\u827A\u672F mascot (SVG \u6216\u7EAF CSS \u7ED8\u5236)
- kinetic \u4E2D\u6587 / \u65E5\u6587 display \u5B57
- \u5E95\u90E8 timeline ribbon \u4E00\u76F4\u8D70
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u52A8\u753B\u7528 @keyframes, \u4E0D\u4F9D\u8D56 JS
- \u590D\u53E4\u8C03\u8272\u677F: \u7EA2 / \u7C73 / \u58A8\u7EFF`,enName:"Sprite Animation",scenario:"marketing",aspectHint:"\u7AD6\u7248/\u6A2A\u7248\u5747\u53EF",tags:["pixel","8-bit","\u590D\u53E4","explainer"]},{id:"poster-hero",name:"\u8425\u9500\u6D77\u62A5",icon:"\u{1F5BC}\uFE0F",description:"\u7AD6\u7248\u6D77\u62A5 / \u670B\u53CB\u5708\u5206\u4EAB\u56FE, \u5F3A\u89C6\u89C9\u51B2\u51FB",category:"poster",body:`\u3010\u6A21\u677F: \u8425\u9500\u6D77\u62A5\u3011
- \u5BB9\u5668 \`w-[1080px] h-[1920px] mx-auto\`, \u5168\u5C4F\u6E10\u53D8 / mesh \u80CC\u666F\u3002
- \u4E0A\u90E8 30% \u7559\u767D + \u4E00\u4E2A\u5927 emoji \u6216\u62BD\u8C61\u51E0\u4F55\u56FE\u5F62\u3002
- \u4E2D\u90E8\u4E3B\u6807\u9898\u5360\u89C6\u89C9\u4E2D\u5FC3 (text-8xl, font-black), \u4E00\u53E5\u8BDD\u526F\u6807\u9898\u3002
- \u4E0B\u90E8\u4FE1\u606F\u5361\u7247: 3-5 \u6761\u6838\u5FC3\u8981\u70B9\u7528\u56FE\u6807 + \u77ED\u53E5\u3002
- \u5E95\u90E8\u53F3\u4E0B\u89D2\u653E\u54C1\u724C / \u4E8C\u7EF4\u7801 (\u7528 SVG \u5360\u4F4D)\u3002
- \u4F7F\u7528\u5927\u80C6\u7684\u8272\u5F69: \u6E10\u53D8\u80CC\u666F (from-violet-500 via-fuchsia-500 to-indigo-500 \u4E4B\u7C7B), \u6587\u5B57\u767D\u8272 + 1 \u4E2A\u5BF9\u6BD4\u8272\u9AD8\u4EAE\u3002
- \u4F7F\u7528 SVG \u505A\u88C5\u9970\u6027\u5143\u7D20 (\u5706 / \u4E09\u89D2 / \u6CE2\u6D6A / \u566A\u70B9\u7EB9\u7406)\u3002`,enName:"Marketing Poster",scenario:"marketing",aspectHint:"1080\xD71920 \u7AD6\u7248",tags:["poster","\u6D77\u62A5","\u670B\u53CB\u5708"]},{id:"magazine-poster",name:"\u6742\u5FD7\u98CE\u6D77\u62A5",icon:"\u{1F5DE}\uFE0F",description:"Sunday-paper \u98CE\u683C, \u5927\u5B57 serif headline + \u53CC\u680F\u6B63\u6587 + \u7F16\u53F7 sections",category:"poster",body:`\u3010\u6A21\u677F: \u6742\u5FD7\u98CE\u6D77\u62A5 / Magazine Poster\u3011
\u3010\u610F\u56FE\u3011Newsprint editorial \u98CE\u683C\u7684\u957F\u56FE\u6D77\u62A5, \u8BFB\u8D77\u6765\u50CF\u4E00\u7BC7\u62A5\u7EB8\u5168\u7248\u3002
\u3010\u5E03\u5C40\u3011
- Dateline \u9876\u680F (publication / date / issue)
- Oversized serif headline (\u542B strike-through \u8BCD + \u659C\u4F53 accent)
- \u53CC\u680F body \u6B63\u6587
- 6 \u4E2A\u7F16\u53F7 sections, \u6BCF\u4E2A\u542B\u5C0F\u6807\u9898 + 1-2 \u6BB5 + pull-quote
- \u5E95\u90E8\u7F72\u540D + \u5C0F ornament
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u7EB8\u611F: \u6696\u7070 cream \u80CC\u666F + \u7EC6 dot pattern, \u9ED1\u5B57
- \u5B57\u4F53: Playfair Display + IBM Plex Serif + JetBrains Mono`,enName:"Magazine Poster",scenario:"marketing",aspectHint:"\u7AD6\u7248\u957F\u56FE",tags:["magazine","newsprint","editorial","manifesto"]},{id:"mockup-device-3d",name:"iPhone \xD7 MacBook \u7ACB\u4F53\u5C55\u67B6",icon:"\u{1F4F1}",description:"iPhone + MacBook \u4EFF GLTF \u9759\u6001\u5C55\u67B6, \u5C4F\u5E55\u5185\u5D4C\u771F\u5B9E HTML \u5185\u5BB9, \u73BB\u7483\u955C\u5934\u6298\u5C04, 360\xB0 \u8F6C\u76D8\u6784\u56FE",category:"poster",body:`\u3010\u6A21\u677F: \u8BBE\u5907 3D \u5C55\u67B6 (Device 3D Showcase / HTML-in-Canvas)\u3011
\u3010\u610F\u56FE\u3011\u4EA7\u54C1\u53D1\u5E03\u3001App \u6F14\u793A\u3001\u8BBE\u8BA1\u7A3F\u5C55\u793A\u3002\u628A\u7528\u6237\u63D0\u4F9B\u7684 UI \u5185\u5BB9\u771F\u5B9E\u6E32\u67D3\u5230 iPhone / MacBook "\u5C4F\u5E55"\u91CC, \u5468\u56F4\u7528 CSS 3D transform \u6A21\u62DF GLTF \u6A21\u578B\u7684\u73BB\u7483 / \u9AD8\u5149 / \u6298\u5C04\u3002Inspired by hyperframes vfx-iphone-device\u3002

\u3010\u786C\u6027\u6784\u56FE\u3011
- **\u753B\u5E03**: 1920\xD71080, \u6696\u7070\u6E10\u53D8\u80CC\u666F \`radial-gradient(#1a1a1f \u2192 #0a0a0f)\`, \u5E95\u90E8\u53CD\u5C04\u5730\u9762 (mirror gradient)\u3002
- **iPhone 15 Pro \u6A21\u578B**: \u5DE6\u4FA7 / \u4E2D\u90E8, \`transform: rotateY(-12deg) rotateX(4deg) translateZ(40px)\`; \u8FB9\u6846\u949B\u91D1\u5C5E\u94F6 \`#a8a8ad\` (\u5B9E\u5FC3 4px) + \u5C4F\u5E55\u5706\u89D2 56px; \u5C4F\u5E55\u5185\u5D4C iframe-like div, \u771F\u5B9E\u6E32\u67D3\u7528\u6237\u7684 HTML \u5185\u5BB9 (mobile viewport 375\xD7812)\u3002
- **MacBook Pro 14"** (\u53EF\u9009\u7B2C\u4E8C\u53F0): \u53F3\u4FA7, \u7565\u5C0F, \`rotateY(8deg)\`; \u4E0A\u76D6\u5C4F\u5E55\u5D4C\u5165\u684C\u9762 viewport \u5185\u5BB9 (1440\xD7900 \u7F29\u653E); \u5E95\u5EA7\u952E\u76D8 + trackpad \u7528 CSS \u9634\u5F71\u7EBF\u6761\u7ED8\u5236 (\u4E0D\u753B\u952E\u5E3D\u7EC6\u8282)\u3002
- **\u73BB\u7483 / \u955C\u5934\u5149\u6591**: \u9876\u90E8\u52A0 2-3 \u4E2A \`radial-gradient(ellipse, rgba(255,255,255,0.4) 0%, transparent 60%)\` \u7684\u692D\u5706 highlight, \u6A21\u62DF morphing glass lens\u3002
- **\u5730\u9762\u53CD\u5C04**: \u8BBE\u5907\u4E0B\u65B9 \`transform: scaleY(-1)\` + \`mask-image: linear-gradient(to bottom, rgba(0,0,0,0.4), transparent 70%)\`\u3002

\u3010\u5C4F\u5E55\u5185\u5BB9\u6765\u6E90\u3011
- \u7528\u6237\u63D0\u4F9B\u7684\u662F\u6587\u672C/\u6570\u636E \u2192 \u81EA\u52A8\u6E32\u67D3\u4E3A\u4E00\u4E2A mock app \u754C\u9762 (\u9876\u90E8 status bar + \u6807\u9898 + body + \u5E95\u90E8 tab bar \u6216 home indicator)\u3002
- \u7528\u6237\u63D0\u4F9B\u7684\u662F HTML \u2192 \u539F\u6837\u5D4C\u5165\u5C4F\u5E55 div \u5185 (\u6CE8\u610F\u7F29\u653E transform \u8BA9\u5B83\u9002\u914D\u5C4F\u5E55\u5BBD\u9AD8)\u3002
- \u5C4F\u5E55\u5185 UI \u7528 Tailwind, \u5B57\u53F7\u8981\u6309 mobile \u771F\u5B9E\u5C3A\u5BF8 (text-sm / text-base, \u4E0D\u8981 text-9xl)\u3002

\u3010\u53EF\u9009\u9644\u52A0\u5143\u7D20\u3011
- \u53F3\u4E0B\u89D2 "product slug" \u89D2\u6807: \u5927 logo + \u4E00\u884C tagline + \u526F\u6807 hairline\u3002
- \u9876\u90E8\u4E00\u884C caption (\u82F1\u6587 sans, \u5B57\u53F7\u5C0F, \u900F\u660E 0.6): \u4EA7\u54C1 codename / \u65E5\u671F / \u7248\u672C\u3002
- \u52A0 8s \u81EA\u52A8 CSS \u8F6C\u76D8: \`@keyframes turntable\` rotateY -12 \u2194 12, ease-in-out infinite alternate; \u53EF\u88AB \`prefers-reduced-motion\` \u5173\u95ED\u3002

\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- **\u7EDD\u4E0D**: \u7528\u5916\u90E8 mockup \u56FE\u7247 URL (\u4EFB\u4F55 unsplash / dribbble link), \u5168\u90E8\u7528 CSS / SVG \u7ED8\u5236\u8BBE\u5907\u3002
- \u5B57\u4F53: \u8BBE\u5907\u5916\u7684 caption / logo \u7528 \`Inter Tight\` / \`SF Pro\` \u98CE\u683C; \u8BBE\u5907\u5185\u6839\u636E\u7528\u6237\u5185\u5BB9\u81EA\u9002\u5E94\u3002
- \u80CC\u666F\u53EF\u9009 4 \u5957\u8C03\u8272: charcoal / pearl / midnight blue / mocha; \u4E0D\u8981\u5F69\u8679\u6E10\u53D8\u3002
- \u5355\u6587\u4EF6 HTML; iframe \u4E0D\u8981\u7528 srcdoc \u5D4C\u5957 (\u5BB9\u6613\u51FA\u95EE\u9898), \u7528 \`<div class="screen">\` + Tailwind \u6E32\u67D3\u5185\u5BB9\u3002
- \u5FC5\u987B\u7528\u7528\u6237\u771F\u5B9E\u6570\u636E\u586B\u5145\u5C4F\u5E55\u5185\u5BB9, \u4E25\u7981 lorem ipsum \u6216 "Your text here"\u3002`,enName:"Device 3D Showcase",scenario:"product",aspectHint:"1920\xD71080 (16:9)",tags:["device","mockup","iphone","macbook","html-in-canvas","product"]},{id:"waitlist-page",name:"\u7B49\u5019\u540D\u5355\u9875",icon:"\u2709\uFE0F",description:"\u6781\u7B80\u4EA7\u54C1\u9884\u53D1\u5E03\u843D\u5730\u9875, \u542B\u90AE\u7BB1\u6355\u83B7\u3001logo\u3001\u88C5\u9970\u56FE\u5C42",category:"prototype",body:`\u3010\u6A21\u677F: \u7B49\u5019\u540D\u5355\u9875 / Waitlist\u3011
\u3010\u610F\u56FE\u3011\u4E3A\u65B0\u4EA7\u54C1 / \u65E9\u9E1F\u5185\u6D4B\u505A\u4E00\u5F20\u6781\u7B80\u7B49\u5019\u9875\u3002
\u3010\u5E03\u5C40\u3011
- \u5C45\u4E2D\u5E03\u5C40: brand logo + \u4E00\u884C tagline + \u5927\u5B57 hero (\u8BF4\u6E05\u695A\u505A\u4EC0\u4E48)
- \u90AE\u7BB1\u6355\u83B7 input + submit \u6309\u94AE (\u5408\u5E76\u6210\u4E00\u4E2A pill)
- \u4E0B\u65B9 3 \u4E2A\u5C0F\u5356\u70B9 (icon + \u4E00\u884C\u5B57)
- \u5E95\u90E8 founders note + \u793E\u4EA4\u94FE\u63A5
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u88C5\u9970: SVG \u6E10\u53D8 mesh / \u566A\u70B9\u7EB9\u7406 / \u4E00\u9897\u661F\u8F68
- \u6210\u529F\u63D0\u4EA4\u540E\u7ED9\u4E00\u4E2A\u5FAE\u52A8\u6548 (\u2713 + \u6587\u6848\u53D8\u5316)`,enName:"Waitlist Page",scenario:"marketing",aspectHint:"\u684C\u9762 1440",tags:["waitlist","launch","\u9884\u53D1\u5E03"]},{id:"pricing-page",name:"\u5B9A\u4EF7\u9875",icon:"\u{1F4B3}",description:"\u4E09\u6863\u5B9A\u4EF7 + \u7279\u6027\u5BF9\u6BD4\u8868 + FAQ",category:"prototype",body:`\u3010\u6A21\u677F: \u5B9A\u4EF7\u9875\u3011
\u3010\u610F\u56FE\u3011\u6807\u51C6 SaaS \u4E09\u6863\u5B9A\u4EF7\u9875, \u4E00\u773C\u5BF9\u9F50\u4EF7\u503C\u4E0E\u4EF7\u683C\u3002
\u3010\u5E03\u5C40\u3011
- Header + monthly/annual \u5207\u6362
- 3 \u6863\u5B9A\u4EF7\u5361\u7247 (Free / Pro / Enterprise), \u4E2D\u95F4\u6863 popular \u9AD8\u4EAE
- \u5B8C\u6574\u7279\u6027\u5BF9\u6BD4\u8868 (\u2713 / \u2013 / \u4E0D\u540C\u6863\u52FE)
- FAQ (details/summary)
- \u5E95\u90E8 CTA`,enName:"Pricing Page",scenario:"sales",aspectHint:"\u684C\u9762 1440",tags:["pricing","plans","\u5B9A\u4EF7"]},{id:"wireframe-sketch",name:"\u624B\u7ED8\u7EBF\u6846\u56FE",icon:"\u270F\uFE0F",description:"\u7F51\u683C\u80CC\u666F + marker \u7B14\u89E6 + \u591A tab + sticky note + scribble \u56FE\u8868",category:"prototype",body:`\u3010\u6A21\u677F: \u624B\u7ED8 Wireframe\u3011
\u3010\u610F\u56FE\u3011\u767D\u677F / \u8349\u7A3F\u524D\u9636\u6BB5\u7684 wireframe \u63A2\u7D22\u3002
\u3010\u5E03\u5C40\u3011
- Graph-paper \u80CC\u666F
- \u591A tab labels (variants \u6807\u7B7E)
- scribbled chart placeholders + hatched fills
- Sticky-note annotations (\u9EC4\u8272, \u65CB\u8F6C\u4E00\u70B9\u70B9)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u5B57\u4F53: Caveat / Architects Daughter; \u4E0D\u8981\u89C4\u89C4\u77E9\u77E9\u7684\u5BF9\u9F50`,enName:"Wireframe Sketch",scenario:"design",aspectHint:"\u684C\u9762 1440",tags:["wireframe","lo-fi","sketch","\u8349\u7A3F","\u624B\u7ED8"]},{id:"web-proto-soft",name:"Apple Soft \u539F\u578B",icon:"\u{1FAE7}",description:"Apple \u8C03: \u94F6/\u5976 canvas + \u53CC\u5C42\u659C\u9762\u5361\u7247 + button-in-button + spring",category:"prototype",body:`\u3010\u6A21\u677F: Apple Soft \u539F\u578B\u3011
\u3010\u610F\u56FE\u3011Apple-tier \u8F6F\u8D28\u611F, squircle + spring motion + ambient mesh\u3002
\u3010\u5E03\u5C40\u3011
- Silver / cream canvas + ambient mesh background
- Double-bezel \u5361\u7247 (\u5185\u5916\u4E24\u5C42\u5706\u89D2 + \u9AD8\u5149)
- Button-in-button CTA
- Spring motion (\u5FAE\u53CD\u5F39\u7684 hover)`,enName:"Apple-tier Soft Prototype",scenario:"design",aspectHint:"\u684C\u9762 1440",tags:["apple","soft","squircle","spring"]},{id:"web-proto-brutalist",name:"Brutalist \u539F\u578B",icon:"\u2B1B",description:"Swiss industrial-print \u98CE: \u5355\u5B57 grotesque\u3001\u5DE8\u6570\u5B57\u3001ASCII \u88C5\u9970",category:"prototype",body:`\u3010\u6A21\u677F: Brutalist \u7F51\u9875\u539F\u578B\u3011
\u3010\u610F\u56FE\u3011Swiss Industrial Print \u98CE\u683C, \u4E0D\u67D4\u548C\u4E0D\u53CB\u597D, \u5F3A\u6743\u5A01\u611F\u3002
\u3010\u5E03\u5C40\u3011
- Newsprint canvas + hairline grid dividers
- Monolithic black grotesque \u6807\u9898, viewport-bleeding \u5DE8\u6570\u5B57
- Hazard-red accent + ASCII \u88C5\u9970 (\u250C\u2500\u2518 \u7B49)
- Sections \u7528\u6781\u7B80\u6570\u5B57\u7F16\u53F7`,enName:"Brutalist Prototype",scenario:"design",aspectHint:"\u684C\u9762 1440",tags:["brutalist","swiss","industrial","hairline"]},{id:"web-proto-editorial",name:"Editorial \u539F\u578B",icon:"\u{1F4DC}",description:"Editorial-minimalist: \u6696\u8272\u5355\u8272 canvas + serif display + grotesque body",category:"prototype",body:`\u3010\u6A21\u677F: Editorial \u7F51\u9875\u539F\u578B\u3011
\u3010\u610F\u56FE\u3011\u6742\u5FD7\u611F minimalist, \u5927\u91CF\u7559\u767D + \u5FAE\u52A8\u6548\u3002
\u3010\u5E03\u5C40\u3011
- Warm monochrome canvas
- Serif display + grotesque body + mono meta
- 1px hairline borders, \u6781\u67D4\u548C chip
- Macro-whitespace, ambient micro-motion`,enName:"Editorial Prototype",scenario:"design",aspectHint:"\u684C\u9762 1440",tags:["editorial","minimalist","serif"]},{id:"saas-landing",name:"SaaS Landing",icon:"\u{1F680}",description:"\u5355\u9875 SaaS \u843D\u5730\u9875, \u542B hero/features/social-proof/pricing/CTA",category:"prototype",body:`\u3010\u6A21\u677F: SaaS Landing\u3011
\u3010\u610F\u56FE\u3011\u5B8C\u6574\u7684 SaaS \u4EA7\u54C1\u843D\u5730\u9875, \u628A\u7528\u6237\u5185\u5BB9\u6620\u5C04\u5230\u6807\u51C6 sections\u3002
\u3010\u5E03\u5C40\u3011
- Top nav (logo + \u5BFC\u822A + sign-in + \u4E3B CTA)
- Hero (\u5927\u6807\u9898 + \u526F\u6807 + \u53CC CTA + \u53EF\u89C6\u5316\u5360\u4F4D)
- Logo wall (\u793E\u4F1A\u8BA4\u8BC1)
- Features (3-6 \u4E2A\u7279\u6027\u5361, icon + \u6807\u9898 + \u63CF\u8FF0)
- How it works (3 \u6B65\u6D41\u7A0B, \u6570\u5B57 + \u6807\u9898 + \u63CF\u8FF0)
- Pricing (2-3 \u6863, \u63A8\u8350\u6863\u9AD8\u4EAE)
- FAQ (details/summary \u624B\u98CE\u7434)
- Footer
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u73B0\u4EE3 SaaS \u98CE: \u5927\u5B57\u53F7, \u67D4\u548C\u6E10\u53D8, glassmorphism \u5361\u7247, \u6EDA\u52A8\u5165\u573A\u52A8\u753B
- \u81F3\u5C11\u5904\u7406 \`md:\` \u65AD\u70B9, \u79FB\u52A8\u7AEF\u5355\u680F`,enName:"SaaS Landing",scenario:"marketing",aspectHint:"\u684C\u9762 1440",tags:["saas","landing","marketing"]},{id:"prototype-web",name:"Web \u4EA7\u54C1\u539F\u578B",icon:"\u{1F6E0}\uFE0F",description:"\u53EF\u70B9\u51FB\u7684\u529F\u80FD\u6027 Web \u539F\u578B, \u542B\u5BFC\u822A\u3001\u82F1\u96C4\u533A\u3001\u7279\u6027\u533A\u3001CTA",category:"prototype",body:`\u3010\u6A21\u677F: Web \u4EA7\u54C1\u539F\u578B\u3011
- \u8F93\u51FA\u4E00\u4E2A\u5B8C\u6574\u7684\u4EA7\u54C1 landing page\u3002
- Sections: Top Nav (logo + \u5BFC\u822A + CTA \u6309\u94AE) \u2192 Hero (\u5927\u6807\u9898 + \u526F\u6807 + \u53CC CTA + \u53EF\u89C6\u5316\u5360\u4F4D) \u2192 Features (3-6 \u4E2A\u7279\u6027\u5361) \u2192 How it works (\u6B65\u9AA4) \u2192 Social proof (logo wall / \u8BC4\u4EF7) \u2192 Pricing (\u53EF\u9009) \u2192 Footer\u3002
- \u4F7F\u7528\u73B0\u4EE3 SaaS \u8BBE\u8BA1\u8D8B\u52BF: \u5927\u5B57\u53F7\u3001\u67D4\u548C\u6E10\u53D8\u3001glassmorphism \u5361\u7247\u3001\u6EDA\u52A8\u5230\u89C6\u56FE\u5165\u573A\u52A8\u753B (pure CSS \u5373\u53EF)\u3002
- \u54CD\u5E94\u5F0F: \u79FB\u52A8\u7AEF\u5355\u680F, \u684C\u9762\u591A\u680F; \u81F3\u5C11\u5904\u7406 \`md:\` \u65AD\u70B9\u3002
- \u6DFB\u52A0\u4EA4\u4E92: nav \u6EDA\u52A8\u53D8\u8272; \u7279\u6027\u5361 hover \u6D6E\u8D77; FAQ \u53EF\u624B\u98CE\u7434\u5C55\u5F00 (\u7528 \`<details>\`)\u3002
- \u8FD9\u662F\u9AD8\u4FDD\u771F\u539F\u578B, \u5E94\u8BE5\u8BA9\u4EBA\u89C9\u5F97"\u660E\u5929\u5C31\u80FD\u4E0A\u7EBF"\u3002`,enName:"Web Prototype",scenario:"design",aspectHint:"1440\xD7900 \u684C\u9762",tags:["prototype","landing","\u539F\u578B"]},{id:"resume-modern",name:"\u6781\u7B80\u7B80\u5386",icon:"\u{1F4C4}",description:"\u73B0\u4EE3\u6781\u7B80\u7B80\u5386, A4 \u5355\u9875, \u9002\u5408\u6253\u5370\u6216\u5BFC\u51FA PDF",category:"resume",body:`\u3010\u6A21\u677F: \u73B0\u4EE3\u6781\u7B80\u7B80\u5386\u3011
- \u5BB9\u5668\u5BBD\u5EA6\u6A21\u62DF A4: \`w-[210mm] min-h-[297mm] mx-auto\`, \u5185\u8FB9\u8DDD 16-20mm\u3002
- \u9876\u90E8\u59D3\u540D\u5DE8\u5927 (text-4xl), \u5E95\u4E0B\u4E00\u884C contact (\u90AE\u7BB1 / \u7535\u8BDD / \u57CE\u5E02 / GitHub / LinkedIn), \u4E2D\u95F4\u7528\u7EC6\u7AD6\u7EBF\u5206\u9694\u3002
- \u4E3B\u4F53\u4E24\u680F\u53EF\u9009: \u5DE6 60% \u4E3B\u7EBF\uFF08\u7ECF\u5386/\u9879\u76EE/\u6559\u80B2\uFF09, \u53F3 40% \u526F\u7EBF\uFF08\u6280\u80FD/\u8BED\u8A00/\u83B7\u5956\uFF09\u3002
- \u7AE0\u8282\u6807\u9898: small caps \u98CE\u683C, \u4E0A\u65B9\u4E00\u6761\u77ED accent \u7EBF (w-8 h-0.5)\u3002
- \u7ECF\u5386\u6BCF\u6761: \u516C\u53F8 + \u804C\u4F4D + \u65F6\u95F4\u533A\u95F4 (\u53F3\u5BF9\u9F50), \u4E0B\u65B9 1-3 \u6761 bullet \u7528\u52A8\u8BCD\u5F00\u5934\u3002
- \u4E0D\u4F7F\u7528\u82B1\u54E8\u989C\u8272, \u9ED1\u767D\u7070 + 1 \u4E2A accent (\u6DF1\u84DD / \u58A8\u7EFF)\u3002
- \u6DFB\u52A0 @media print \u6837\u5F0F, \u9690\u85CF\u4E0D\u5FC5\u8981\u7684\u5143\u7D20, \u989C\u8272\u4FDD\u7559\u3002`,enName:"Modern Resume",scenario:"personal",aspectHint:"A4 (210\xD7297mm)",tags:["resume","cv","\u7B80\u5386"]},{id:"deck-open-slide-canvas",name:"1920 \u753B\u5E03\u81EA\u7531 Deck",icon:"\u{1F3A8}",description:"\u9501\u6B7B 1920\xD71080 \u753B\u5E03, React \u7EC4\u4EF6\u7EA7\u81EA\u7531\u7EC4\u5408, \u4E0D\u7ED1\u6A21\u677F",category:"slides",body:'\u3010\u6A21\u677F: 1920 \u753B\u5E03\u81EA\u7531 Deck\u3011\n\u3010\u610F\u56FE\u3011\u4E0D\u60F3\u88AB\u6A21\u677F\u675F\u7F1A\u7684\u573A\u666F (\u4E2A\u4EBA\u4F5C\u54C1\u96C6\u3001\u5947\u7279\u6F14\u8BB2\u3001\u827A\u672F / \u8BBE\u8BA1\u8BFE deck)\u3002\u7ED9\u4E00\u4E2A\u56FA\u5B9A 1920\xD71080 \u753B\u5E03 + \u6781\u5F3A\u7684\u7C7B\u578B / \u8C03\u8272\u7EA6\u675F, \u8BA9 agent \u50CF\u5199 React \u7EC4\u4EF6\u4E00\u6837\u6309\u5185\u5BB9\u81EA\u7531\u6392\u5E03\u6BCF\u4E00\u9875\u3002Inspired by 1weiho/open-slide\u3002\n\n\u3010\u786C\u6027\u6280\u672F\u89C4\u683C\u3011\n- \u753B\u5E03: \u6BCF\u9875\u4E25\u683C `width: 1920px; height: 1080px;` \u7528 `transform: scale(...)` \u9002\u914D\u89C6\u7A97 (\u9ED8\u8BA4 `scale(0.7)` \u5C45\u4E2D)\u3002\n- **\u7EDD\u5BF9\u7981\u6B62 overflow**: \u6BCF\u9875\u5185\u5BB9\u5FC5\u987B fit in 1920\xD71080, \u4E0D\u8BB8\u6EDA\u52A8\u6761\u51FA\u73B0\u3002\n- \u5B57\u53F7 type scale (px): `2xs:18 \xB7 xs:22 \xB7 sm:28 \xB7 md:36 \xB7 lg:48 \xB7 xl:64 \xB7 2xl:88 \xB7 3xl:120 \xB7 4xl:160 \xB7 5xl:220`\u3002\n- \u8FB9\u8DDD padding: 96 / 128 / 160 \u4E09\u6863\u4E4B\u4E00\u3002\n- \u6BCF\u9875\u6709 `<section class="slide" data-slide-id="<n>">`\u3002\n\n\u3010\u8C03\u8272\u677F \u2014 \u6BCF\u4E2A deck \u9009 1 \u5957, \u5168\u7A0B\u4E0D\u6539\u3011\n- \u{1F32B} **Ash & Lime** \u2014 bg `#f1efea`, ink `#161616`, accent `#c5e803`\u3002\n- \u{1F30C} **Sea Indigo** \u2014 bg `#0a0e1a`, ink `#f5f5f7`, accent `#5ac8fa`\u3002\n- \u{1F9C9} **Mate Mocha** \u2014 bg `#1a1411`, ink `#f5e9d6`, accent `#d97757`\u3002\n- \u{1F338} **Pearl Rose** \u2014 bg `#fdf6f3`, ink `#1a1015`, accent `#ff5d8f`\u3002\n\n\u3010\u5E03\u5C40\u81EA\u7531\u5EA6 \u2014 \u8FD9\u662F\u6838\u5FC3\u3011\n- \u4E0D\u5F3A\u5236\u6A21\u677F, \u6BCF\u9875\u6839\u636E**\u5185\u5BB9\u6027\u8D28**\u81EA\u9009\u5E03\u5C40: cover / question / quote / image-text / \u4E09\u5217 / \u4E94\u5217 / \u5217\u8868 / \u6570\u636E\u5361 / \u6EE1\u7248\u56FE\u3002\n- \u4F46\u6BCF\u9875**\u5FC5\u987B\u9075\u5B88\u4E00\u6761\u89C4\u5219**: \u89C6\u89C9\u91CD\u5FC3 (visual hierarchy) \u53EA\u6709 1 \u4E2A \u2014 \u4E00\u53E5\u91D1\u53E5\u3001\u4E00\u4E2A\u6570\u5B57\u3001\u4E00\u5F20\u56FE, \u4E0D\u8981"\u4EC0\u4E48\u90FD\u5F3A\u8C03"\u3002\n- \u4E0D\u8BB8\u585E\u4E24\u6BB5\u5E73\u7B49\u7684\u6587\u5B57; \u771F\u8981\u5E76\u5217\u5C31\u4E0A 3 \u5217\u7B49\u6743\u91CD\u7F51\u683C\u3002\n\n\u3010\u5B57\u4F53\u3011\n- \u897F\u6587: `Inter Tight` (display) + `Inter` (body); \u6216 `Source Serif Pro` (editorial \u98CE\u65F6)\u3002\n- \u4E2D\u6587: `Noto Sans SC` (sans \u98CE) \u6216 `Noto Serif SC` (editorial \u98CE); \u4E0D\u6DF7 sans + serif\u3002\n- mono: `JetBrains Mono` \u7ED9\u6570\u636E / \u65F6\u95F4\u6233\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- \u4E25\u7981 emoji \u88C5\u9970 (\u5185\u5BB9\u91CC\u7684\u5141\u8BB8); \u4E25\u7981\u591A\u8272\u5F69\u8679; accent \u53EA\u7528\u4E00\u4E2A\u8272\u3002\n- \u4E25\u7981 SVG icon \u5957\u7528 lucide / feather \u7B49\u901A\u7528\u5E93 (\u81EA\u5DF1\u5199 inline SVG)\u3002\n- \u52A0\u952E\u76D8 \u2190 / \u2192 \u5207\u6362 + hash \u540C\u6B65; \u89D2\u6807\u56FA\u5B9A: \u53F3\u4E0B `\u2116N/M`, \u5DE6\u4E0B deck title\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u7684\u771F\u5B9E\u5185\u5BB9; \u4E25\u7981 lorem ipsum\u3002\n- \u5355\u6587\u4EF6 HTML; Tailwind CDN; \u4E0D\u8981\u5916\u94FE\u56FE\u7247\u3002',enName:"Open-Slide 1920 Canvas Deck",scenario:"design",aspectHint:"1920\xD71080 (16:9)",tags:["canvas","open-slide","freeform","1920","react"]},{id:"deck-safety-alert",name:"\u5B89\u5168 / \u98CE\u9669\u7EA2\u8272 Deck",icon:"\u26A0\uFE0F",description:"\u7EA2\u7425\u73C0\u8B66\u793A\u8272 + hazard \u6761\u7EB9 + L1/L2/L3 tier \u5361\u7247 + \u5220\u9664\u7EBF\u6807\u9898",category:"slides",body:`\u3010\u6A21\u677F: Safety Alert Deck\u3011
\u3010\u610F\u56FE\u3011\u5B89\u5168 / \u98CE\u9669 / \u4E8B\u6545\u590D\u76D8 / red team / policy-as-code \u7528 deck\u3002
\u3010\u5E03\u5C40\u3011
- \u9876/\u5E95 45\xB0 \u7EA2\u9ED1 hazard \u6761\u7EB9
- \u7EA2\u8272\u5220\u9664\u7EBF\u5426\u5B9A\u6807\u9898
- L1/L2/L3 \u7EFF / \u7425\u73C0 / \u7EA2 tier \u5361\u7247
- \u5706\u70B9\u72B6\u6001 alert box
- policy-yaml \u4EE3\u7801\u5757 (\u7EA2\u5DE6\u8FB9\u6846 + bad \u5173\u952E\u8BCD\u9AD8\u4EAE)
- \u7EA2\u7EFF checklist + \u4E8B\u6545\u5806\u53E0\u67F1\u72B6\u56FE`,enName:"Testing / Safety Alert Deck",scenario:"engineering",aspectHint:"16:9",tags:["safety","security","policy","incident"]},{id:"deck-graphify-dark",name:"\u6697\u5E95\u56FE\u8C31 Deck",icon:"\u{1F30C}",description:"\u6DF1\u591C\u6E10\u53D8 + \u6F02\u6D6E orbs + SVG \u529B\u5BFC\u5411\u56FE\u8C31 + JetBrains Mono",category:"slides",body:`\u3010\u6A21\u677F: Graphify Dark Graph Deck\u3011
\u3010\u610F\u56FE\u3011AI-native / \u77E5\u8BC6\u56FE\u8C31 / dev-tool launch deck\u3002
\u3010\u5E03\u5C40\u3011
- Cover: #06060c\u2192#0e1020 \u6E10\u53D8 + \u6D6E\u52A8 blur orbs + SVG \u529B\u5BFC\u5411 graph
- Section \u9875: \u5F69\u8679\u6E10\u53D8\u6807\u9898
- \u4EE3\u7801 / CLI \u9875: JetBrains Mono \u9AD8\u4EAE
- Glassmorphism \u5361\u7247\u9875`,enName:"Graphify Dark Deck",scenario:"engineering",aspectHint:"16:9",tags:["graph","dev tool","ai","cli"]},{id:"deck-xhs-white",name:"\u767D\u5E95\u6742\u5FD7\u98CE Deck",icon:"\u{1F308}",description:"\u7EAF\u767D + \u9876\u90E8\u5F69\u8679 bar + \u6E10\u53D8\u6587\u5B57 + \u9A6C\u5361\u9F99\u8F6F\u5361\u7247 + \u9ED1\u5E95 pill",category:"slides",body:`\u3010\u6A21\u677F: \u767D\u5E95\u6742\u5FD7\u98CE Deck\u3011
\u3010\u610F\u56FE\u3011\u53EF\u540C\u65F6\u53D1\u5C0F\u7EA2\u4E66\u56FE\u6587\u4E0E\u6A2A\u7248 PPT \u53CC\u7528\u7684\u767D\u5E95\u6742\u5FD7\u98CE\u3002
\u3010\u5E03\u5C40\u3011
- \u7EAF\u767D\u80CC\u666F + \u9876\u90E8 10 \u8272\u5F69\u8679 bar
- 80-110px display \u6807\u9898 + \u7D2B\u2192\u84DD\u2192\u7EFF\u2192\u6A59\u2192\u7C89\u6E10\u53D8\u6587\u5B57
- \u9A6C\u5361\u9F99\u8F6F\u5361\u7247\u7EC4 (\u7C89 / \u7D2B / \u84DD / \u7EFF / \u6A59)
- \u9ED1\u5E95\u767D\u5B57 .focus pill + \u5F15\u7528\u5927\u5757`,enName:"White Editorial Deck",scenario:"marketing",aspectHint:"16:9 / 3:4",tags:["editorial","rainbow","macaron"]},{id:"deck-product-launch",name:"\u4EA7\u54C1\u53D1\u5E03 Keynote",icon:"\u{1F389}",description:"\u6697 hero + \u4EAE\u5185\u5BB9, \u6A59\u2192\u6843 accent, \u7279\u6027\u5361 + \u5B9A\u4EF7 + CTA",category:"slides",body:`\u3010\u6A21\u677F: Product Launch Keynote\u3011
\u3010\u610F\u56FE\u3011\u65B0\u4EA7\u54C1\u53D1\u5E03\u7684 Keynote \u98CE deck\u3002
\u3010\u5E03\u5C40\u3011
- Cover (\u6697\u80CC\u666F + \u5927\u5B57\u4E3B\u9898)
- Why we built this (\u95EE\u9898)
- Introducing (\u4EA7\u54C1\u540D + 1 \u5F20 hero shot)
- Feature cards (3-6 \u4E2A)
- Pricing tiers
- CTA / Available now
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- accent: \u6696\u6A59\u2192\u6843 \u6E10\u53D8`,enName:"Product Launch Deck",scenario:"marketing",aspectHint:"16:9",tags:["launch","keynote","product"]},{id:"deck-guizang-editorial",name:"\u8D35\u8D5E\u7F16\u8F91\u58A8\u6C34 Deck",icon:"\u{1F58B}\uFE0F",description:"\u7535\u5B50\u6742\u5FD7 \xD7 \u7535\u5B50\u58A8\u6C34; 10 \u4E2A\u7248\u9762 + 5 \u5957\u8C03\u8272\u677F (\u58A8\u6C34/\u975B\u84DD\u74F7/\u68EE\u6797\u58A8/\u725B\u76AE\u7EB8/\u6C99\u4E18)",category:"slides",body:"\u3010\u6A21\u677F: \u8D35\u8D5E\u7F16\u8F91\u58A8\u6C34 Deck (Editorial \xD7 E-Ink)\u3011\n\u3010\u610F\u56FE\u3011\u53D9\u4E8B\u3001\u89C2\u70B9\u3001\u5206\u4EAB\u3001\u4E2A\u4EBA\u98CE\u683C\u8868\u8FBE\u3002\u58A8\u7EB8\u5370\u5237\u611F, \u4E0D\u8981\u79D1\u6280\u611F\u3002Inspired by op7418/guizang-ppt-skill Style A\u3002\n\n\u3010\u8C03\u8272\u677F \u2014 5 \u9009 1, \u4E25\u7981\u6539 hex\u3001\u4E25\u7981\u6DF7\u7528\u3011\n- \u{1F58B} **\u58A8\u6C34\u7ECF\u5178 Monocle** \u2014 ink `#0a0a0b`, paper `#f1efea`, paper-tint `#e8e5de`, ink-tint `#18181a`. \u9ED8\u8BA4 / \u901A\u7528\u5546\u4E1A / \u79D1\u6280\u3002\n- \u{1F30A} **\u975B\u84DD\u74F7 Indigo Porcelain** \u2014 ink `#0a1f3d`, paper `#f1f3f5`, paper-tint `#e4e8ec`, ink-tint `#152a4a`. \u79D1\u6280 / \u7814\u7A76 / \u6570\u636E\u3002\n- \u{1F33F} **\u68EE\u6797\u58A8 Forest Ink** \u2014 ink `#1a2e1f`, paper `#f5f1e8`, paper-tint `#ece7da`, ink-tint `#253d2c`. \u81EA\u7136 / \u53EF\u6301\u7EED / \u6587\u5316\u3002\n- \u{1F342} **\u725B\u76AE\u7EB8 Kraft Paper** \u2014 ink `#2a1e13`, paper `#eedfc7`, paper-tint `#e0d0b6`, ink-tint `#3a2a1d`. \u6000\u65E7 / \u4EBA\u6587 / \u6587\u5B66\u3002\n- \u{1F319} **\u6C99\u4E18 Dune** \u2014 ink `#1f1a14`, paper `#f0e6d2`, paper-tint `#e3d7bf`, ink-tint `#2d2620`. \u827A\u672F / \u8BBE\u8BA1 / \u65F6\u5C1A\u3002\n\n\u3010\u5E03\u5C40 \u2014 10 \u4E2A\u78C1\u5E26\u5F0F\u7248\u5F0F\u6C60, \u53EF\u590D\u7528; **\u6570\u91CF\u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u51B3\u5B9A**, \u5B8C\u6574\u8986\u76D6\u6BCF\u4E2A\u8981\u70B9; \u77ED\u5185\u5BB9 6-12 \u5F20\u8D77\u6B65, \u957F\u5185\u5BB9\u5E94\u66F4\u591A (\u540C\u4E00\u7248\u5F0F\u53EF\u5728\u4E0D\u540C\u7AE0\u8282\u91CD\u590D\u4F7F\u7528)\u3011\n- **L01 Hero Cover** \u2014 \u5C45\u4E2D\u5927\u5B57 hero typography + kicker + subtitle + lead paragraph + \u5E95\u90E8\u5143\u6570\u636E row\u3002\n- **L02 Act Divider** \u2014 kicker + 8.5-10vw \u5DE8\u5927 headline + \u4E00\u53E5\u5F15\u8A00; \u7AE0\u8282\u5207\u6362\u53EF\u53CD\u8272 (ink \u2194 paper)\u3002\n- **L03 Big Numbers Grid** \u2014 3\xD72 \u6570\u636E\u5361 (label / \u5927\u6570\u5B57 / \u6CE8\u91CA)\u3002\n- **L04 Quote + Image** \u2014 \u5DE6 kicker + headline + body + callout; \u53F3 16:10 \u56FE (\u57FA\u7EBF\u5BF9\u9F50 baseline \u4E0D\u662F top)\u3002\n- **L05 Image Grid** \u2014 3\xD72 \u6216 3\xD71 \u7B49\u9AD8\u56FE\u7F51\u683C (26vh \u6216 22vh); \u4E25\u683C\u7EDF\u4E00\u9AD8\u5EA6\u3002\n- **L06 Pipeline / Flow** \u2014 \u6A2A\u5411\u7F16\u53F7\u6B65\u9AA4\u7EC4, \u6BCF\u6B65: \u2116X + \u6807\u9898 + \u63CF\u8FF0; \u652F\u6301\u952E\u76D8\u9010\u6B65\u63A8\u8FDB\u3002\n- **L07 Hero Question** \u2014 7vw \u5168\u5C4F\u5355\u4E00\u95EE\u53E5, \u6309\u8BED\u4E49\u65AD\u884C, \u5468\u56F4\u6781\u7B80\u3002\n- **L08 Big Quote** \u2014 5.8vw \u5DE8\u5927\u886C\u7EBF\u5F15\u6587 + \u82F1\u6587\u7FFB\u8BD1 + \u7F72\u540D + \u65E5\u671F\u3002\n- **L09 Before / After** \u2014 1:1 split; \u5DE6\u5217 opacity .55 (\u65E7/before); \u53F3\u5217 full brightness (\u65B0/after)\u3002\n- **L10 Mixed Media** \u2014 8:4 \u6BD4\u4F8B; \u5DE6\u5927\u6BB5\u6587\u5B57 (kicker / headline / body / callout) + \u53F3 3:4 \u7AD6\u56FE\u4F5C\u8F85\u52A9\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- **\u4E25\u7981**: \u6E10\u53D8 / drop-shadow / \u5706\u89D2 / \u5706\u5F62\u88C5\u9970 / blur / SVG \u56FE\u6807\u5E93 / emoji \u88C5\u9970\u3002\n- **\u5B57\u4F53**: Display \u7528 `Playfair Display` (\u82F1) / `Noto Serif SC` (\u4E2D); Body \u7528 `Inter` / `Noto Sans SC`; \u7F16\u53F7 / \u6570\u5B57\u5076\u5C14\u53EF\u7528 italic \u886C\u7EBF\u3002\n- **\u6742\u5FD7\u611F\u7EC6\u8282**: kicker \u7528 11px uppercase letterspacing 0.12em; folio \u53F3\u4E0B\u89D2 `01 / 12`; \u9876\u90E8\u7EC6 hairline rule + \u671F\u520A logo / topic\u3002\n- **\u4E0D\u8BB8**: \u6570\u636E\u634F\u9020\u3001Lorem ipsum\u3001\u5360\u4F4D\u56FE\u7247 URL\u3002\u6240\u6709\u56FE\u8BF7\u7528\u7EAF CSS / SVG \u5185\u8054\u63CF\u7ED8 (\u8272\u5757 + \u7B80\u7B14)\u3002\n- \u952E\u76D8 \u2190 / \u2192 \u5207\u6362; hash \u540C\u6B65; \u5355\u6587\u4EF6 HTML\u3002",enName:"Guizang Editorial E-Ink Deck",scenario:"marketing",aspectHint:"16:9 \u6A2A\u5411\u7FFB\u9875",tags:["editorial","e-ink","magazine","narrative","guizang"]},{id:"deck-dir-key-nav",name:"\u6781\u7B80\u65B9\u5411\u952E Keynote",icon:"\u25B6\uFE0E",description:"8 \u9875\u5355\u8272\u80CC\u666F, 160px display + 4px accent + Mono \u7BAD\u5934\u5217\u8868",category:"slides",body:`\u3010\u6A21\u677F: \u6781\u7B80\u65B9\u5411\u952E Keynote\u3011
\u3010\u610F\u56FE\u3011\u201C\u6709\u8BDD\u8981\u8BF4\u4F46\u6CA1\u4EC0\u4E48\u53EF\u770B\u201D \u7684\u6781\u7B80 keynote\u3002
\u3010\u5E03\u5C40\u3011
- \u9875\u6570\u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u51B3\u5B9A (\u77ED\u5185\u5BB9 8 \u9875\u8D77\u6B65, \u957F\u5185\u5BB9\u5E94\u66F4\u591A); \u6BCF\u9875\u5355\u8272\u80CC\u666F, \u4ECE\u4E0B\u5217\u8C03\u8272\u677F\u91CC\u5FAA\u73AF\u9009\u53D6 (\u975B / \u5976 / \u7EDB / \u7FE0 / \u7070 / \u7D2B / \u767D / \u70AD), \u540C\u8272\u53EF\u590D\u7528
- 160px display \u6807\u9898 + 4px \u77ED\u7C97 accent \u7EBF
- \u7BAD\u5934 \u2192 \u524D\u7F00\u7684 Mono \u5217\u8868
- \u5DE6\u4E0B \u2190 \u2192 kbd \u63D0\u793A + \u53F3\u4E0B\u9875\u7801`,enName:"Dir-Key Nav Minimal Deck",scenario:"personal",aspectHint:"16:9",tags:["minimal","kbd","monocolor"]},{id:"deck-tech-sharing",name:"\u6280\u672F\u5206\u4EAB Deck",icon:"\u{1F4BB}",description:"GitHub-dark + JetBrains Mono + \u7EC8\u7AEF\u4EE3\u7801\u5757, \u542B agenda + Q&A",category:"slides",body:`\u3010\u6A21\u677F: Tech Sharing Deck\u3011
\u3010\u610F\u56FE\u3011\u5DE5\u7A0B\u5185\u90E8\u5206\u4EAB / \u4F1A\u8BAE talk \u7684 deck\u3002
\u3010\u5E03\u5C40\u3011
- Cover (\u8BAE\u9898 + \u8BB2\u8005 + handle)
- Agenda \u9875
- \u6B63\u6587\u9875\u82E5\u5E72 (\u4EE3\u7801\u5757 + \u5173\u952E\u89C2\u70B9)
- Demo \u9875 (terminal \u622A\u56FE)
- Q&A \u9875
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- GitHub-dark \u914D\u8272 + JetBrains Mono`,enName:"Tech Sharing Deck",scenario:"engineering",aspectHint:"16:9",tags:["tech talk","conference","engineering"]},{id:"deck-course-module",name:"\u8BFE\u7A0B / \u57F9\u8BAD Deck",icon:"\u{1F393}",description:"\u6696\u7EB8\u80CC\u666F + Playfair, \u5DE6\u4FA7\u5B66\u4E60\u76EE\u6807\u5E38\u9A7B, \u542B MCQ \u81EA\u6D4B\u9875",category:"slides",body:`\u3010\u6A21\u677F: \u8BFE\u7A0B / \u57F9\u8BAD\u6A21\u5757 Deck\u3011
\u3010\u610F\u56FE\u3011\u6559\u5B66 / workshop \u7528 deck, \u6301\u7EED\u663E\u793A\u5B66\u4E60\u76EE\u6807\u3002
\u3010\u5E03\u5C40\u3011
- Cover (\u6A21\u5757\u540D + \u8BB2\u5E08)
- Learning objectives \u5217\u8868 (\u5DE6\u4FA7\u6301\u7EED\u663E\u793A)
- \u6B63\u6587\u9875 (concept + \u4F8B\u5B50)
- MCQ \u81EA\u6D4B\u9875
- Wrap-up + \u4E0B\u4E00\u6A21\u5757\u9884\u544A
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- warm paper bg + Playfair serif`,enName:"Course Module Deck",scenario:"education",aspectHint:"16:9",tags:["course","workshop","training","\u6559\u5B66"]},{id:"deck-blueprint",name:"\u84DD\u56FE\u67B6\u6784 Deck",icon:"\u{1F4D0}",description:"\u5976\u6CB9\u7EB8 + \u9508\u7EA2 + \u84DD\u56FE\u7F51\u683C mask + \u9ED1\u8FB9\u786C\u5361\u7247 + pipeline \u76D2",category:"slides",body:`\u3010\u6A21\u677F: Knowledge Arch Blueprint Deck\u3011
\u3010\u610F\u56FE\u3011\u8BA4\u771F\u7684\u3001\u5370\u5237\u53CB\u597D\u7684\u67B6\u6784 / pipeline \u8BB2\u89E3 deck\u3002
\u3010\u5E03\u5C40\u3011
- \u5976\u6CB9 #F0EAE0 \u5E95 + \u84DD\u56FE 48px \u7F51\u683C mask
- Pipeline \u6B65\u9AA4\u76D2 (\u5176\u4E2D\u4E00\u4E2A\u62AC\u9AD8)
- \u53F3\u4FA7\u9508\u7EA2 #B5392A insight callout
- Playfair serif \u5927\u5B57 + SVG \u865A\u7EBF\u53CD\u9988\u73AF
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u96F6\u6E10\u53D8\u96F6\u8F6F\u9634\u5F71`,enName:"Knowledge Arch Blueprint",scenario:"engineering",aspectHint:"16:9",tags:["blueprint","architecture","engineering"]},{id:"deck-xhs-pastel",name:"\u9A6C\u5361\u9F99\u6162\u751F\u6D3B Deck",icon:"\u{1F361}",description:"\u5976\u6CB9\u5E95 + \u67D4\u5149 blob + \u9A6C\u5361\u9F99\u5706\u89D2\u5361\u7247 + Playfair \u659C\u4F53\u5E8F\u53F7",category:"slides",body:`\u3010\u6A21\u677F: \u9A6C\u5361\u9F99\u6162\u751F\u6D3B Deck\u3011
\u3010\u610F\u56FE\u3011\u751F\u6D3B\u65B9\u5F0F / \u4E2A\u4EBA\u6210\u957F / \u60C5\u7EEA\u5411\u5185\u5BB9\u7528 deck\u3002
\u3010\u5E03\u5C40\u3011
- \u5976\u6CB9 #fef8f1 \u5E95 + \u4E09\u4E2A\u67D4\u5149 blob
- Playfair \u659C\u4F53\u886C\u7EBF display + sans \u6B63\u6587
- 28px \u5706\u89D2\u9A6C\u5361\u9F99\u5361\u7247 (\u6843 / \u8584\u8377 / \u5929 / \u7D2B / \u67E0 / \u73AB)
- Playfair \u659C\u4F53 01-04 \u5E8F\u53F7
- SVG donut \u56FE + chip+page \u9876\u680F`,enName:"Pastel Slow-life Deck",scenario:"personal",aspectHint:"16:9",tags:["xhs","pastel","lifestyle","lifestyle"]},{id:"deck-swiss-international",name:"\u745E\u58EB\u56FD\u9645\u4E3B\u4E49 Deck",icon:"\u{1F7E6}",description:"16 \u5217\u7F51\u683C + \u5355\u4E00\u9971\u548C accent + 22 \u4E2A\u9501\u6B7B\u7248\u9762 (Klein Blue / Lemon / Mint / Safety Orange)",category:"slides",body:`\u3010\u6A21\u677F: \u745E\u58EB\u56FD\u9645\u4E3B\u4E49 Deck (Swiss International)\u3011
\u3010\u610F\u56FE\u3011\u4E8B\u5B9E\u3001\u4EA7\u54C1\u3001\u5206\u6790\u3001\u65B9\u6CD5\u8BBA\u8868\u8FBE\u3002\u6781\u5EA6\u51B7\u9759\u3001\u7406\u6027\u3001\u5B66\u9662\u6D3E, \u6CA1\u6709\u4EFB\u4F55\u624B\u7ED8 / \u566A\u70B9 / \u88C5\u9970\u3002Inspired by op7418/guizang-ppt-skill Style B\u3002

\u3010\u4E3B\u9898\u3011**\u53EA\u80FD\u4ECE\u4E0B\u9762 4 \u5957\u4E8C\u9009\u4E00, \u4E0D\u8BB8\u6DF7\u7528\u3001\u4E0D\u8BB8\u6539 hex**:
- \u{1F535} **Klein Blue (IKB)** \u2014 accent \`#002FA7\`, paper \`#fafaf8\`, ink \`#0a0a0a\`. \u5546\u4E1A / AI / \u8BBE\u8BA1\u573A\u666F\u3002
- \u{1F7E1} **Lemon Yellow** \u2014 accent \`#FFD500\`, paper \`#f7f5ee\` (\u6DE1\u5976\u6CB9), ink \`#0a0a0a\`. \u5E74\u8F7B / \u96F6\u552E / \u4F53\u80B2\u3002\u6587\u5B57\u5FC5\u987B\u7528\u9ED1\u8272 (\u4E0D\u80FD\u767D\u8272)\u3002
- \u{1F7E2} **Lemon Green / Neon** \u2014 accent \`#C5E803\`, paper \`#f7f5ee\`, ink \`#0a0a0a\`. \u53EF\u6301\u7EED / \u79D1\u6280\u521D\u521B / Gen-Z \u54C1\u724C\u3002\u6587\u5B57\u5FC5\u987B\u7528\u9ED1\u8272\u3002
- \u{1F7E0} **Safety Orange** \u2014 accent \`#FF6B35\`, paper \`#f7f5ee\`, ink \`#0a0a0a\`. \u5DE5\u4E1A / \u6C7D\u8F66 / \u7D27\u6025\u6D88\u606F\u3002\u6587\u5B57\u7528\u767D\u8272 + bold \u2265 600\u3002

\u3010\u5E03\u5C40 \u2014 22 \u4E2A\u53EF\u590D\u7528\u7248\u5F0F\u6C60, \u4E0D\u8BB8\u65B0\u589E\u6216\u6539\u9020\u7248\u5F0F; **\u6570\u91CF\u7531\u5185\u5BB9\u51B3\u5B9A**, \u628A\u3010\u7528\u6237\u5185\u5BB9\u3011\u5B8C\u6574\u8986\u76D6\u5B8C\u4E3A\u6B62 (\u77ED\u5185\u5BB9 6-10 \u5F20\u8D77\u6B65, \u957F\u5185\u5BB9\u5E94\u8FDC\u8D85\u6B64\u8303\u56F4, \u540C\u4E00\u7248\u5F0F\u53EF\u5728\u4E0D\u540C\u7AE0\u8282\u91CD\u590D\u4F7F\u7528)\u3011
- **S01 Cover** \u2014 \u5168\u5C4F accent + ASCII \u547C\u5438\u70B9\u9635 + \u53CD\u767D\u6807\u9898 + \u5143\u6570\u636E chrome (date / \u2116 / topic)\u3002
- **S02 Vertical Timeline** \u2014 \u5DE6\u4FA7\u865A\u7EBF\u8F74 + \u5706\u70B9; \u53F3\u4FA7\u8282\u70B9 = \u5E74\u4EFD + KPI + \u63CF\u8FF0\u3002
- **S03 Statement** \u2014 9.6vw \u5C45\u4E2D\u5DE8\u5B57 + \u5DE6\u4FA7\u5927\u6BB5\u7559\u767D + \u5E95\u90E8 hairline + \u6CE8\u91CA\u3002
- **S04 Six Cells** \u2014 2\xD73 \u7F51\u683C, \u6BCF\u683C: icon + \u7F16\u53F7 + \u77ED\u6807\u9898 + \u5355\u884C\u63CF\u8FF0\u3002
- **S05 Three Sub-cards** \u2014 \u5DE6\u4FA7 hero \u6807\u9898 + \u53F3\u4FA7 3 \u5F20\u6C34\u5E73\u5806\u53E0\u7684\u7070\u8272\u5361\u3002
- **S06 KPI Tower** \u2014 4 \u5217\u53D8\u9AD8\u84DD\u8272\u67F1\u72B6; \u67F1\u9876 icon; \u67F1\u5E95\u5927\u6570\u5B57 + \u6807\u7B7E\u3002
- **S07 H-Bar Chart** \u2014 \u6C34\u5E73\u6392\u540D\u6A2A\u6761, \u5BBD\u5EA6\u53CD\u6620\u6570\u636E, \u672B\u7AEF\u6807\u6570\u5B57\u3002
- **S08 Duo Compare** \u2014 \u5782\u76F4\u5206\u5272\u7EBF; \u5DE6 Before / \u53F3 After\u3002
- **S09 Closing Manifesto** \u2014 \u5DE6 IKB \u5757 + ASCII \u70B9\u9635 + \u5BA3\u8A00; \u53F3\u767D\u5E95 + 3 \u6761\u8981\u70B9\u3002
- **S10 Dot Matrix Statement** \u2014 \u5C45\u4E2D\u5BA3\u8A00 + \u89D2\u843D\u51E0\u4F55\u70B9\u77E9\u9635 / \u5706\u73AF\u77E9\u9635\u3002
- **S11 Horizontal Timeline** \u2014 \u9876\u90E8 headline, \u4E2D\u90E8 hairline \u8F74, \u7B49\u8DDD\u8282\u70B9, \u8282\u70B9\u4E0B\u65B9\u6B65\u9AA4\u540D\u3002
- **S12 Manifesto + Ink Banner** \u2014 \u4E0A\u534A headline + \u89E3\u91CA; \u4E0B\u534A\u5168\u5BBD\u9ED1\u8272\u6A2A\u5E45 + \u53CD\u767D\u5C0F\u5B57\u3002
- **S13 Three Forces Cards** \u2014 \u5DE6 ink hero \u5757; \u53F3 3 \u5F20\u7070\u8272\u5361, \u6BCF\u5361: \u5927\u6570\u5B57 + \u6587\u672C\u3002
- **S14 Loop Diagram** \u2014 \u5DE6\u7F16\u53F7\u6B65\u9AA4; \u53F3 SVG \u540C\u5FC3\u73AF; \u4E2D\u5FC3 "LOOP" \u6807\u7B7E\u3002
- **S15 Image Matrix + Hero Stat** \u2014 4\xD73 \u7B49\u9AD8\u5361\u7247 (12 \u9879) + \u5E95\u90E8 summary \u5927\u6570\u5B57 + \u6807\u7B7E\u3002
- **S16 Multi-card Brief** \u2014 3\xD72 \u5FAE\u5361; \u4E3B\u6587\u5DE6\u4E0A, \u6CE8\u811A\u53F3\u4E0B, \u5355\u5361 accent \u9AD8\u4EAE\u3002
- **S17 System Diagram** \u2014 \u5DE6 headline + 3 \u6BB5\u63CF\u8FF0; \u53F3 SVG \u4E09\u540C\u5FC3\u5706 + \u5916\u90E8\u6807\u7B7E\u3002
- **S18 Why Now** \u2014 3 \u5217, \u6BCF\u5217: category label + headline + \u63CF\u8FF0 + \u5E95\u90E8\u6570\u5B57 (\u6700\u540E\u4E00\u5217 accent)\u3002
- **S19 Four Cards** \u2014 \u9876\u90E8 accent hairline + headline + 4 \u5F20\u7B49\u5BBD\u5361 (\u5143\u6570\u636E / \u6807\u9898 / \u6B63\u6587)\u3002
- **S20 Stacked KPI Ledger** \u2014 \u5782\u76F4\u884C + hairline \u5206\u9694; \u5DE6\u5927\u6570\u5B57 / \u4E2D\u6807\u7B7E / \u53F3 icon\u3002
- **S21 Tech Spec Sheet** \u2014 \u5DE6\u6807\u9898\u5757 / \u4E2D 3 \u4E2A KPI hairline / \u53F3\u53D8\u9AD8\u67F1 / \u5E95\u6570\u636E\u3002
- **S22 Image Hero** \u2014 \u4E0A 60% \u5168\u5BBD\u56FE + \u767D\u8272\u6807\u9898\u5757\u8986\u76D6; \u4E0B 40% \u89E3\u91CA + 3 \u5217 KPI\u3002

\u3010\u8BBE\u8BA1\u7EC6\u8282 \u2014 \u7EDD\u5BF9\u94C1\u5F8B\u3011
- **\u53EA\u7528\u76F4\u89D2**: \u5168\u7A0B \`border-radius: 0\`\u3002\u5706\u89D2 = \u7ACB\u523B\u8FDD\u53CD\u3002
- **1px hairline borders**, \u9ED1\u8272\u6216 accent; \u4E25\u7981\u9634\u5F71 / \u6E10\u53D8 / blur\u3002
- **16 \u5217\u7F51\u683C**: \`grid-template-columns: repeat(16, 1fr); gap: 0\`\u3002
- **\u5B57\u4F53**: Inter Tight (Latin display) / Inter (body) / Noto Sans SC (\u4E2D\u6587) / JetBrains Mono (\u6570\u636E); \u4E25\u7981\u886C\u7EBF\u3001\u4E25\u7981\u88C5\u9970\u5B57\u4F53\u3002
- **\u5B57\u53F7\u6781\u7AEF\u53CD\u5DEE**: cover \u7528 9.6vw display, body 14-16px, label 11px uppercase letterspacing 0.08em\u3002
- **\u952E\u76D8 \u2190 / \u2192 \u5207\u6362 + hash \u540C\u6B65**; \u89D2\u6807\u56FA\u5B9A: \`\u2116N/N\` \u53F3\u4E0B, topic \u6807\u7B7E\u5DE6\u4E0B\u3002
- **\u4E0D\u8BB8\u7F16\u9020**: \u6570\u5B57\u5FC5\u987B\u6765\u81EA\u7528\u6237\u8F93\u5165, \u56FE\u8868\u67F1\u9AD8 = \u771F\u5B9E\u6570\u636E\u6309\u6BD4\u4F8B\u3002
- \u8F93\u51FA\u5355\u6587\u4EF6 HTML, \u4E0D\u7528\u4EFB\u4F55\u5916\u90E8\u56FE\u7247 URL; \u88C5\u9970\u51E0\u4F55 (ASCII \u77E9\u9635 / \u540C\u5FC3\u5706) \u7528\u7EAF CSS \u6216\u5185\u8054 SVG\u3002`,enName:"Swiss International Deck",scenario:"marketing",aspectHint:"16:9 \u6A2A\u5411\u7FFB\u9875",tags:["swiss","grid","international","ikb","editorial","facts"]},{id:"deck-simple",name:"\u901A\u7528 Simple Deck",icon:"\u25AB\uFE0F",description:"\u901A\u7528 horizontal-swipe HTML deck, \u4E0D\u8981 magazine \u8C03",category:"slides",body:`\u3010\u6A21\u677F: Simple Deck\u3011
\u3010\u610F\u56FE\u3011\u5E72\u51C0\u901A\u7528\u7684 horizontal-swipe deck (pitch / overview / study)\u3002
\u3010\u5E03\u5C40\u3011
- Cover + N \u4E2A content \u9875 + \u6536\u5C3E (N \u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u957F\u5EA6\u51B3\u5B9A, \u5B8C\u6574\u8986\u76D6\u6BCF\u4E2A\u8981\u70B9; \u77ED\u5185\u5BB9 6-10 \u8D77\u6B65, \u957F\u5185\u5BB9\u5E94\u66F4\u591A)
- \u6BCF\u9875\u4E00\u4E2A\u6838\u5FC3\u4FE1\u606F + 1 \u5F20\u56FE / 1 \u4E2A\u56FE\u8868
- \u9876\u90E8 progress bar
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u952E\u76D8 \u2190 / \u2192 \u5207\u6362 + hash \u540C\u6B65`,enName:"Simple Deck",scenario:"product",aspectHint:"16:9",tags:["deck","simple","swipe"]},{id:"deck-pitch",name:"\u6295\u8D44\u4EBA Pitch Deck",icon:"\u{1F680}",description:"10 \u9875\u878D\u8D44 deck, \u767D\u5E95 + \u84DD\u7D2B\u6E10\u53D8 hero, traction \u67F1\u72B6, $X.XM ask",category:"slides",body:`\u3010\u6A21\u677F: Investor Pitch Deck\u3011
\u3010\u610F\u56FE\u301110 \u9875\u6295\u8D44\u4EBA ready \u7684 fundraising deck\u3002
\u3010\u5E03\u5C40\u3011
- Cover (Logo + Tagline + Round/$Ask)
- Problem \xB7 Solution \xB7 Why Now
- Product (\u622A\u56FE\u5360\u4F4D)
- Market size (TAM/SAM/SOM)
- Traction (\u67F1\u72B6\u56FE\u5927\u6570\u5B57)
- Business model
- Go-to-market
- Team
- Ask: $4.5M-style page
- Thanks / Contact`,enName:"Investor Pitch Deck",scenario:"finance",aspectHint:"16:9 \xD710",tags:["pitch","investor","seed","vc"]},{id:"weekly-update",name:"\u56E2\u961F\u5468\u62A5 Deck",icon:"\u{1F5D3}\uFE0F",description:"6-8 \u9875\u6A2A\u5411\u6ED1\u52A8\u5468\u62A5: \u5DF2\u53D1\u5E03 / \u8FDB\u884C\u4E2D / \u963B\u585E / \u6307\u6807 / \u6C42\u52A9",category:"slides",body:`\u3010\u6A21\u677F: \u56E2\u961F\u5468\u62A5 Deck\u3011
\u3010\u610F\u56FE\u30116-8 \u9875 horizontal-swipe slides, \u5468\u62A5\u56FA\u5B9A\u7ED3\u6784\u3002
\u3010\u5E03\u5C40\u3011
- Cover (\u5468\u6B21 + \u56E2\u961F + \u4E00\u53E5\u8BDD\u4E3B\u9898)
- Shipped (\u5217\u8868 + owner)
- In flight (\u8FDB\u5EA6\u6761)
- Blocked (\u7EA2\u8272 callout)
- Metrics (KPI \u5361\u7247\u7F51\u683C + \u5468\u5BF9\u6BD4)
- Asks (\u6C42\u52A9\u6E05\u5355)
- Thanks \u6536\u5C3E
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u952E\u76D8\u5DE6\u53F3\u5207\u6362, hash \u540C\u6B65`,enName:"Weekly Update Deck",scenario:"operations",aspectHint:"16:9 \xD78",tags:["weekly","\u5468\u62A5","status"]},{id:"deck-xhs-post",name:"\u5C0F\u7EA2\u4E66\u56FE\u6587 Deck",icon:"\u{1F380}",description:"9 \u9875 3:4 \u7AD6\u7248\u56FE\u6587, \u6696 pastel + \u865A\u7EBF sticker \u5361\u7247",category:"slides",body:`\u3010\u6A21\u677F: \u5C0F\u7EA2\u4E66 / Instagram Carousel\u3011
\u3010\u610F\u56FE\u3011\u53D1\u5C0F\u7EA2\u4E66 / IG carousel \u7684 9 \u9875 3:4 \u7AD6\u7248\u56FE\u6587\u3002
\u3010\u5E03\u5C40\u3011
- Cover + N \u4E2A content \u9875 + \u6536\u5C3E CTA (N \u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u51B3\u5B9A, \u5B8C\u6574\u8986\u76D6\u6BCF\u4E2A\u8981\u70B9; \u77ED\u5185\u5BB9 7 \u9875\u8D77\u6B65, \u957F\u5185\u5BB9\u5E94\u66F4\u591A, \u53D7\u5C0F\u7EA2\u4E66\u5E73\u53F0\u5355\u5E16\u56FE\u7247\u6570\u7EA6\u675F\u5EFA\u8BAE\u603B\u6570 \u2264 18)
- \u6696\u8272 pastel \u80CC\u666F
- \u865A\u7EBF sticker \u5361\u7247 + \u5E95\u90E8\u9875\u7801 dots`,enName:"Xiaohongshu Post Deck",scenario:"marketing",aspectHint:"810\xD71080 \xD79",tags:["xhs","instagram","carousel"]},{id:"deck-presenter-mode",name:"\u6F14\u8BB2\u8005\u6A21\u5F0F Deck",icon:"\u{1F3A4}",description:"tokyo-night \u9ED8\u8BA4\u4E3B\u9898, T \u5207\u6362 5 \u4E3B\u9898, S \u6253\u5F00\u63D0\u8BCD\u5668 popup",category:"slides",body:`\u3010\u6A21\u677F: Presenter Mode Deck\u3011
\u3010\u610F\u56FE\u3011\u6015\u5FD8\u8BCD\u7684\u6F14\u8BB2\u8005\u4E13\u7528 deck, \u542B\u9010\u5B57\u7A3F notes \u4E0E popup teleprompter\u3002
\u3010\u5E03\u5C40\u3011
- \u6BCF\u9875 + \`<aside class="notes">\` 150-300 \u5B57\u7A3F
- \u53F3\u4E0B\u5C0F toolbar: T \u5207\u4E3B\u9898 / S \u6253\u5F00 popup
- Popup: CURRENT / NEXT / SCRIPT / TIMER \u56DB\u5F20\u78C1\u5438\u5361
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u9ED8\u8BA4 tokyo-night; \u5171 5 \u5957\u4E3B\u9898 (\u542B light)`,enName:"Presenter Mode Deck",scenario:"engineering",aspectHint:"16:9",tags:["presenter","notes","\u63D0\u8BCD","teleprompter"]},{id:"deck-magazine-web",name:"\u6742\u5FD7\u98CE\u7F51\u9875 PPT",icon:"\u{1F4F0}",description:"\u7535\u5B50\u6742\u5FD7 \xD7 \u7535\u5B50\u58A8\u6C34\u98CE, WebGL \u6D41\u4F53\u80CC\u666F + \u886C\u7EBF display",category:"slides",body:`\u3010\u6A21\u677F: \u6742\u5FD7\u98CE\u7F51\u9875 PPT (magazine-web-ppt)\u3011
\u3010\u610F\u56FE\u3011horizontal-swipe HTML deck, \u6742\u5FD7 \xD7 e-ink \u8C03\u3002
\u3010\u5E03\u5C40\u3011
- Cover (\u886C\u7EBF display + WebGL \u6D41\u4F53\u80CC\u666F)
- \u7AE0\u8282\u5E55\u5C01\u9875
- \u6570\u636E\u5927\u5B57\u62A5\u9875 (\u4E00\u4E2A\u5DE8\u6570\u5B57 + \u4E00\u53E5\u89E3\u91CA)
- \u56FE\u7247\u7F51\u683C\u9875
- \u91D1\u53E5\u9875 (Sunday-paper \u98CE)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u5B57\u4F53: Playfair / Noto Serif SC display + Inter / \u601D\u6E90 sans body
- \u952E\u76D8 \u2190 / \u2192 \u5207\u6362; hash \u540C\u6B65`,enName:"Magazine Web Deck",scenario:"marketing",aspectHint:"16:9 \u6A2A\u5411\u7FFB\u9875",tags:["magazine","editorial","e-ink","horizontal swipe"]},{id:"deck-hermes-cyber",name:"Cyber Terminal Deck",icon:"\u{1F7E2}",description:"\u9ED1\u5E95 + CRT \u7F51\u683C\u626B\u63CF\u7EBF + $ \u547D\u4EE4\u884C\u6807\u9898 + \u8584\u8377\u7EFF\u5927\u5B57 + \u4E09\u6863 tag",category:"slides",body:`\u3010\u6A21\u677F: Hermes Cyber Terminal Deck\u3011
\u3010\u610F\u56FE\u3011CLI / agent / dev tool \u6D4B\u8BC4 deck (\u542B trace, diff, benchmark)\u3002
\u3010\u5E03\u5C40\u3011
- #0a0c10 \u9ED1\u5E95 + 56px \u8D5B\u535A\u7F51\u683C + CRT \u6697\u89D2
- \u7A97\u53E3\u7EA2\u7EFF\u706F chrome + \`$ prompt\` \u6807\u9898
- \u8584\u8377\u7EFF #7ed3a4 \u5927\u5B57 + JetBrains Mono
- Stroke-only \u67F1\u72B6\u56FE + blinking \u5149\u6807
- \u7425\u73C0 / \u7EFF / \u7EA2 \u4E09\u6863 tag`,enName:"Hermes Cyber Terminal Deck",scenario:"engineering",aspectHint:"16:9",tags:["cyber","terminal","review","cli"]},{id:"deck-obsidian-claude",name:"GitHub Dark \u7D2B\u6E10\u53D8 Deck",icon:"\u{1F303}",description:"GitHub-dark + \u7D2B\u84DD\u73AF\u5883\u5149 + \u4E09\u8272\u6E10\u53D8\u6807\u9898 + GitHub \u98CE\u4EE3\u7801",category:"slides",body:`\u3010\u6A21\u677F: Obsidian Claude Gradient Deck\u3011
\u3010\u610F\u56FE\u3011\u7C7B GitHub Blog / Linear Changelog \u7684\u5F00\u53D1\u8005\u6559\u7A0B deck\u3002
\u3010\u5E03\u5C40\u3011
- GitHub-dark #0d1117 + \u7D2B\u84DD radial \u73AF\u5883\u5149 + 60px \u7F51\u683C mask
- \u5C45\u4E2D\u5E03\u5C40 + \u7D2B\u8272 pill tag
- \u4E09\u8272\u6E10\u53D8\u6807\u9898 (#a855f7\u2192#60a5fa\u2192#34d399)
- GitHub \u98CE\u4EE3\u7801 palette + \u7D2B\u8272\u5DE6\u8FB9\u6846\u9AD8\u4EAE\u5757`,enName:"Obsidian Claude Gradient Deck",scenario:"engineering",aspectHint:"16:9",tags:["github","dark","purple","mcp","agent"]},{id:"ppt-keynote",name:"Keynote \u98CE\u683C PPT",icon:"\u{1F3AC}",description:"\u82F9\u679C Keynote \u7EA7\u522B\u5E7B\u706F\u7247, \u4E00\u5C4F\u4E00\u5361, \u952E\u76D8\u5DE6\u53F3\u5207\u6362",category:"slides",body:`\u3010\u6A21\u677F: Keynote \u98CE\u683C PPT\u3011
- \u6BCF\u5F20\u5E7B\u706F\u7247\u662F\u4E00\u4E2A \`<section class="slide">\`, \u6574\u4F53\u5BBD 1280 \u9AD8 720, \u5C45\u4E2D\u663E\u793A, \u80CC\u666F\u6E10\u53D8\u3002
- \u5355\u9875\u5185\u5BB9\u6781\u7B80: \u5927\u6807\u9898 + 1-3 \u884C\u652F\u6301\u6587\u5B57; \u6216\u4E00\u5F20\u6570\u636E\u56FE; \u6216\u4E00\u4E2A\u91D1\u53E5\u3002
- \u5B57\u53F7: \u6807\u9898 \`text-7xl font-semibold tracking-tight\`, \u526F\u6807\u9898 \`text-2xl text-neutral-500\`\u3002
- \u7B2C\u4E00\u9875\u662F\u5C01\u9762 (\u4E3B\u9898 + \u6F14\u8BB2\u8005 / \u65E5\u671F), \u6700\u540E\u4E00\u9875\u662F "Thanks." \u6216\u884C\u52A8\u53F7\u53EC\u3002
- \u9876\u90E8\u53F3\u4E0A\u89D2\u5C0F\u6307\u793A\u5668: \u5F53\u524D\u9875 / \u603B\u9875\u6570\u3002
- \u52A0\u4E00\u6BB5 JavaScript \u76D1\u542C ArrowLeft / ArrowRight / \u7A7A\u683C\u952E\u5207\u6362 slide; \u540C\u65F6\u7EF4\u62A4 hash (#/3)\u3002
- \u6BCF\u9875\u4E4B\u95F4\u7528 fade-in \u52A8\u753B\u3002
- \u4FDD\u6301\u7559\u767D, \u6570\u636E\u5361\u7247\u7528 grid \u5E03\u5C40\u5BF9\u9F50, \u989C\u8272\u514B\u5236\u3002`,enName:"Keynote-style Slides",scenario:"marketing",aspectHint:"16:9 (1280\xD7720)",tags:["slides","deck","presentation","\u5E7B\u706F\u7247","\u6F14\u8BB2"]},{id:"deck-replit",name:"Replit Slides \u98CE Deck",icon:"\u{1F7E3}",description:"Replit Slides \u516B\u5957\u4E3B\u9898 (helix/holm/vance/bevel/world/atlas/bluehouse)",category:"slides",body:`\u3010\u6A21\u677F: Replit Slides Style Deck\u3011
\u3010\u610F\u56FE\u3011Replit Slides \u98CE\u7684\u5355\u6587\u4EF6 horizontal-swipe deck, \u9009 1 \u5957\u4E3B\u9898\u4E0D\u6DF7\u7528\u3002
\u3010\u5E03\u5C40\u3011
- Pick one theme: helix / holm / vance / bevel / world-dark / world-mint / atlas / bluehouse
- Cover + agenda + N \u4E2A content + \u6536\u5C3E (N \u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u957F\u5EA6\u51B3\u5B9A, \u5B8C\u6574\u8986\u76D6\u6BCF\u4E2A\u8981\u70B9; \u77ED\u5185\u5BB9 6-10 \u8D77\u6B65, \u957F\u5185\u5BB9\u5E94\u66F4\u591A)
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u6BCF\u5957\u4E3B\u9898\u6709\u5B8C\u6574\u8C03\u8272\u677F + \u5B57\u4F53 + accent, \u4E0D\u8981\u6DF7\u7528`,enName:"Replit Slides Deck",scenario:"product",aspectHint:"16:9",tags:["replit","themed","memo"]},{id:"frame-flowchart-sticky",name:"\u4FBF\u5229\u8D34\u6D41\u7A0B\u56FE\u5E27",icon:"\u{1F4DD}",description:"SVG \u66F2\u7EBF\u8FDE\u63A5 + \u4FBF\u5229\u8D34\u8282\u70B9 + \u5149\u6807\u4EA4\u4E92, \u50CF\u767D\u677F brainstorm",category:"video",body:'\u3010\u6A21\u677F: \u4FBF\u5229\u8D34\u6D41\u7A0B\u56FE\u5E27 (Sticky Flowchart)\u3011\n\u3010\u610F\u56FE\u3011\u628A\u4E00\u4E2A\u6D41\u7A0B / \u7CFB\u7EDF / \u5DE5\u4F5C\u6D41\u753B\u6210"\u767D\u677F + \u4FBF\u5229\u8D34"\u7684\u6837\u5B50, \u9002\u5408 onboarding \u89C6\u9891\u3001\u8FD0\u8425\u6D41\u7A0B\u8BF4\u660E\u3001\u7CFB\u7EDF\u67B6\u6784\u8BB2\u89E3\u3002Inspired by hyperframes flowchart\u3002\n\n\u3010\u753B\u5E03\u30111920\xD71080\u3002\u80CC\u666F: \u7C73\u9EC4\u767D\u677F\u7EB8 `#f4ede1` \u6216\u51B7\u7070\u767D\u677F `#f0f2f4`; \u52A0\u975E\u5E38\u6D45\u7684 hex grid `rgba(0,0,0,0.04)` \u8BA9\u5B83\u6709\u767D\u677F\u611F\u3002\n\n\u3010\u8282\u70B9 (Sticky Notes)\u3011\n- \u6BCF\u8282\u70B9 = \u4E00\u5F20 240\xD7180px \u4FBF\u5229\u8D34, 4 \u5957\u989C\u8272\u968F\u673A\u5206\u914D: \u9EC4 `#fcd34d` / \u6843 `#fca5a5` / \u8584\u8377 `#a7f3d0` / \u5929 `#a5b4fc`\u3002\n- \u4FBF\u5229\u8D34\u6709\u8F7B\u5FAE\u65CB\u8F6C `transform: rotate(\xB12deg)` \u4E0D\u4E00\u81F4, \u6295\u5F71 `drop-shadow(0 6px 14px rgba(0,0,0,0.12))`, \u9876\u90E8\u80F6\u5E26 `linear-gradient(...)` \u88C5\u9970\u3002\n- \u8282\u70B9\u5185\u5BB9: 1 \u4E2A emoji \u6216\u5355\u7EBF SVG icon + \u5927\u5B57\u6807\u9898 (16-20px) + \u4E00\u884C\u63CF\u8FF0 (12px)\u3002\n- \u8282\u70B9\u5B57\u4F53: `Kalam` / `Caveat` / `Patrick Hand` \u624B\u5199\u611F\u5B57\u4F53 (\u4E2D\u6587\u7528 `\u971E\u9E5C\u6587\u6977` \u6216 `LXGW WenKai Screen`)\u3002\n\n\u3010\u8FDE\u63A5\u7EBF (SVG)\u3011\n- \u7528 `<path>` Bezier \u66F2\u7EBF\u8FDE\u63A5\u8282\u70B9, stroke `#2a2a2a`, width 2.5, `stroke-linecap: round`, `stroke-dasharray: 0` (\u5B9E\u7EBF) \u6216 `8 6` (\u865A\u7EBF = \u6761\u4EF6\u5206\u652F)\u3002\n- \u7BAD\u5934\u7EC8\u7AEF\u7528 `marker-end`, \u9ED1\u8272\u4E09\u89D2\u5C0F\u7BAD\u5934\u3002\n- \u590D\u6742\u8282\u70B9\u53EF\u6709\u5FAA\u73AF\u6216\u5206\u652F: \u540C\u4E00\u8282\u70B9\u8FDE\u51FA 2 \u6761 (\u5206\u53C9) \u6216 2 \u6761\u8FDB\u5165\u4E00\u8282\u70B9 (\u5408\u5E76)\u3002\n\n\u3010\u53EF\u9009\u4EA4\u4E92\u3011\n- \u9876\u90E8 caption (sans, 12px uppercase): "FLOW \xB7 MIGRATION \xB7 2026"\u3002\n- \u9F20\u6807 hover \u8282\u70B9: \u62AC\u8D77\u9634\u5F71 + scale 1.05, \u7528 CSS transition\u3002\n- \u4E00\u4E2A"\u5149\u6807"\u88C5\u9970 (`<svg>` arrow + name tag), \u6D6E\u5728\u67D0\u8282\u70B9\u65C1, \u6A21\u62DF figma \u534F\u4F5C\u5149\u6807\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- \u81F3\u5C11 5 \u4E2A\u8282\u70B9, \u6700\u591A 12 \u4E2A\u3002\n- \u8282\u70B9\u6392\u5E03\u4E0D\u8981\u5168\u90E8\u5C45\u4E2D\u5BF9\u9F50, \u8981\u6709\u4E00\u70B9\u767D\u677F\u98CE\u7684"\u968F\u624B\u8D34"\u611F, \u4F46\u4FDD\u8BC1\u8FDE\u63A5\u7EBF\u6E05\u6670\u4E0D\u4EA4\u53C9\u3002\n- \u4E25\u7981: \u5168\u5C4F\u6DF1\u8272\u80CC\u666F\u3001\u9713\u8679\u8272\u3001\u4F01\u4E1A dashboard \u98CE\u683C\u3002\n- \u5B57\u4F53\u4E0D\u80FD\u7528 Inter / \u886C\u7EBF, \u5FC5\u987B\u624B\u5199\u611F\u3002\n- \u5355\u6587\u4EF6 HTML, \u4E0D\u8981\u5916\u90E8\u56FE\u6807\u5E93 (\u7528 inline SVG)\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u7684\u771F\u5B9E\u6D41\u7A0B\u5185\u5BB9; \u8282\u70B9\u6587\u5B57\u76F4\u63A5\u6765\u81EA\u7528\u6237\u8F93\u5165\u3002',enName:"Sticky Flowchart Frame",scenario:"operations",aspectHint:"1920\xD71080 (16:9)",tags:["flowchart","diagram","sticky","whiteboard","frame"]},{id:"motion-frames",name:"\u52A8\u6548\u82F1\u96C4\u5E27",icon:"\u{1F300}",description:"\u53EF\u5FAA\u73AF CSS \u52A8\u6548\u7EC4\u5408: \u65CB\u8F6C\u73AF\u3001\u5730\u7403\u4EEA\u3001\u8BA1\u65F6\u5668\u3001\u89C6\u5DEE\u6807\u7B7E",category:"video",body:`\u3010\u6A21\u677F: Motion \u5E27 / Hero Loop\u3011
\u3010\u610F\u56FE\u3011\u4E00\u5E27\u5E26\u5FAA\u73AF\u52A8\u6548\u7684 hero, \u53EF\u4F5C\u4E3A\u89C6\u9891\u7247\u5934\u6216\u843D\u5730\u9875\u5927\u56FE\u3002
\u3010\u5E03\u5C40\u3011
- Rotating type ring (SVG + transform)
- Animated globe / \u62BD\u8C61\u51E0\u4F55
- Ticking timer (mono \u5B57\u4F53, JS \u53EF\u6709\u53EF\u65E0)
- Parallax labels \u6D6E\u52A8
\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011
- \u7EAF CSS \u52A8\u6548, \u6D41\u7545\u53EF\u5FAA\u73AF
- \u7535\u5F71\u611F\u8C03\u8272 + 1 \u4E2A\u9713\u8679 accent`,enName:"Motion Frames",scenario:"marketing",aspectHint:"\u684C\u9762 hero",tags:["motion","title card","loop","video poster"]},{id:"frame-glitch-title",name:"\u6545\u969C\u827A\u672F\u6807\u9898\u5E27",icon:"\u26A1",description:"\u6570\u5B57\u6545\u969C / \u50CF\u6563\u504F\u79FB / \u6570\u636E\u8150\u8D25\u6807\u9898, \u9002\u5408\u89C6\u9891\u8F6C\u573A / cyberpunk hero",category:"video",body:'\u3010\u6A21\u677F: \u6545\u969C\u827A\u672F\u6807\u9898\u5E27 (Glitch Title)\u3011\n\u3010\u610F\u56FE\u3011\u5355\u5E27 hero / \u89C6\u9891\u8F6C\u573A / cyberpunk \u98CE\u683C\u6807\u9898\u3002Inspired by hyperframes glitch\u3002\n\n\u3010\u753B\u5E03\u30111920\xD71080, \u80CC\u666F `#070708` \u8FD1\u9ED1\u6216 CRT \u6697\u7070 `#0d0e10`; \u52A0 56px \u7F51\u683C (\u900F\u660E 5%) + scanlines \u6A2A\u7EBF (\u900F\u660E 8%, 2px \u95F4\u9694)\u3002\n\n\u3010\u4E3B\u6807\u9898\u3011\n- \u5C45\u4E2D, 6-9vw, weight 800/900, \u5B57\u4F53 `Space Grotesk Bold` / `Inter Tight Black` / `JetBrains Mono Bold`\u3002\n- \u989C\u8272: \u4E3B\u5C42 `#f5f5f7`; \u540E\u9762\u5957 2 \u5C42\u4F2A\u5F71:\n  - cyan `#00f0ff` translate(`-3px`, `1px`)\u3002\n  - magenta `#ff2bd6` translate(`3px`, `-1px`)\u3002\n- \u6574\u5C42\u52A0 clip-path \u5207\u7247 5-8 \u6BB5, \u6BCF\u6BB5 `@keyframes` \u968F\u673A translateX -10px \u2192 10px, \u6301\u7EED 80-160ms, \u9519\u5CF0\u64AD\u653E, \u8425\u9020 "data corruption" \u50CF\u6563\u3002\n- \u6BCF\u9694 1.5s \u89E6\u53D1\u4E00\u6B21"\u91CD\u6545\u969C" \u2014 \u6574\u4E2A\u6807\u9898\u88AB horizontal smear 1 frame, \u7528 `filter: url(#displacementFilter)` \u6216\u7B80\u5355 CSS \u5E73\u79FB\u3002\n\n\u3010\u9644\u52A0\u5C42\u3011\n- \u9876\u90E8\u4E00\u884C caption (uppercase mono, 11px, opacity 0.6): `>> SIGNAL_LOST \xB7 CH-04 \xB7 14:32:08`\u3002\n- \u6807\u9898\u4E0B\u9762 1 \u884C\u526F\u6807 (24-28px, mono, opacity 0.7), \u5076\u53D1\u88AB ` \u0336\u2592\u0336` \u5B57\u7B26\u66FF\u6362 (\u5047\u4E71\u7801)\u3002\n- \u89D2\u843D\u968F\u673A\u70B9\u7F00 `\u2588\u2593\u2592\u2591` ASCII \u566A\u70B9 chunks\u3002\n- \u5E95\u90E8 timecode (mono, opacity 0.4)\u3002\n- \u6574\u753B\u9762\u53E0 noise grain \u5C42 `background-image: url("data:image/svg+xml,...turbulence...")`, opacity 6%, mix-blend-mode overlay\u3002\n\n\u3010SVG \u6EE4\u955C (\u53EF\u9009)\u3011\n- \u5B9A\u4E49 `<filter id="rgbShift">` \u7528 `feColorMatrix` + `feOffset` + `feMerge` \u628A R/G/B \u4E09\u901A\u9053\u504F\u79FB; \u6574\u5C42 `filter: url(#rgbShift)` \u5728\u6545\u969C\u77AC\u95F4\u5E94\u7528\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- \u989C\u8272\u4EC5\u7528: \u9ED1 / \u767D / cyan / magenta / \u4E00\u70B9 amber \u8B66\u544A\u8272; \u4E25\u7981\u5168\u5F69\u8679\u3002\n- \u5B57\u4F53: \u897F\u6587 `Space Grotesk` \u6216 `JetBrains Mono` Bold; \u4E2D\u6587 `Noto Sans Mono CJK SC` \u6216 `Noto Sans SC` Bold\u3002\n- \u4E25\u7981 lorem ipsum; \u5FC5\u987B\u7528\u7528\u6237\u7684\u6807\u9898 + \u526F\u6807\u3002\n- \u52A8\u6548\u7528 `@keyframes`, \u53EF\u88AB `prefers-reduced-motion` \u5173\u95ED (\u9000\u56DE\u9759\u6001 chromatic split)\u3002\n- \u5355\u6587\u4EF6 HTML\u3002',enName:"Glitch Title Frame",scenario:"video",aspectHint:"1920\xD71080 (16:9)",tags:["glitch","cyberpunk","title","transition","vfx","frame"]},{id:"frame-light-leak-cinema",name:"\u80F6\u7247\u6F0F\u5149\u7535\u5F71\u5E27",icon:"\u{1F39E}\uFE0F",description:"\u80F6\u7247\u6F0F\u5149 + \u9897\u7C92\u566A\u70B9 + 16:9 letterbox + \u886C\u7EBF\u5927\u5B57, \u7535\u5F71\u611F\u5F00\u573A / \u7AE0\u8282\u5361",category:"video",body:'\u3010\u6A21\u677F: \u80F6\u7247\u6F0F\u5149\u7535\u5F71\u5E27\u3011\n\u3010\u610F\u56FE\u3011\u7EAA\u5F55\u7247 / \u4E2A\u4EBA\u77ED\u7247 / \u89C6\u9891\u7AE0\u8282\u5361\u7684\u5F00\u573A\u5355\u5E27 \u2014\u2014 \u6696\u6A59\u6F0F\u5149 + 35mm \u9897\u7C92 + \u886C\u7EBF\u5927\u5B57, \u53E4\u5178\u80F6\u7247\u8D28\u611F\u3002Inspired by hyperframes light-leak\u3002\n\n\u3010\u753B\u5E03\u3011\n- **2.39:1 letterbox** (\u63A8\u8350): 1920\xD7800, \u4E0A\u4E0B\u9ED1\u8FB9\u5404 140px (`#000`)\u3002\n- \u6216 16:9: 1920\xD71080, \u65E0 letterbox\u3002\n\n\u3010\u80CC\u666F\u3011\n- \u5E95\u5C42: \u6DF1\u6696\u8272 (\u6DF1\u7EA2\u68D5 `#1a0d08` / \u58A8\u7EFF `#0a1410` / \u84DD\u7D2B `#0d0e1a`) \u6216\u573A\u666F\u63CF\u7ED8 (CSS gradient \u6A21\u62DF\u5929\u7A7A / \u5BA4\u5185 / \u5BA4\u5916)\u3002\n- **\u80F6\u7247\u6F0F\u5149 (Light Leak)**: 2-3 \u4E2A\u5927 `radial-gradient(ellipse at top right, #ffb547 0%, transparent 50%)` + 1 \u4E2A\u5E95\u90E8 `linear-gradient(to top, #d97757 0%, transparent 30%)`; \u989C\u8272\u53D6\u6696\u6A59 / \u6843 / \u73AB\u7EA2 / \u6697\u9EC4, **\u4E0D\u8981\u51B7\u84DD**\u3002\n- **35mm Grain**: \u5168\u5C4F\u8986\u76D6 SVG turbulence noise \u56FE\u5C42, opacity 14%, `mix-blend-mode: overlay`; \u4E5F\u53EF\u7528 `background-image: url("data:image/svg+xml,...feTurbulence...")`\u3002\n- \u53EF\u9009: 1 \u9053 `feDisplacementMap` \u6A21\u62DF\u80F6\u7247\u6446\u52A8 (\u614E\u7528)\u3002\n\n\u3010\u6587\u5B57\u3011\n- \u4E2D\u592E\u6216\u5DE6\u4E0B: \u5927\u5B57\u886C\u7EBF (Source Serif Pro / Playfair Display / EB Garamond) 5-8vw, weight 500 italic; \u989C\u8272\u6696\u767D `#f5e9d6` \u6216 cream\u3002\n- \u526F\u6807 (24-28px) \u4E00\u884C, opacity 0.7, \u540C\u6837\u886C\u7EBF\u3002\n- \u89D2\u843D caption (uppercase letterspace 0.18em, 10-11px, mono, opacity 0.5): "REEL 03 \xB7 CH I \xB7 1985"\u3002\n- \u5E95\u90E8 timecode + \u62CD\u6444\u5730 + \u65E5\u671F (mono, opacity 0.4)\u3002\n\n\u3010\u53EF\u9009\u9644\u52A0\u3011\n- "\u80F6\u7247\u5212\u75D5": \u51E0\u6761 1-2px \u7AD6\u5411\u767D\u7EBF, opacity 0.2, \u4E0D\u89C4\u5219\u95F4\u8DDD (\u7528 `box-shadow` \u591A\u91CD inset \u6216\u591A\u4E2A `<div>`)\u3002\n- "\u80F6\u7247\u9F7F\u5B54": letterbox \u9ED1\u8FB9\u5185, \u7B49\u8DDD\u5C0F\u767D\u65B9\u5757 (CSS repeating-linear-gradient)\u3002\n- \u5165\u573A\u52A8\u6548: \u6574\u753B\u9762\u4ECE underexposed (brightness 0.3) \u2192 normal, 800ms \u5185; \u6F0F\u5149\u4F4D\u7F6E\u7F13\u6162\u6F02\u79FB 12s \u4E00\u4E2A\u5468\u671F\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- \u989C\u8272\u7EDD\u4E0D\u8D85\u8FC7 4 \u4E2A\u8272\u76F8 (\u6DF1\u80CC\u666F + 2 \u4E2A\u6696\u6F0F\u5149\u8272 + \u6587\u5B57 cream)\u3002\n- \u4E25\u7981: \u84DD\u7D2B\u6F0F\u5149 (\u8FDD\u53CD\u80F6\u7247\u8D28\u611F)\u3001emoji\u3001\u9713\u8679\u8272\u3001\u51E0\u4F55 dashboard \u88C5\u9970\u3002\n- \u4E2D\u6587: `Noto Serif SC` italic \u4E0D\u5B58\u5728 \u2192 \u7528 `Noto Serif SC` regular + \u5B57\u8DDD\u52A0\u5927\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u63D0\u4F9B\u7684\u6807\u9898; \u81EA\u52A8\u4F30\u7B97\u5408\u7406"\u5E74\u4EFD / \u7AE0\u8282 / \u5730\u70B9" \u5143\u6570\u636E (\u4F46\u6765\u6E90\u7528\u6237\u5185\u5BB9)\u3002\n- \u5355\u6587\u4EF6 HTML, \u7528 `prefers-reduced-motion` \u5173\u52A8\u6548\u3002',enName:"Light-Leak Cinematic Frame",scenario:"video",aspectHint:"2.39:1 letterbox (1920\xD7800) \u6216 16:9 (1920\xD71080)",tags:["cinema","film","light-leak","grain","letterbox","frame"]},{id:"frame-logo-outro",name:"\u54C1\u724C Logo \u6536\u5C3E\u5E27",icon:"\u{1F3AC}",description:"Logo \u5206\u5757\u7EC4\u88C5\u5165\u573A + glow bloom + tagline \u63ED\u793A, \u9002\u5408\u89C6\u9891\u7247\u5C3E / \u54C1\u724C\u95ED\u5E55",category:"video",body:'\u3010\u6A21\u677F: Logo \u6536\u5C3E\u5E27 (Logo Outro)\u3011\n\u3010\u610F\u56FE\u3011\u89C6\u9891\u7ED3\u5C3E\u7684\u54C1\u724C reveal \u5E27 \u2014\u2014 logo \u5206\u5757\u62FC\u88C5 + glow bloom + tagline \u4E0A\u6D6E + CTA\u3002Inspired by hyperframes logo-outro\u3002\n\n\u3010\u753B\u5E03\u30111920\xD71080, \u9ED1\u8272 `#08090c` \u6216\u54C1\u724C\u6DF1\u8272\u80CC\u666F; \u52A0\u5FAE\u5999 vignette `radial-gradient(...)` \u8BA9\u4E2D\u5FC3\u66F4\u4EAE\u3002\n\n\u3010\u5E03\u5C40\u3011\n- **\u4E2D\u5FC3 Logo**: \u7528 CSS / \u5185\u8054 SVG \u7ED8\u5236; \u7531 4-8 \u4E2A\u51E0\u4F55\u5757 (\u5706 / \u65B9 / \u4E09\u89D2 / hairline) \u7EC4\u6210\u3002\n  - \u5165\u573A\u52A8\u753B: \u6BCF\u4E2A\u5757\u4ECE\u5C4F\u5E55\u5916\u6ED1\u5165 (\xB1100px \u4E0D\u540C\u65B9\u5411) + scale 1.4\u21921.0 + opacity 0\u21921, \u9519\u5CF0 80ms; \u603B\u65F6\u957F 1.2s\u3002\n  - \u5165\u573A\u5B8C\u6210\u540E, \u6574\u4E2A logo \u52A0 glow bloom: `filter: drop-shadow(0 0 24px <accent>40)`; \u540C\u65F6\u4E00\u9053 shimmer `mask-image` \u6A2A\u626B logo (500ms)\u3002\n- **\u54C1\u724C\u540D**: logo \u4E0B\u65B9 6-8% \u4F4D\u7F6E, \u5927\u5B57 (Inter Tight / SF Pro Display, 48-72px, weight 700, letter-spacing -0.02em), \u5165\u573A: typewriter or fade-up after logo bloom (1.4s \u5F00\u59CB)\u3002\n- **Tagline**: \u54C1\u724C\u540D\u4E0B\u65B9\u4E00\u884C (24-28px, weight 400, opacity 0.7), fade in (1.8s)\u3002\n- **\u5E95\u90E8 CTA + \u5143\u6570\u636E**: \u53CC\u884C\u5E95\u90E8 row, \u4F8B\u5982 `htmlanything.dev \xB7 @htmlanything \xB7 2026`, 11px uppercase letter-spacing 0.16em, \u989C\u8272 opacity 0.4, hairline \u5206\u9694\u3002\n\n\u3010\u8C03\u8272 \u2014 4 \u9009 1, \u4E0D\u6DF7\u7528\u3011\n- \u{1F30C} **Midnight Indigo** \u2014 bg `#08090c`, accent `#7c5cff` (\u9713\u8679\u7D2B\u84DD glow)\u3002\n- \u{1F305} **Solar Amber** \u2014 bg `#0e0a08`, accent `#ffb547` (\u6696\u7425\u73C0)\u3002\n- \u{1F33F} **Forest Mint** \u2014 bg `#0a1410`, accent `#5fb38a` (\u8584\u8377\u7EFF)\u3002\n- \u26AA **Bone & Ink** \u2014 bg `#f1efea`, accent `#0a0a0b` (\u65E0 neon, \u8D70 editorial \u98CE, glow \u6539\u6210\u9634\u5F71)\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- **\u7EDD\u4E0D**: \u7528\u5916\u94FE logo \u56FE\u7247; logo \u5FC5\u987B\u7528\u7EAF CSS / \u5185\u8054 SVG \u51E0\u4F55\u7ED8\u5236\u3002\n- \u5165\u573A\u52A8\u753B\u7528 `@keyframes` + `animation-delay`; \u53EF\u88AB `prefers-reduced-motion` \u5173\u95ED\u3002\n- \u5B57\u4F53: \u897F\u6587 `Inter Tight` / `SF Pro Display` / `Manrope`; \u4E2D\u6587 `Noto Sans SC` weight 700\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u63D0\u4F9B\u7684\u54C1\u724C\u540D + tagline; \u82E5\u6CA1\u6709, \u8DD1 fallback "HTML Anything" / "Anything \u2192 beautiful HTML"\u3002\n- \u5355\u6587\u4EF6 HTML; \u6574\u4E2A\u52A8\u753B\u5B8C\u6210\u540E freeze (\u4E0D\u8981 loop, \u8FD9\u662F\u89C6\u9891\u7ED3\u5C3E\u5E27)\u3002\n- \u9876\u90E8\u53EF\u9009 5px ribbon (accent \u8272) \u589E\u52A0\u54C1\u724C\u8BC6\u522B\u3002',enName:"Logo Outro Frame",scenario:"video",aspectHint:"1920\xD71080 (16:9)",tags:["logo","outro","branding","end-card","frame"]},{id:"video-hyperframes",name:"Hyperframes \u89C6\u9891\u811A\u672C",icon:"\u{1F39E}\uFE0F",description:"Hyperframes / Remotion \u517C\u5BB9\u7684\u8FDE\u7EED\u5E27\u52A8\u753B, \u53EF\u81EA\u52A8\u64AD\u653E",category:"video",body:'\u3010\u6A21\u677F: Hyperframes \u89C6\u9891\u5E27\u3011\n- \u8F93\u51FA N \u4E2A\u8FDE\u7EED `<section class="frame">`, \u6BCF\u4E2A `w-[1920px] h-[1080px]`; N \u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u4FE1\u606F\u5BC6\u5EA6\u51B3\u5B9A (\u77ED\u811A\u672C 6-10 \u5E27\u8D77\u6B65, \u957F\u811A\u672C\u5E94\u66F4\u591A, \u6BCF\u5E27\u53EA\u627F\u8F7D\u4E00\u4E2A\u955C\u5934/\u6982\u5FF5)\u3002\n- \u6BCF\u5E27\u8868\u8FBE\u4E00\u4E2A\u955C\u5934/\u6982\u5FF5: \u6587\u5B57 + \u89C6\u89C9\u6784\u56FE (\u4E2D\u592E\u6784\u56FE / \u9EC4\u91D1\u5206\u5272 / \u4E09\u5206\u6CD5)\u3002\n- \u6BCF\u5E27\u5E95\u90E8\u9690\u85CF\u6807\u8BB0 `<!-- frame:N duration:3000 transition:fade -->` \u4F9B\u540E\u7EED Remotion / Hyperframes \u6E32\u67D3\u811A\u672C\u8BFB\u53D6\u3002\n- \u9876\u90E8\u52A0\u4E00\u6BB5 JavaScript \u81EA\u52A8\u64AD\u653E: \u6BCF 3 \u79D2\u5207\u6362\u5230\u4E0B\u4E00\u5E27, \u4E5F\u652F\u6301\u70B9\u51FB / \u65B9\u5411\u952E\u63A7\u5236; \u89D2\u843D\u663E\u793A\u8FDB\u5EA6\u6761\u3002\n- \u7B2C 1 \u5E27\u662F hook (\u4E00\u4E2A\u6570\u636E / \u4E00\u4E2A\u53CD\u5E38\u8BC6 / \u4E00\u4E2A\u95EE\u9898), \u7B2C 2-N \u662F\u8BBA\u8BC1, \u6700\u540E\u662F\u7ED3\u8BBA + CTA\u3002\n- \u5B57\u53F7\u5DE8\u5927 (text-9xl), \u4E00\u53E5\u8BDD\u5373\u53EF, \u4E0D\u8981\u5806\u780C\u3002\n- \u914D\u8272\u7EDF\u4E00\u4E00\u5957\u7535\u5F71\u611F (\u6DF1\u8272\u80CC\u666F + 1 \u4E2A\u9713\u8679\u5F3A\u8C03\u8272)\u3002\n- \u8F93\u51FA\u6700\u540E\u5305\u542B\u4E00\u6BB5\u7B80\u77ED\u6CE8\u91CA `<!-- HYPERFRAMES_META: ... -->`, \u5305\u542B\u6BCF\u5E27 duration / transition / sceneSummary \u7684 JSON \u5143\u6570\u636E, \u7528\u4E8E\u540E\u7EED\u8F6C Remotion\u3002',enName:"Hyperframes Video",scenario:"video",aspectHint:"1920\xD71080 (16:9)",tags:["video","hyperframes","remotion","\u89C6\u9891"]},{id:"frame-data-chart-nyt",name:"NYT \u98CE\u6570\u636E\u56FE\u8868\u5E27",icon:"\u{1F4C8}",description:"NYT-newsroom \u6392\u7248 + \u9519\u5CF0\u63ED\u793A\u52A8\u753B + \u7F16\u8F91\u7EA7\u56FE\u8868 (\u6298\u7EBF/\u67F1/\u8303\u56F4\u5E26)",category:"video",body:'\u3010\u6A21\u677F: NYT \u98CE\u6570\u636E\u56FE\u8868\u5E27\u3011\n\u3010\u610F\u56FE\u3011\u628A\u4E00\u6BB5\u6570\u636E (CSV / JSON / \u4E00\u53E5\u7ED3\u8BBA) \u505A\u6210\u300A\u7EBD\u7EA6\u65F6\u62A5\u300B\u4E13\u680F\u611F\u7684\u5355\u5E27/\u52A8\u753B\u56FE\u8868, \u9002\u5408\u89C6\u9891\u7247\u6BB5\u6216\u63A8\u7279\u5361\u3002Inspired by hyperframes data-chart\u3002\n\n\u3010\u753B\u5E03\u30111920\xD71080, \u6696\u767D\u5E95 `#f7f5ee` \u6216\u58A8\u9ED1\u5E95 `#0e0e0e` \u4E8C\u9009\u4E00; \u6587\u5B57\u8272\u548C\u80CC\u666F\u76F8\u53CD\u3002\n\n\u3010\u5E03\u5C40\u3011\n- **\u9876\u90E8 kicker** (11px uppercase letterspace 0.14em, \u989C\u8272 = accent \u7EA2 `#a91d1d` \u6216 mint `#5fb38a`): \u6570\u636E\u6765\u6E90 + \u7C7B\u76EE, \u5982 "GLOBAL \xB7 WEEKLY ACTIVE USERS \xB7 2018\u20132026"\u3002\n- **\u5927\u5B57\u6807\u9898** (Cheltenham / Playfair / Source Serif Pro, 5.6vw, italic \u526F\u6807\u53EF\u9009): \u4E00\u53E5\u7ED3\u8BBA\u3002**\u7ED3\u8BBA\u5FC5\u987B\u4ECE\u7528\u6237\u6570\u636E\u4E2D\u63D0\u70BC**, \u4E0D\u662F\u63CF\u8FF0\u56FE\u3002\n- **\u56FE\u8868\u533A** (\u5360\u753B\u5E03 55-65%):\n  - \u6298\u7EBF: 1-2 \u6761\u7EBF, \u4E3B\u7EBF ink \u5B9E\u5FC3 2.5px, \u6B21\u7EBF dashed 1.5px; \u6570\u636E\u70B9\u7528 6px \u5B9E\u5FC3\u5706; \u5173\u952E\u70B9\u65C1\u6807\u6CE8 `2024 \xB7 412M` \u9ED1\u8272 mono \u5C0F\u5B57\u3002\n  - \u67F1\u72B6: \u5168\u90E8 ink \u5355\u8272\u6216\u52A0 1 \u9053 accent \u9AD8\u4EAE\u67F1; \u67F1\u9876\u5927\u6570\u5B57; \u67F1\u5E95\u7C7B\u76EE\u659C\u4F53 (Cheltenham italic)\u3002\n  - \u8303\u56F4\u5E26 (range band): \u6D45\u7070\u586B\u5145 `#e6e2d2` \u5305\u7EDC + \u4E2D\u7EBF ink\u3002\n- **\u5E95\u90E8 source + footnote** (10px mono, opacity 0.6): "Source: \u7528\u6237\u6570\u636E \xB7 Chart by html-anything"\u3002\n- **\u9519\u5CF0\u63ED\u793A\u52A8\u753B**: \u6807\u9898 fade-in (0s), kicker (200ms), \u6298\u7EBF stroke-dashoffset 1.2s ease-out (400ms), \u6570\u636E\u6807\u7B7E\u4F9D\u6B21 100ms \u95F4\u9694\u3002\u53EF\u88AB `prefers-reduced-motion` \u5173\u95ED\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- **\u7EDD\u4E0D**: \u4F7F\u7528 chart.js / d3 \u5E93 (\u9664\u975E jsdelivr CDN \u5F15\u5165); \u63A8\u8350\u624B\u5199 SVG, \u4E0D\u8D85\u8FC7 80 \u884C inline\u3002\n- \u5B57\u4F53: \u6807\u9898 `Source Serif Pro` \u6216 `Cheltenham` (\u65E0\u5219\u7528 `Playfair Display`); body `IBM Plex Sans` \u6216 `Inter`; \u6570\u636E\u6807\u7B7E `IBM Plex Mono`\u3002\n- 1 \u4E2A\u4E3B\u8272 (ink) + 1 \u4E2A accent (NYT red `#a91d1d` / \u7F16\u8F91 mint `#5fb38a` / \u6696\u6A59 `#d97757` \u4E09\u9009\u4E00)\u3002\n- Y \u8F74\u523B\u5EA6\u4EC5 hairline + 3-4 \u4E2A tick, \u6807\u7B7E\u5728\u8F74\u5916\u4FA7 mono \u5B57\u3002\n- \u4E25\u7981 grid \u5168\u5C4F\u94FA\u7EBF\u3001\u9634\u5F71\u30013D \u7ACB\u4F53\u67F1; \u4E25\u7981 emoji\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u63D0\u4F9B\u7684\u6570\u636E\u3002\u5982\u679C\u8F93\u5165\u662F\u6587\u672C\u7ED3\u8BBA, \u81EA\u52A8\u4F30\u7B97\u5408\u7406\u5750\u6807 (\u4F46\u8981\u6807\u6CE8 "schematic"); \u5982\u679C\u662F CSV/JSON, \u76F4\u63A5\u7ED8\u5236\u3002\n- \u5355\u6587\u4EF6 HTML; \u6570\u636E\u70B9\u65C1\u6CE8\u91CA\u683C\u5F0F: `<text class="annot">2024 \xB7 412M</text>`\u3002',enName:"NYT-Style Data Chart Frame",scenario:"video",aspectHint:"1920\xD71080 (16:9)",tags:["data","chart","nyt","editorial","frame"]},{id:"vfx-text-cursor",name:"VFX \u6587\u5B57\u5149\u6807",icon:"\u2728",description:"\u5149\u6807\u62D6\u5149 + \u5F69\u8272\u50CF\u6563\u5C04\u7EBF + \u5B9A\u5411\u5149\u6591, \u9002\u5408\u89C6\u9891\u7247\u5934\u9010\u5B57\u63ED\u793A\u91D1\u53E5",category:"video",body:'\u3010\u6A21\u677F: VFX \u6587\u5B57\u5149\u6807 (Text Cursor)\u3011\n\u3010\u610F\u56FE\u3011\u89C6\u9891\u5F00\u573A/Hero \u5E27 \u2014\u2014 \u5149\u6807\u5728\u753B\u5E03\u4E0A"\u6253\u5B57", \u6587\u5B57\u9010\u5B57\u6D6E\u73B0, \u540E\u9762\u62D6\u7740\u5F69\u8272\u50CF\u6563\u5C3E\u8FF9 + \u5B9A\u5411\u5149\u6591\u3002Inspired by hyperframes vfx-text-cursor\u3002\n\n\u3010\u753B\u5E03\u30111920\xD71080, \u80CC\u666F `#06070a` \u6697\u54D1\u9ED1 \u6216 `#0a0d12` (\u6709\u6696\u504F\u84DD); \u52A0\u5FAE\u5999 vignette\u3002\n\n\u3010\u5185\u5BB9\u3011\n- \u4E00\u53E5\u91D1\u53E5 (\u4E2D\u82F1\u4E0D\u9650), \u5C45\u4E2D, \u5B57\u53F7 6-8vw, weight 700, \u5B57\u4F53 `Inter Tight` / `Source Sans 3` / `Noto Sans SC`\u3002\n- \u9010\u5B57\u63ED\u793A, \u6BCF\u4E2A\u5B57\u7B26 80ms \u95F4\u9694; \u5F53\u524D\u5B57\u7B26\u540E\u9762\u8DDF\u7740\u4E00\u4E2A cursor `\u258D` (\u6216\u7EC6 vertical bar)\u3002\n- \u5DF2\u63ED\u793A\u6587\u5B57\u9ED8\u8BA4\u767D\u8272 `#f5f5f7`, opacity 1; \u5373\u5C06\u63ED\u793A\u4F4D\u7F6E\u52A0 chromatic ghost: \u4E00\u4EFD `text-shadow: 2px 0 #ff3b6f, -2px 0 #00d4ff` \u5728 reveal \u77AC\u95F4, 200ms \u5185\u6536\u655B\u56DE\u6B63\u5E38\u3002\n- \u5149\u6807\u672C\u8EAB: 16px \u5BBD\u77E9\u5F62, \u989C\u8272 = accent (\u53D6 1: hot pink `#ff3b6f` / cyan `#00d4ff` / amber `#ffb547`), \u95EA\u70C1 `@keyframes` 1.0s \u5468\u671F; \u540E\u9762\u62D6\u4E00\u6761 60-120px \u7684 motion blur trail (\u5F84\u5411\u6E10\u53D8\u5230\u900F\u660E)\u3002\n\n\u3010\u5149\u6591 / \u5C04\u7EBF\u3011\n- \u5728\u6253\u5B57\u4F4D\u7F6E\u9644\u8FD1\u968F\u673A\u751F\u6210 3-5 \u9053**\u5B9A\u5411\u5149\u6591** (light leak): \u7528 `linear-gradient(45deg, transparent, accent20, transparent)` \u7684\u7EC6\u957F\u77E9\u5F62 + `mix-blend-mode: screen`, \u4E0D\u89C4\u5219\u89D2\u5EA6\u3002\n- \u5F53\u6587\u5B57\u6253\u5B8C, \u6574\u6BB5\u6587\u5B57\u52A0 0.5s shimmer sweep (\u5149\u5E26\u6A2A\u626B)\u3002\n\n\u3010\u5B57\u6BB5\u3011\n- \u9876\u90E8 caption (uppercase letterspace 0.18em, 11px, opacity 0.5): "FRAME 01 \xB7 OPENING"\u3002\n- \u6587\u5B57\u5E95\u4E0B\u526F\u6807 (24-28px, opacity 0.6): \u6765\u6E90 / \u7AE0\u8282\u3002\n- \u53F3\u4E0B\u89D2 timecode (`00:03:21` mono)\u3002\n\n\u3010\u8BBE\u8BA1\u7EC6\u8282\u3011\n- **\u7EDD\u4E0D**: \u591A\u8272\u5F69\u8679 chromatic (\u53EA\u7528 1 \u4E2A hot pink + cyan \u8FD9\u79CD\u4E8C\u5143\u50CF\u6563, \u4E0D\u8981 R/G/B \u5168\u8272)\u3002\n- \u5B57\u4F53: \u897F\u6587 `Inter Tight` Bold; \u4E2D\u6587 `Noto Sans SC` Bold; \u4E25\u7981\u886C\u7EBF\u3002\n- \u52A8\u6548\u7528 `@keyframes` + JS \u8BA1\u65F6\u5668 (`setTimeout` \u9010\u5B57), \u53EF\u88AB `prefers-reduced-motion` \u5173\u95ED (\u76F4\u63A5\u663E\u793A\u6240\u6709\u5B57)\u3002\n- \u5FC5\u987B\u7528\u7528\u6237\u63D0\u4F9B\u7684\u91D1\u53E5; \u4E0D\u8981\u634F\u9020\u3002\n- \u5355\u6587\u4EF6 HTML, \u4E0D\u8981\u5916\u94FE\u5B57\u4F53\u4EE5\u5916\u7684\u8D44\u6E90\u3002',enName:"VFX Text Cursor",scenario:"video",aspectHint:"1920\xD71080 (16:9)",tags:["vfx","text","cursor","chromatic","reveal","frame"]}];var vt=[{id:"custom",name:"\u81EA\u5B9A\u4E49\u6A21\u5F0F",icon:"palette"},{id:"design",name:"AI\u6A21\u5F0F",icon:"sparkles"}],G=[...yt];var ki='\n\u4F60\u662F\u4E16\u754C\u7EA7\u7684\u89C6\u89C9\u8BBE\u8BA1\u5E08 + \u8D44\u6DF1\u524D\u7AEF\u5DE5\u7A0B\u5E08\u3002\u8BF7\u8F93\u51FA\u4E00\u4EFD**\u81EA\u5305\u542B\u7684\u5355\u6587\u4EF6 HTML**\uFF0C\u8981\u6C42\uFF1A\n\n\u3010\u5185\u5BB9\u9A71\u52A8\u6570\u91CF \u2014 \u6700\u9AD8\u4F18\u5148\u7EA7, \u8986\u76D6\u6A21\u677F\u91CC\u7684\u4EFB\u4F55\u6570\u5B57\u3011\n- \u6A21\u677F\u53EA\u5B9A\u4E49"\u53EF\u7528\u7248\u9762 / \u98CE\u683C / \u914D\u8272 / \u5B57\u4F53 / \u7EC4\u4EF6\u5E93", **\u4E0D\u5B9A\u4E49** slide / \u5E27 / \u5361\u7247 / section \u7684\u6570\u91CF\u3002\n- \u8F93\u51FA\u7684 slide / frame / card / section \u6570\u91CF**\u5B8C\u5168\u7531\u3010\u7528\u6237\u5185\u5BB9\u3011\u7684\u5B9E\u9645\u957F\u5EA6\u548C\u4FE1\u606F\u7ED3\u6784\u51B3\u5B9A**\u3002\u5FC5\u987B**\u5B8C\u6574\u8986\u76D6**\u7528\u6237\u5185\u5BB9\u7684\u6BCF\u4E00\u4E2A\u8981\u70B9\u3001\u7AE0\u8282\u3001\u6570\u636E\u7EC4, **\u4E0D\u8BB8\u603B\u7ED3\u3001\u538B\u7F29\u3001\u4E22\u5F03\u4FE1\u606F**\u3002\n- \u5982\u679C\u6A21\u677F\u6B63\u6587\u91CC\u5199\u4E86\u7C7B\u4F3C"\u6311 6-10 \u5F20\u7EC4\u6210 deck / \u8F93\u51FA 6-10 \u5E27 / 3-6 \u5F20\u5361\u7247"\u7684\u6570\u5B57, **\u4E00\u5F8B\u89C6\u4E3A\u77ED\u793A\u4F8B\u4E0B\u7684\u53C2\u8003\u4E0B\u9650, \u4E0D\u662F\u4E0A\u9650**\u3002\u77ED\u5185\u5BB9\u53EF\u4EE5\u4F4E\u4E8E\u8BE5\u8303\u56F4, \u957F\u5185\u5BB9\u5E94\u8FDC\u8D85\u8BE5\u8303\u56F4\u3002\n- \u63A8\u8350\u505A\u6CD5: \u5148\u628A\u3010\u7528\u6237\u5185\u5BB9\u3011\u6309\u8BED\u4E49\u5207\u6210\u82E5\u5E72\u6BB5 (\u7AE0\u8282\u6807\u9898 / \u8BBA\u70B9 / \u6570\u636E\u7EC4 / \u5217\u8868\u9879 / \u6B65\u9AA4), \u6BCF\u4E00\u6BB5 \u2192 \u81F3\u5C11\u4E00\u4E2A\u72EC\u7ACB\u7684 slide / section / card, \u7136\u540E\u518D\u4ECE\u6A21\u677F\u7684\u7248\u5F0F\u6C60\u91CC\u7ED9\u6BCF\u4E00\u6BB5\u6311\u6700\u5408\u9002\u7684\u7248\u9762\u3002\u5B81\u53EF\u591A\u9875\u4E5F\u4E0D\u8981\u628A\u591A\u4E2A\u72EC\u7ACB\u8981\u70B9\u786C\u585E\u8FDB\u4E00\u9875\u3002\n\n\u3010\u786C\u6027\u6280\u672F\u8981\u6C42\u3011\n- **\u7981\u6B62\u4F7F\u7528 Write / Edit / MultiEdit / Bash / Create / \u4EFB\u4F55\u6587\u4EF6\u7CFB\u7EDF\u5DE5\u5177**\u3002\u4E0D\u8981\u628A HTML \u5199\u5230\u4EFB\u4F55 `.html` \u6587\u4EF6\u91CC\u3002\n- \u76F4\u63A5\u628A\u5B8C\u6574\u7684 HTML \u6587\u6863\u4F5C\u4E3A\u52A9\u624B\u56DE\u590D\u7684\u6B63\u6587\u6D41\u5F0F\u8F93\u51FA\u3002\u4E0D\u8981\u5148\u8BF4"\u6211\u6765\u751F\u6210"\u3001"\u5DF2\u8F93\u51FA\u81F3 \u2026"\u4E4B\u7C7B\u7684\u8BDD\u3002\n- \u6587\u6863\u4EE5 `<!DOCTYPE html>` \u5F00\u5934, \u672B\u5C3E\u4EE5 `</html>` \u7ED3\u675F\u3002\n- \u5728 `<head>` \u4E2D\u901A\u8FC7 CDN \u5F15\u5165 Tailwind v3 Play (https://cdn.tailwindcss.com) \u4E0E\u6240\u9700\u7684 Google Fonts\u3002\n- \u4E0D\u8981\u5F15\u7528\u4EFB\u4F55\u5916\u90E8\u56FE\u7247 URL\uFF08\u9664\u975E\u4F60\u80FD\u4FDD\u8BC1 URL \u957F\u671F\u6709\u6548\uFF1B\u4F18\u5148\u4F7F\u7528 CSS / SVG \u5185\u8054\u7ED8\u5236\uFF09\u3002\n- \u5FC5\u8981\u7684\u811A\u672C\uFF08\u56FE\u8868\u3001\u52A8\u753B\uFF09\u901A\u8FC7 jsdelivr CDN \u5F15\u5165\uFF1B\u4FDD\u6301\u5355\u6587\u4EF6\u53EF\u53CC\u51FB\u6253\u5F00\u5373\u7528\u3002\n- \u8F93\u51FA**\u7EAF HTML**, \u4E0D\u8981\u7528 markdown \u4EE3\u7801\u56F4\u680F\u5305\u88F9, \u4E0D\u8981\u4EFB\u4F55\u89E3\u91CA\u6027\u6587\u5B57\u3002\u7B2C\u4E00\u4E2A\u5B57\u7B26\u5FC5\u987B\u662F `<`\u3002\n\n\u3010\u8BBE\u8BA1\u51C6\u5219 \u2014 \u4E16\u754C\u7EA7\u6807\u51C6\u3011\n- \u6392\u7248: \u4E2D\u6587\u4F18\u5148 `Noto Sans SC` / `Noto Serif SC`, \u82F1\u6587 `Inter` / `Manrope` / `SF Pro` \u98CE\u683C\u3002\n- \u8272\u5F69: \u4F7F\u7528 1 \u4E2A\u4E3B\u8272 + 2 \u4E2A\u4E2D\u6027\u8272 + \u81F3\u591A 1 \u4E2A\u5F3A\u8C03\u8272; \u5927\u80C6\u7559\u767D; \u4E0D\u4F7F\u7528\u7EAF\u9ED1\u7EAF\u767D (#000/#fff), \u6539\u7528 `#0a0a0a` / `#fafafa`\u3002\n- \u7F51\u683C: 8 px \u57FA\u7EBF; \u6BB5\u843D\u6700\u5927\u5BBD\u5EA6 65 ch; \u6807\u9898\u4E0E\u6B63\u6587\u6709\u6E05\u6670\u7684\u5C42\u7EA7\u3002\n- \u5FAE\u89C2\u7EC6\u8282: \u5706\u89D2\u7EDF\u4E00 (rounded-xl/2xl), \u6295\u5F71\u67D4\u548C (shadow-sm/lg), \u8FB9\u6846 1px `#e5e7eb` / `#262626`\u3002\n- \u52A8\u6548: \u4EC5\u5728\u5FC5\u8981\u5904\u4F7F\u7528 `transition-all` \u6216\u5165\u573A fade-in; \u4E0D\u8981\u55A7\u5BBE\u593A\u4E3B\u3002\n- \u65E0\u969C\u788D: \u989C\u8272\u5BF9\u6BD4\u5EA6 \u2265 4.5; \u91CD\u8981\u4EA4\u4E92\u6709 focus \u6001\u3002\n\n\u3010\u5185\u5BB9\u771F\u5B9E\u6027\u3011\n- **\u5FC5\u987B\u4F7F\u7528\u7528\u6237\u63D0\u4F9B\u7684\u771F\u5B9E\u6570\u636E**, \u4E0D\u8981\u7F16\u9020\u3001\u4E0D\u8981 lorem ipsum\u3001\u4E0D\u8981 "Your text here"\u3002\n- \u5982\u679C\u7528\u6237\u6570\u636E\u662F\u7ED3\u6784\u5316\u6570\u636E (CSV/JSON), \u8BF7\u63D0\u53D6\u5173\u952E\u6D1E\u5BDF\u5E76\u4EE5\u56FE\u8868/\u8868\u683C\u5448\u73B0\u3002\n- \u4E2D\u6587\u4E0E\u82F1\u6587\u6DF7\u6392\u65F6, \u4E2D\u82F1\u6587\u4E4B\u95F4\u7559\u534A\u89D2\u7A7A\u683C (\u76D8\u53E4\u4E4B\u767D)\u3002\n\n\u3010Markdown \u6269\u5C55\u8BED\u6CD5\u6E32\u67D3 \u2014 \u5FC5\u987B\u652F\u6301\u3011\n\u7528\u6237\u7684 Markdown \u4E2D\u53EF\u80FD\u5305\u542B\u4EE5\u4E0B\u975E\u6807\u51C6/\u6269\u5C55\u8BED\u6CD5\uFF0C\u4F60\u5FC5\u987B\u6B63\u786E\u8BC6\u522B\u5E76\u5728 HTML \u4E2D\u9AD8\u8D28\u91CF\u6E32\u67D3\uFF1A\n1. `==\u9AD8\u4EAE\u6587\u672C==` (Obsidian \u9AD8\u4EAE\u8BED\u6CD5) \u2192 \u8F6C\u6362\u4E3A `<mark>\u9AD8\u4EAE\u6587\u672C</mark>`\uFF0C\u5E76\u6DFB\u52A0\u9192\u76EE\u7684\u9AD8\u4EAE\u80CC\u666F\u6837\u5F0F\uFF08\u5982\u9EC4\u8272\u534A\u900F\u660E\u5E95\u8272 + \u5706\u89D2\uFF09\u3002\n2. `<u>\u4E0B\u5212\u7EBF\u6587\u672C</u>` \u2192 \u4FDD\u7559 `<u>` \u6807\u7B7E\uFF0C\u6DFB\u52A0\u4E0B\u5212\u7EBF\u6837\u5F0F\uFF08\u5EFA\u8BAE\u5E26\u989C\u8272\u504F\u79FB\u7684\u4E0B\u5212\u7EBF\uFF0C\u907F\u514D\u9ED8\u8BA4\u6837\u5F0F\u8FC7\u4E8E\u751F\u786C\uFF09\u3002\n3. `####` / `#####` / `######` \u2192 \u8F6C\u6362\u4E3A `<h4>` / `<h5>` / `<h6>`\uFF0C\u5FC5\u987B\u8BBE\u7F6E\u6E05\u6670\u7684\u5B57\u53F7\u5C42\u7EA7\u548C\u95F4\u8DDD\uFF08H4 \u6BD4 H3 \u5C0F\u4E00\u7EA7\uFF0C\u4EE5\u6B64\u7C7B\u63A8\uFF09\uFF0C\u4E0D\u8981\u4F7F\u7528\u548C\u6B63\u6587\u4E00\u6837\u7684\u5B57\u53F7\u3002\n4. `- [ ] \u672A\u5B8C\u6210\u4EFB\u52A1` / `- [x] \u5DF2\u5B8C\u6210\u4EFB\u52A1` \u2192 \u6E32\u67D3\u4E3A\u7F8E\u89C2\u7684\u4EFB\u52A1\u5217\u8868\u3002\u4E0D\u8981\u4F7F\u7528\u539F\u751F `<input type="checkbox">`\uFF08\u6837\u5F0F\u4E0D\u53EF\u63A7\uFF09\uFF0C\u63A8\u8350\u7528 SVG \u6216\u7EAF CSS \u7ED8\u5236 checkbox\uFF08\u2713 \u7B26\u53F7 + \u65B9\u6846\uFF09\uFF0C\u5DF2\u52FE\u9009\u548C\u672A\u52FE\u9009\u8981\u6709\u660E\u663E\u7684\u89C6\u89C9\u5DEE\u5F02\u3002\n5. `$$...$$` \u6570\u5B66\u516C\u5F0F\u5757 \u548C `$...$` \u884C\u5185\u6570\u5B66\u516C\u5F0F \u2192 \u5FC5\u987B\u5728 `<head>` \u4E2D\u5F15\u5165 KaTeX CDN\uFF08https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css \u53CA\u5BF9\u5E94 JS\uFF09\uFF0C\u4F7F\u7528 KaTeX \u5C06\u516C\u5F0F\u6E32\u67D3\u4E3A\u9AD8\u8D28\u91CF\u6392\u7248 HTML\u3002\u6CE8\u610F\uFF1ALaTeX \u516C\u5F0F\u5185\u5BB9\u4E0D\u8981 escape\uFF0C\u4FDD\u6301\u539F\u6837\u4F20\u7ED9 KaTeX\u3002\n6. ```mermaid` \u56FE\u8868\u4EE3\u7801\u5757 \u2192 \u5FC5\u987B\u5728 `<head>` \u4E2D\u5F15\u5165 Mermaid CDN\uFF08https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js\uFF09\u3002\u5C06 mermaid \u4EE3\u7801\u5757\u7684\u5185\u5BB9\u539F\u6837\u5305\u88F9\u5728 `<div class="mermaid">` \u4E2D\uFF08\u4E0D\u8981\u5BF9\u5185\u5BB9\u8FDB\u884C HTML \u8F6C\u4E49\uFF09\uFF0C\u5E76\u5728\u9875\u9762\u5E95\u90E8\u6DFB\u52A0 `<script>mermaid.initialize({startOnLoad:true});</script>`\u3002\u652F\u6301\u6D41\u7A0B\u56FE(flowchart)\u3001\u65F6\u5E8F\u56FE(sequenceDiagram)\u3001\u7C7B\u56FE(classDiagram)\u3001\u7518\u7279\u56FE(gantt)\u3001\u72B6\u6001\u56FE(stateDiagram)\u7B49\u3002\u5982\u679C\u540C\u65F6\u5B58\u5728\u591A\u4E2A mermaid \u56FE\u8868\uFF0C\u6BCF\u4E2A\u90FD\u4F7F\u7528\u72EC\u7ACB\u7684 `<div class="mermaid">` \u5305\u88F9\u3002\n',xt=`\u3010\u6A21\u677F: \u81EA\u5B9A\u4E49\u6A21\u5F0F \u5E7B\u706F\u7247 / Presentation Deck\u3011
\u3010\u610F\u56FE\u3011\u5C06 Markdown \u5185\u5BB9\u8F6C\u6362\u4E3A\u6A2A\u5411\u5E7B\u706F\u7247, \u6BCF\u9875\u4E00\u4E2A <section>, \u652F\u6301\u952E\u76D8/\u89E6\u6478\u7FFB\u9875\u3002
\u3010\u6838\u5FC3\u89C4\u5219 \u2014 \u5FC5\u987B\u4E25\u683C\u9075\u5B88\u3011
1. \u5206\u9875: Markdown \u4E2D\u7684 \`---\` (\u5355\u72EC\u4E00\u884C\u7684\u6C34\u5E73\u5206\u5272\u7EBF) \u662F**\u5E7B\u706F\u7247\u5206\u9875\u7B26**\u3002\u6309 \`---\` \u5C06\u5185\u5BB9\u5207\u5206\u4E3A\u82E5\u5E72\u9875, \u6BCF\u4E00\u9875\u751F\u6210\u4E00\u4E2A <section class="slide">\u3002
2. YAML \u6307\u4EE4\u89E3\u6790: \u7528\u6237\u7684 frontmatter \u4E2D\u53EF\u80FD\u5305\u542B\u81EA\u5B9A\u4E49\u6A21\u5F0F\u6307\u4EE4, \u4F60\u5FC5\u987B\u8BC6\u522B\u5E76\u5E94\u7528:
   - theme: \u4E3B\u9898\u540D\u79F0 (\u4F60\u6839\u636E\u540D\u79F0\u9009\u62E9\u5408\u9002\u7684\u914D\u8272\u65B9\u6848)
   - paginate: true/false \u2014 \u662F\u5426\u5728\u53F3\u4E0B\u89D2\u663E\u793A\u9875\u7801
   - size: 16:9 (\u9ED8\u8BA4) \u6216 4:3 \u2014 \u51B3\u5B9A\u5E7B\u706F\u7247\u5BBD\u9AD8\u6BD4
   - class: \u5168\u5C40 CSS \u7C7B\u540D, \u52A0\u5230\u6BCF\u4E2A <section> \u4E0A
   - backgroundColor / backgroundImage / backgroundSize / backgroundPosition / backgroundRepeat: \u5168\u5C40\u80CC\u666F\u8BBE\u7F6E
   - color: \u5168\u5C40\u6587\u5B57\u989C\u8272
   - header / footer: \u5168\u5C40\u9875\u7709\u9875\u811A\u6587\u672C
   - headingDivider: \u5982\u8BBE\u4E3A 2, \u8868\u793A\u6BCF\u4E2A ## \u6807\u9898\u81EA\u52A8\u5F00\u542F\u65B0\u5E7B\u706F\u7247
   - style: \u989D\u5916\u539F\u59CB CSS, \u76F4\u63A5\u6CE8\u5165 <style>
   \u5C40\u90E8\u6307\u4EE4(\u4EE5 _ \u524D\u7F00, \u5982 _backgroundColor: red): \u53EA\u4F5C\u7528\u4E8E**\u7D27\u8DDF\u5176\u540E\u7684\u90A3\u4E00\u9875**\u3002
   - layout: \u7248\u5F0F\u6A21\u677F \u2014 \u63A7\u5236\u5F53\u524D\u9875\u7684\u5E03\u5C40\u7ED3\u6784\u3002\u53EF\u9009\u503C:
     \xB7 default \u2014 \u6807\u51C6\u9875\uFF08\u6807\u9898+\u5185\u5BB9\u81EA\u4E0A\u800C\u4E0B\uFF0C\u9ED8\u8BA4\uFF09
     \xB7 cover \u2014 \u5C01\u9762\u9875\uFF08\u5927\u6807\u9898\u5C45\u4E2D\u653E\u5927\uFF0C\u9002\u5408\u9996\u5C4F\uFF09
     \xB7 center \u2014 \u5C45\u4E2D\u9875\uFF08\u6240\u6709\u5185\u5BB9\u5C45\u4E2D\u5806\u53E0\uFF09
     \xB7 two-cols \u2014 \u53CC\u680F\u5E03\u5C40\uFF08\u5DE6\u4FA7\u9ED8\u8BA4\u5185\u5BB9\uFF0C\u53F3\u4FA7\u7528 ::right:: \u5206\u9694\uFF09
     \xB7 statement \u2014 \u91D1\u53E5\u9875\uFF08\u8D85\u5927\u5B57\u53F7\u5C45\u4E2D\u5F15\u7528\uFF09
     \xB7 section \u2014 \u7AE0\u8282\u5206\u9694\u9875\uFF08\u4EC5\u4FDD\u7559\u5927\u6807\u9898\uFF0C\u6781\u7B80\uFF09
     \u7528\u6237\u901A\u8FC7\u6BCF\u9875\u524D\u7684 frontmatter \u6307\u5B9A: ---
layout: cover
---
3. \u5E7B\u706F\u7247\u5C3A\u5BF8: \u9ED8\u8BA4 16:9 (width: 1280px, height: 720px)\u3002\u5E7B\u706F\u7247\u5BB9\u5668\u4F7F\u7528\u56FA\u5B9A\u6BD4\u4F8B, \u5728\u6D4F\u89C8\u5668\u4E2D\u5C45\u4E2D\u663E\u793A, \u4FDD\u6301\u6BD4\u4F8B\u7F29\u653E\u3002
4. \u5185\u5BB9\u6620\u5C04: \u4E0D\u8981\u628A\u591A\u9875\u5185\u5BB9\u585E\u8FDB\u4E00\u9875\u3002\u6BCF\u4E00\u9875\u53EA\u653E\u5BF9\u5E94 \`---\` \u533A\u95F4\u5185\u7684\u5185\u5BB9\u3002\u5982\u679C\u67D0\u9875\u5185\u5BB9\u592A\u957F, \u53EF\u4EE5\u9002\u5F53\u7F29\u5C0F\u5B57\u53F7\u6216\u8C03\u6574\u5E03\u5C40, \u4F46\u4E0D\u8981\u62C6\u5206\u5230\u5176\u4ED6\u9875\u3002
5. \u6392\u7248: \u6BCF\u9875\u6807\u9898\u7528 <h1> \u6216 <h2>, \u6B63\u6587\u7528 <p> / <ul> / <ol> / <table> / <blockquote>\u3002\u5217\u8868\u9879\u8981\u6E05\u6670, \u4E0D\u8981\u62E5\u6324\u3002
6. \u8BBE\u8BA1\u7EC6\u8282:
   - \u9ED8\u8BA4\u4F7F\u7528\u6DF1\u8272\u6E10\u53D8\u80CC\u666F (#0f172a \u2192 #1e1b4b), \u6587\u5B57\u767D\u8272/\u6D45\u7070, \u8425\u9020\u4E13\u4E1A\u6F14\u793A\u6C1B\u56F4
   - \u652F\u6301 theme \u6307\u4EE4\u5207\u6362\u914D\u8272: default(\u6DF1\u84DD), gaia(\u767D\u5E95\u9ED1\u5B57), uncover(\u9ED1\u5E95\u767D\u5B57)
   - \u4EE3\u7801\u5757\u4F7F\u7528\u6DF1\u8272\u80CC\u666F + \u8BED\u6CD5\u9AD8\u4EAE\u98CE\u683C
   - \u8868\u683C\u4F7F\u7528\u534A\u900F\u660E\u5361\u7247\u98CE\u683C
   - \u5F15\u7528\u5757\u4F7F\u7528\u5DE6\u4FA7\u8272\u6761
7. \u4EA4\u4E92: \u5728 <script> \u4E2D\u5B9E\u73B0\u952E\u76D8\u7FFB\u9875 (\u5DE6\u53F3\u7BAD\u5934\u3001\u7A7A\u683C\u3001PgUp/PgDown) \u548C\u70B9\u51FB\u7FFB\u9875\u3002\u663E\u793A\u5F53\u524D\u9875\u7801 / \u603B\u9875\u6570\u3002\u9996\u5C4F\u663E\u793A "\u6309 \u2192 \u6216\u7A7A\u683C\u7FFB\u9875" \u63D0\u793A, 2 \u79D2\u540E\u6DE1\u51FA\u3002
8. \u8F93\u51FA\u7ED3\u6784:
   <div id="custom-deck">
     <section class="slide" ...>\u7B2C1\u9875\u5185\u5BB9</section>
     <section class="slide" ...>\u7B2C2\u9875\u5185\u5BB9</section>
     ...
   </div>
   \u52A0\u4E0A\u7FFB\u9875\u63A7\u5236 UI \u548C\u952E\u76D8\u4E8B\u4EF6\u811A\u672C\u3002`;function wt(i){let a=i.split(`
`),e=[];for(let t of a){let n=t.match(/^([a-zA-Z_]\w*):\s*(.+)$/);if(n){let o=n[1],s=n[2].trim();["theme","paginate","class","backgroundColor","backgroundImage","backgroundSize","backgroundPosition","backgroundRepeat","color","header","footer","size","headingDivider","math","lang","style","layout"].includes(o)&&e.push(`${o}: ${s}`)}}return e.length>0?e.join(`
`):"(\u65E0\u989D\u5916\u6307\u4EE4)"}function Pe(i){return G.find(a=>a.id===i)}function Ge(i,a,e){let t=[ki.trim()];return e&&t.push(e),t.push(i.trim()),t.push("\u3010\u8F93\u5165\u683C\u5F0F\u3011: markdown"),t.push("\u3010\u7528\u6237\u5185\u5BB9\u3011:"),t.push(a),t.join(`

`)+`
`}var L=require("obsidian");var ue='## LumiSlate \u81EA\u5B9A\u4E49\u6A21\u5F0F CSS \u67B6\u6784\u89C4\u8303\uFF08\u5FC5\u987B\u9075\u5B88\uFF09\n\n### 1. \u67B6\u6784\u6982\u8FF0\n\u81EA\u5B9A\u4E49\u6A21\u5F0F\u5C06 Markdown \u6309 `---` \u5206\u9875\u7B26\u5207\u5206\u4E3A\u82E5\u5E72\u9875\uFF0C\u6BCF\u9875\u6E32\u67D3\u4E3A\u4E00\u4E2A `<section>` \u5143\u7D20\u3002\n- \u6240\u6709\u6837\u5F0F\u5FC5\u987B\u4F7F\u7528 `section` \u4F5C\u4E3A\u6839\u9009\u62E9\u5668\uFF08\u5982 `section h1`\u3001`section p`\uFF09\n- **\u4E25\u7981\u4F7F\u7528 `.slide` \u7C7B\u9009\u62E9\u5668**\uFF1A\u8FD9\u662F\u63D2\u4EF6\u5E03\u5C40\u5F15\u64CE\u7684\u4FDD\u7559\u7C7B\uFF0C\u5BF9\u5176\u8BBE\u7F6E\u6837\u5F0F\u4F1A\u88AB\u5F3A\u5236\u8986\u76D6\n- \u63D2\u4EF6\u5728 :root \u4E2D\u9884\u5B9A\u4E49 `--ls-*` CSS \u53D8\u91CF\uFF0C\u8986\u76D6\u5B83\u4EEC\u53EF\u6539\u53D8\u5168\u5C40\u9ED8\u8BA4\u503C\n\n### 2. Markdown \u2192 HTML \u5143\u7D20\u6620\u5C04\uFF08CSS \u7F16\u5199\u6838\u5FC3\u4F9D\u636E\uFF09\n\u81EA\u5B9A\u4E49\u6A21\u5F0F\u4F7F\u7528\u6807\u51C6 Markdown \u6E32\u67D3\u5F15\u64CE\uFF0C\u4EE5\u4E0B\u5185\u5BB9\u4F1A\u88AB\u8F6C\u6362\u4E3A\u5BF9\u5E94\u7684 HTML \u6807\u7B7E\u3002\u4F60\u7684 CSS \u5FC5\u987B\u4E3A**\u6BCF\u4E00\u79CD**\u5143\u7D20\u63D0\u4F9B\u7CBE\u5FC3\u8BBE\u8BA1\u7684\u6837\u5F0F\uFF1A\n\n#### 2.1 \u6807\u9898\u4F53\u7CFB\uFF08\u5FC5\u987B\u5EFA\u7ACB\u6E05\u6670\u5C42\u7EA7\uFF09\n| Markdown | HTML | CSS \u8981\u6C42 |\n|----------|------|----------|\n| `# H1` | `<h1>` | \u5E7B\u706F\u7247\u4E3B\u6807\u9898\uFF0C\u5B57\u53F7\u6700\u5927\uFF08\u5EFA\u8BAE 2.5-3rem\uFF09\uFF0C\u5B57\u91CD bold\uFF0C\u4E0A\u4E0B margin \u5145\u8DB3 |\n| `## H2` | `<h2>` | \u7AE0\u8282\u6807\u9898\uFF0C\u6BD4 H1 \u5C0F 20%\uFF08\u5EFA\u8BAE 2-2.2rem\uFF09\uFF0C\u989C\u8272\u53EF\u7565\u6D45 |\n| `### H3` | `<h3>` | \u5C0F\u8282\u6807\u9898\uFF08\u5EFA\u8BAE 1.5-1.7rem\uFF09\uFF0C\u4E0E\u6B63\u6587\u6709\u660E\u786E\u533A\u5206 |\n| `#### H4` | `<h4>` | \u5B50\u6807\u9898\uFF08\u5EFA\u8BAE 1.2-1.3rem\uFF09\uFF0C**\u4E0D\u53EF\u4E0E\u6B63\u6587\u540C\u5927\u5C0F** |\n| `##### H5` | `<h5>` | \u8F85\u52A9\u6807\u9898\uFF08\u5EFA\u8BAE 1.05-1.1rem\uFF09\uFF0C\u53EF\u52A0\u989C\u8272\u533A\u5206 |\n| `###### H6` | `<h6>` | \u6700\u5C0F\u6807\u9898\uFF08\u5EFA\u8BAE 0.95-1rem\uFF09\uFF0C\u901A\u5E38\u7528\u4F5C\u6807\u7B7E\u6216\u5143\u4FE1\u606F |\n\n**\u9009\u62E9\u5668**\uFF1A`section h1` ~ `section h6`\n**\u5173\u952E**\uFF1AH1-H6 \u5FC5\u987B\u5F62\u6210\u9012\u51CF\u7684\u5B57\u53F7\u9636\u68AF\uFF0C\u4E0D\u53EF\u51FA\u73B0 H3 \u6BD4 H2 \u5927\u6216 H4 \u4E0E\u6B63\u6587\u540C\u5927\u5C0F\u7684\u60C5\u51B5\u3002\n\n#### 2.2 \u6BB5\u843D\u4E0E\u6587\u672C\u4FEE\u9970\n| Markdown | HTML | CSS \u8981\u6C42 |\n|----------|------|----------|\n| \u666E\u901A\u6BB5\u843D | `<p>` | line-height: 1.6-1.8\uFF0C\u9002\u5F53 margin-bottom\uFF080.5-0.8em\uFF09 |\n| `**\u7C97\u4F53**` | `<strong>` | font-weight: 700 \u6216 600\uFF0C\u989C\u8272\u53EF\u7565\u4EAE\u4E8E\u6B63\u6587 |\n| `*\u659C\u4F53*` | `<em>` | font-style: italic\uFF0C\u53EF\u9644\u52A0\u8F7B\u5FAE\u989C\u8272\u504F\u79FB |\n| `~~\u5220\u9664\u7EBF~~` | `<del>` | text-decoration: line-through\uFF0C\u989C\u8272\u7565\u6DE1\uFF08\u5982 opacity: 0.6\uFF09 |\n| `==\u9AD8\u4EAE==` | `<mark>` | **\u5FC5\u987B**\u8BBE\u8BA1\u9192\u76EE\u7684\u9AD8\u4EAE\u6837\u5F0F\uFF1A\u5982\u9EC4\u8272\u534A\u900F\u660E\u5E95\u8272\uFF08rgba(255,215,0,0.3)\uFF09+ \u5706\u89D2 padding\uFF082px 6px\uFF09 |\n| `<u>\u4E0B\u5212\u7EBF</u>` | `<u>` | \u4F7F\u7528\u5E26\u989C\u8272\u504F\u79FB\u7684\u4E0B\u5212\u7EBF\uFF08\u5982 border-bottom: 2px solid var(--ls-accent)\uFF09\uFF0C\u907F\u514D\u9ED8\u8BA4\u6837\u5F0F\u7684\u751F\u786C\u611F |\n| `[\u94FE\u63A5](url)` | `<a>` | color \u4F7F\u7528\u4E3B\u9898\u5F3A\u8C03\u8272\uFF0Chover \u65F6\u52A0\u4E0B\u5212\u7EBF\u6216\u989C\u8272\u53D8\u5316\uFF0Ctransition: all 0.2s |\n| `\u884C\u5185\u4EE3\u7801` | `<code>`\uFF08\u884C\u5185\uFF09 | \u7B49\u5BBD\u5B57\u4F53\u3001\u8F7B\u5FAE\u80CC\u666F\u8272\uFF08\u4E0E\u5E7B\u706F\u7247\u80CC\u666F\u5F62\u6210\u5BF9\u6BD4\uFF09\u3001\u5706\u89D2 padding\uFF082px 4px\uFF09\u3001\u5B57\u53F7\u7565\u5C0F\uFF080.9em\uFF09 |\n\n#### 2.3 \u5217\u8868\uFF08\u65E0\u5E8F/\u6709\u5E8F/\u4EFB\u52A1\uFF09\n| Markdown | HTML | CSS \u8981\u6C42 |\n|----------|------|----------|\n| `- \u9879\u76EE` | `<ul><li>` | \u5DE6\u4FA7\u7F29\u8FDB\u4E00\u81F4\uFF08padding-left: 1.5em\uFF09\uFF0Clist-style \u53EF\u4F7F\u7528\u81EA\u5B9A\u4E49\u7B26\u53F7\uFF08\u5982\u5706\u70B9\u3001\u65B9\u5757\uFF09 |\n| `1. \u9879\u76EE` | `<ol><li>` | \u6570\u5B57/\u5B57\u6BCD\u5E8F\u53F7\u6837\u5F0F\u6E05\u6670\uFF0C\u4E0E\u6B63\u6587\u5BF9\u9F50 |\n| `- [ ] \u4EFB\u52A1` | \u81EA\u5B9A\u4E49 HTML\uFF08CSS/SVG \u52FE\u9009\u6846\uFF09 | **\u4E25\u7981\u4F7F\u7528\u539F\u751F `<input type="checkbox">`**\u3002\u7528 CSS/SVG \u7ED8\u5236\uFF1A\u672A\u52FE\u9009\u65F6\u4E3A\u7A7A\u65B9\u6846\uFF0C\u52FE\u9009\u65F6\u663E\u793A \u2713 \u7B26\u53F7 + \u6DFB\u52A0\u5220\u9664\u7EBF\u6548\u679C\uFF08text-decoration: line-through\uFF09 |\n\n**\u9009\u62E9\u5668**\uFF1A`section ul`\u3001`section ol`\u3001`section li`\n**\u5173\u952E**\uFF1A\u5217\u8868\u9879\u95F4\u8DDD\u8981\u5747\u5300\uFF08margin-bottom: 0.3-0.5em\uFF09\uFF0C\u5D4C\u5957\u5217\u8868\u7F29\u8FDB\u6E05\u6670\u3002\n\n#### 2.4 \u4EE3\u7801\u5757\nMarkdown \u4EE3\u7801\u5757\u6E32\u67D3\u4E3A `<pre>` \u5305\u88F9 `<code>` \u7684\u7ED3\u6784\u3002\n- **\u5757\u7EA7\u9009\u62E9\u5668**\uFF1A`section pre`\u3001`section pre code`\n- **\u6837\u5F0F\u8981\u6C42**\uFF1A\u4E0E\u5E7B\u706F\u7247\u80CC\u666F\u5F62\u6210\u5BF9\u6BD4\u7684\u6DF1\u8272\u80CC\u666F\uFF08\u5982 #1e293b\uFF09\u3001\u7B49\u5BBD\u5B57\u4F53\uFF08font-family: \'Fira Code\', monospace\uFF09\u3001\u5706\u89D2\uFF08border-radius: 8px\uFF09\u3001\u9002\u5F53 padding\uFF0812-16px\uFF09\u3001\u63A7\u5236 max-height\uFF08\u5982 400px\uFF0C\u9632\u6B62\u6EA2\u51FA\u5E7B\u706F\u7247\uFF09\n- **\u884C\u5185\u9009\u62E9\u5668**\uFF1A`section code`\uFF08\u5DF2\u5728 2.2 \u4E2D\u8BF4\u660E\uFF09\n\n#### 2.5 \u8868\u683C\n| Markdown | HTML | CSS \u8981\u6C42 |\n|----------|------|----------|\n| `| \u8868\u5934 | \u6570\u636E |` | `<table><thead><tbody><tr><th><td>` | \u6E05\u6670\u7684\u8FB9\u6846\uFF08border-collapse\uFF09\u3001\u8868\u5934\u80CC\u666F\u8272\u7A81\u51FA\u3001\u884C\u4EA4\u66FF\u8272\uFF08striped rows\uFF09\u3001cell padding \u5145\u8DB3\uFF088-12px\uFF09 |\n\n**\u9009\u62E9\u5668**\uFF1A`section table`\u3001`section th`\u3001`section td`\n**\u9632\u622A\u65AD\u7B56\u7565**\uFF1A\u5217\u6570\u591A\u6216\u884C\u6570\u591A\u65F6\u5BB9\u6613\u6EA2\u51FA\u5E7B\u706F\u7247 \u2192 \u4F18\u5148\u7F29\u5C0F\u5B57\u4F53\uFF08\u5982 0.7rem\uFF09\u548C cell padding\uFF1B\u4ECD\u6EA2\u51FA\u65F6\u7528 `transform: scale(0.85)` \u6574\u4F53\u7F29\u653E\uFF08transform-origin: top left\uFF09\u3002\n\n#### 2.6 \u5F15\u7528\u5757\n| Markdown | HTML | CSS \u8981\u6C42 |\n|----------|------|----------|\n| `> \u5F15\u7528` | `<blockquote>` | \u5DE6\u4FA7\u5F69\u8272\u8FB9\u6846\uFF08border-left: 4px solid var(--ls-accent)\uFF09\u3001\u8F7B\u5FAE\u80CC\u666F\u8272\u3001\u5185\u90E8 padding\uFF0812-16px\uFF09\u3001\u659C\u4F53\u6216\u7565\u6DE1\u7684\u6587\u5B57\u8272 |\n\n#### 2.7 \u6C34\u5E73\u7EBF\n| Markdown | HTML | CSS \u8981\u6C42 |\n|----------|------|----------|\n| `---` | `<hr>` | \u7B80\u6D01\u4F18\u96C5\u7684\u5206\u9694\u7EBF\uFF1Aborder: none\u3001border-top: 1px solid var(--ls-border)\u3001\u9002\u5F53 margin\uFF081.5em 0\uFF09\u3001\u53EF\u4F7F\u7528\u6E10\u53D8\u6216\u865A\u7EBF\u589E\u5F3A\u89C6\u89C9\u6548\u679C |\n\n#### 2.8 Callout\uFF08\u8B66\u544A\u6846\uFF09\n\u6E32\u67D3\u4E3A `<div class="callout callout-{type}">`\uFF0C\u5185\u542B `.callout-title` \u548C `.callout-content`\u3002\n- **\u7C7B\u578B**\uFF1Anote/tip/warning/danger/question/example \u7B49\n- **\u6837\u5F0F\u8981\u6C42**\uFF1A\u5DE6\u4FA7\u5F69\u8272\u8FB9\u6846\uFF08\u7C7B\u578B\u51B3\u5B9A\u989C\u8272\uFF0C\u5982 note=blue, warning=orange, danger=red\uFF09+ \u8F7B\u5FAE\u80CC\u666F\u8272 + \u5706\u89D2\uFF0C\u4E0E\u6574\u4F53\u98CE\u683C\u534F\u8C03\n- **\u9009\u62E9\u5668**\uFF1A`section .callout`\u3001`section .callout-title`\u3001`section .callout-content`\u3001`section .callout-note` \u7B49\u7C7B\u578B\u9009\u62E9\u5668\n\n#### 2.9 \u56FE\u7247\n\u63D2\u4EF6\u5DF2\u4E3A\u56FE\u7247\u63D0\u4F9B\u57FA\u7840\u6837\u5F0F\uFF0C\u4F60\u53EA\u9700\u8986\u76D6\u89C6\u89C9\u6548\u679C\uFF1A\n- **\u5355\u56FE**\uFF1A`section img` \u2192 border-radius\u3001box-shadow\u3001border\n- **\u53CC\u56FE\u5E76\u6392**\uFF1A\u7236\u5BB9\u5668 flex + gap\uFF0C\u5B50\u5143\u7D20\u5404\u7EA6 48% \u5BBD\u5EA6\n- **\u591A\u56FE\u7F51\u683C**\uFF1Agrid \u5E03\u5C40\uFF08\u5982 3 \u5217\uFF09\uFF0C\u56FE\u7247\u56FA\u5B9A\u9AD8\u5EA6 + object-fit: cover\n- **\u7EA6\u675F**\uFF1A\u56FE\u7247\u4E0D\u8981\u8D85\u51FA\u5E7B\u706F\u7247\u8FB9\u754C\uFF0C\u5FC5\u8981\u65F6\u9650\u5236 max-height\uFF08\u5982 45%\uFF09\n\n#### 2.10 \u6570\u5B66\u516C\u5F0F\nKaTeX \u6E32\u67D3\u7684\u6570\u5B66\u516C\u5F0F\uFF0C\u5757\u7EA7\u53EF\u52A0\u80CC\u666F\u5BB9\u5668\u3002\n- **\u9009\u62E9\u5668**\uFF1A`section .katex`\u3001`section .katex-display`\n- **\u8981\u6C42**\uFF1A\u786E\u4FDD\u6DF1\u8272/\u6D45\u8272\u80CC\u666F\u90FD\u6709\u8DB3\u591F\u5BF9\u6BD4\u5EA6\uFF0C\u5757\u7EA7\u516C\u5F0F\u53EF\u52A0\u8F7B\u5FAE\u80CC\u666F\u8272\u5BB9\u5668\n\n### 3. \u5E7B\u706F\u7247\u6574\u4F53\u5E03\u5C40\u89C4\u8303\n- **\u5E7B\u706F\u7247\u672C\u4F53\u9009\u62E9\u5668**\uFF1A`section`\uFF08\u4E0D\u8981\u4F7F\u7528 `.slide`\uFF09\n- **\u53EF\u81EA\u7531\u8986\u76D6**\uFF1Abackground\u3001color\u3001font-family\u3001padding\u3001border-radius\u3001box-shadow\u3001border\n- **\u5C3A\u5BF8\u7EA6\u675F**\uFF1A\u7531 frontmatter `size` \u5B57\u6BB5\u63A7\u5236\uFF0816:9=1280x720, 4:3=1024x768, 1:1=800x800\uFF09\uFF0CCSS \u4E2D\u4E0D\u53EF\u8986\u76D6\n- **\u9875\u7801**\uFF1A`.slide-paginate` \u7684 font-size\u3001color\u3001opacity\n\n### 4. CSS \u53D8\u91CF\u4F53\u7CFB\n\u63D2\u4EF6\u5728 :root \u4E2D\u5B9A\u4E49\u4EE5\u4E0B\u53D8\u91CF\uFF0C\u63A8\u8350\u4F18\u5148\u4F7F\u7528\u5B83\u4EEC\u4EE5\u786E\u4FDD\u4E00\u81F4\u6027\uFF1A\n- `--ls-body-bg` / `--ls-body-color`\uFF1A\u9875\u9762\u80CC\u666F/\u6587\u5B57\u8272\n- `--ls-slide-bg` / `--ls-slide-radius` / `--ls-slide-padding`\uFF1A\u5E7B\u706F\u7247\u6837\u5F0F\n- `--ls-h1-size` / `--ls-h1-weight` / `--ls-h1-margin`\uFF1AH1 \u6837\u5F0F\uFF08\u540C\u7406 H2-H6\uFF09\n- `--ls-accent`\uFF1A\u4E3B\u9898\u5F3A\u8C03\u8272\uFF0C\u7528\u4E8E\u94FE\u63A5\u3001\u8FB9\u6846\u3001\u9AD8\u4EAE\u7B49\n\n### 5. \u8F93\u51FA\u8981\u6C42\n- \u8F93\u51FA**\u5B8C\u6574**\u7684 CSS \u4EE3\u7801\uFF08\u542B\u539F\u6709\u5185\u5BB9\u548C\u4F60\u7684\u4FEE\u6539\uFF09\n- \u4E0D\u8981\u6DFB\u52A0 markdown \u4EE3\u7801\u56F4\u680F\uFF08\u5982 ```css`\uFF09\n- \u4E0D\u8981\u5305\u542B\u4EFB\u4F55\u89E3\u91CA\u6027\u6587\u5B57\uFF0C\u53EA\u8F93\u51FA\u7EAF CSS\n- \u4FDD\u6301\u4EE3\u7801\u6574\u6D01\uFF0C\u9002\u5F53\u7F29\u8FDB\n- **\u8986\u76D6\u6240\u6709\u4E0A\u8FF0 Markdown \u5143\u7D20\u7684\u9009\u62E9\u5668**\uFF0C\u4E0D\u8981\u9057\u6F0F\u4EFB\u4F55\u4E00\u79CD',We={aiProvider:"local",apiBaseUrl:"https://api.moonshot.cn/v1/chat/completions",apiKey:"",model:"kimi-latest",defaultMode:"design",defaultSkill:"blog-post",localAgent:"",localAgentBinOverride:"",defaultExportFolder:"",language:"zh-cn",disableAiExtras:!0,cssSystemPrompt:ue,slideLayouts:{},customBaseFontSize:16,customTextColor:"#e2e8f0",customFontFamily:'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',htmlDefaultSaveFolder:""},Ie={"zh-cn":{settingsTitle:"LumiSlate \u8BBE\u7F6E",tabGeneral:"\u5E38\u89C4",tabAi:"AI \u8BBE\u7F6E",defaultExportFolder:"\u9ED8\u8BA4\u5BFC\u51FA\u76EE\u5F55",defaultExportFolderDesc:"\u4FDD\u5B58 HTML \u5230 Vault \u65F6\u7684\u9ED8\u8BA4\u6587\u4EF6\u5939\u8DEF\u5F84\uFF08\u76F8\u5BF9 Vault \u6839\u76EE\u5F55\uFF09\uFF0C\u7559\u7A7A\u5219\u4F7F\u7528\u5F53\u524D\u7B14\u8BB0\u6240\u5728\u76EE\u5F55",defaultExportFolderPlaceholder:"\u4F8B\u5982: exports",htmlDefaultSaveFolder:"HTML \u9ED8\u8BA4\u4FDD\u5B58\u5730\u5740",htmlDefaultSaveFolderDesc:"\u81EA\u5B9A\u4E49\u6A21\u5F0F\u4E0B\u4FDD\u5B58 HTML \u7684\u9ED8\u8BA4\u6587\u4EF6\u5939\u8DEF\u5F84\uFF08\u76F8\u5BF9 Vault \u6839\u76EE\u5F55\uFF09\uFF0C\u7559\u7A7A\u5219\u4F7F\u7528\u5F53\u524D\u7B14\u8BB0\u6240\u5728\u76EE\u5F55",htmlDefaultSaveFolderPlaceholder:"\u4F8B\u5982: lumislate-html",language:"\u754C\u9762\u8BED\u8A00",languageDesc:"\u9009\u62E9\u63D2\u4EF6\u754C\u9762\u7684\u663E\u793A\u8BED\u8A00",langZhCn:"\u7B80\u4F53\u4E2D\u6587",langEn:"English",aiProvider:"\u9996\u9009\u63A5\u5165\u65B9\u5F0F",aiProviderDesc:"\u4F18\u5148\u4F7F\u7528\u672C\u5730 CLI Agent\uFF08\u5982\u5DF2\u5B89\u88C5\uFF09\uFF0C\u6216\u56DE\u9000\u5230 HTTP API",aiProviderLocal:"\u672C\u5730 CLI Agent\uFF08\u4F18\u5148\uFF09",aiProviderHttp:"HTTP API",localAgentTitle:"\u672C\u5730 CLI Agent",httpApiTitle:"HTTP API \u914D\u7F6E",selectAgent:"\u9009\u62E9 Agent",selectAgentDesc:"\u9009\u62E9\u8981\u4F7F\u7528\u7684\u672C\u5730 CLI \u5DE5\u5177",agentNotSelected:"-- \u672A\u9009\u62E9 --",customBinPath:"\u81EA\u5B9A\u4E49\u4E8C\u8FDB\u5236\u8DEF\u5F84",customBinPathDesc:"\u5982\u679C Agent \u4E0D\u5728 PATH \u4E2D\uFF0C\u53EF\u6307\u5B9A\u7EDD\u5BF9\u8DEF\u5F84",customBinPathPlaceholder:"\u7559\u7A7A\u5219\u81EA\u52A8\u68C0\u6D4B PATH",redetect:"\u91CD\u65B0\u68C0\u6D4B",redetectDesc:"\u70B9\u51FB\u91CD\u65B0\u626B\u63CF\u672C\u5730\u5B89\u88C5\u7684 CLI \u5DE5\u5177",redetectBtn:"\u91CD\u65B0\u68C0\u6D4B",apiBaseUrl:"API Base URL",apiBaseUrlDesc:"OpenAI \u517C\u5BB9\u683C\u5F0F\u7684\u5B8C\u6574\u8BF7\u6C42\u5730\u5740",apiKey:"API Key",apiKeyDesc:"\u4F60\u7684 API \u5BC6\u94A5",model:"\u6A21\u578B",modelDesc:"\u4F7F\u7528\u7684\u6A21\u578B ID",apiRefTitle:"\u5E38\u7528 API \u914D\u7F6E\u53C2\u8003",testConnection:"\u68C0\u6D4B\u8FDE\u63A5",testConnectionDesc:"\u6D4B\u8BD5\u5F53\u524D\u914D\u7F6E\u7684 API \u6216 Agent \u662F\u5426\u53EF\u4EE5\u6B63\u5E38\u8FDE\u63A5",testConnectionBtn:"\u68C0\u6D4B\u8FDE\u63A5",connectionOk:"\u8FDE\u63A5\u6210\u529F",connectionFailed:"\u8FDE\u63A5\u5931\u8D25",disableAiExtras:"\u7981\u7528 AI \u989D\u5916\u8F93\u51FA",disableAiExtrasDesc:"\u5F00\u542F\u540E\uFF0CAI \u6E32\u67D3\u65F6\u5C06\u7981\u6B62\u8F93\u51FA insight\u3001thinking\u3001analysis \u7B49\u989D\u5916\u6807\u8BB0\uFF0C\u907F\u514D\u5E72\u6270 HTML \u6E32\u67D3",sectionAiAccess:"AI \u63A5\u5165\u914D\u7F6E",sectionSystemPrompts:"\u7CFB\u7EDF\u63D0\u793A\u8BCD\u8BBE\u7F6E",cssDesignTitle:"CSS \u8BBE\u8BA1",cssDesignDesc:"\u81EA\u5B9A\u4E49 AI \u8F85\u52A9 CSS \u7F16\u8F91\u65F6\u9075\u5FAA\u7684\u7CFB\u7EDF\u63D0\u793A\u8BCD\u3002\u4FEE\u6539\u4FDD\u5B58\u540E\uFF0C\u4E0B\u6B21\u6253\u5F00 CSS \u7F16\u8F91\u5668\u65F6\u7ACB\u5373\u751F\u6548\u3002",useSkillLabel:"\u4F7F\u7528 Skill",useSkillPlaceholder:"\u6682\u4E0D\u53EF\u7528",btnSave:"\u786E\u8BA4\u4FDD\u5B58",btnReset:"\u91CD\u7F6E\u4E3A\u9ED8\u8BA4",promptSaved:"\u7CFB\u7EDF\u63D0\u793A\u8BCD\u5DF2\u4FDD\u5B58",promptReset:"\u5DF2\u91CD\u7F6E\u4E3A\u9ED8\u8BA4",noAgentDetected:"\u672A\u68C0\u6D4B\u5230\u4EFB\u4F55\u672C\u5730 CLI Agent\u3002\u652F\u6301\u7684\u5DE5\u5177\u6709\uFF1A",agentDetected:i=>`\u68C0\u6D4B\u5230 ${i} \u4E2A\u53EF\u7528 Agent`,agentNotDetected:i=>`\u672A\u68C0\u6D4B\u5230 (${i})`,agentAvailable:"\u53EF\u7528",agentUnavailable:"\u672A\u5B89\u88C5",agentPath:"\u8DEF\u5F84",agentVendor:"\u5382\u5546",agentSelected:"\u5DF2\u9009\u4E2D",agentClickToSelect:"\u70B9\u51FB\u9009\u62E9",sectionCustomStyle:"\u81EA\u5B9A\u4E49\u6A21\u5F0F\u6837\u5F0F",customBaseFontSize:"\u57FA\u51C6\u5B57\u53F7",customBaseFontSizeDesc:"\u81EA\u5B9A\u4E49\u6A21\u5F0F\u7684\u57FA\u51C6\u5B57\u53F7\uFF08px\uFF09\u3002\u4FEE\u6539\u540E\uFF0C\u6240\u6709\u6807\u9898\u3001\u95F4\u8DDD\u7B49 rem \u5355\u4F4D\u4F1A\u6309\u6BD4\u4F8B\u7F29\u653E",customTextColor:"\u6587\u5B57\u989C\u8272",customTextColorDesc:"\u81EA\u5B9A\u4E49\u6A21\u5F0F\u7684\u9ED8\u8BA4\u6587\u5B57\u989C\u8272\uFF08HEX \u683C\u5F0F\uFF09",customFontFamily:"\u5B57\u4F53",customFontFamilyDesc:"\u81EA\u5B9A\u4E49\u6A21\u5F0F\u7684\u5B57\u4F53\u65CF\uFF08CSS font-family \u683C\u5F0F\uFF09"},en:{settingsTitle:"LumiSlate Settings",tabGeneral:"General",tabAi:"AI Settings",defaultExportFolder:"Default Export Folder",defaultExportFolderDesc:"Default folder for saving HTML to Vault (relative to Vault root). Leave empty to use current note directory.",defaultExportFolderPlaceholder:"e.g. exports",htmlDefaultSaveFolder:"HTML Default Save Folder",htmlDefaultSaveFolderDesc:"Default folder for saving HTML in custom mode (relative to Vault root). Leave empty to use current note directory.",htmlDefaultSaveFolderPlaceholder:"e.g. lumislate-html",language:"Language",languageDesc:"Select the plugin interface language",langZhCn:"\u7B80\u4F53\u4E2D\u6587",langEn:"English",aiProvider:"Preferred Provider",aiProviderDesc:"Use local CLI Agent (if installed) or fallback to HTTP API",aiProviderLocal:"Local CLI Agent (Preferred)",aiProviderHttp:"HTTP API",localAgentTitle:"Local CLI Agents",httpApiTitle:"HTTP API Configuration",selectAgent:"Select Agent",selectAgentDesc:"Choose a local CLI tool to use",agentNotSelected:"-- None --",customBinPath:"Custom Binary Path",customBinPathDesc:"Specify absolute path if Agent is not on PATH",customBinPathPlaceholder:"Leave empty for auto-detection",redetect:"Redetect",redetectDesc:"Click to rescan locally installed CLI tools",redetectBtn:"Redetect",apiBaseUrl:"API Base URL",apiBaseUrlDesc:"Full OpenAI-compatible request URL",apiKey:"API Key",apiKeyDesc:"Your API key",model:"Model",modelDesc:"Model ID to use",apiRefTitle:"Common API Configurations",testConnection:"Test Connection",testConnectionDesc:"Test whether the current API or Agent can connect successfully",testConnectionBtn:"Test",connectionOk:"Connection successful",connectionFailed:"Connection failed",disableAiExtras:"Disable AI Extra Output",disableAiExtrasDesc:"When enabled, AI rendering will suppress insight, thinking, analysis, and other extra markers to avoid interfering with HTML rendering",sectionAiAccess:"AI Access Configuration",sectionSystemPrompts:"System Prompt Settings",cssDesignTitle:"CSS Design",cssDesignDesc:"Custom system prompt for AI-assisted CSS editing. Changes take effect immediately the next time the CSS editor opens.",useSkillLabel:"Use Skill",useSkillPlaceholder:"Not available",btnSave:"Save",btnReset:"Reset to Default",promptSaved:"System prompt saved",promptReset:"Reset to default",noAgentDetected:"No local CLI Agent detected. Supported tools: ",agentDetected:i=>`${i} agent(s) available`,agentNotDetected:i=>`Not detected (${i})`,agentAvailable:"Available",agentUnavailable:"Not installed",agentPath:"Path",agentVendor:"Vendor",agentSelected:"Selected",agentClickToSelect:"Click to select",sectionCustomStyle:"Custom Mode Style",customBaseFontSize:"Base Font Size",customBaseFontSizeDesc:"Base font size for custom mode (px). All headings and spacing in rem units will scale proportionally",customTextColor:"Text Color",customTextColorDesc:"Default text color for custom mode (HEX format)",customFontFamily:"Font Family",customFontFamilyDesc:"Font family for custom mode (CSS font-family format)"}};function k(i,a){var o;let e=i.settings.language,n=((o=Ie[e])!=null?o:Ie["zh-cn"])[a];return typeof n=="function"?n(0):n!=null?n:a}function Ci(i,a,e){var s;let t=i.settings.language,o=((s=Ie[t])!=null?s:Ie["zh-cn"])[a];return o(e)}var Ei={claude:"brain-circuit",codex:"code-2",gemini:"sparkles","cursor-agent":"mouse-pointer-2",deepseek:"search",aider:"git-branch",opencode:"terminal",qwen:"bot",qoder:"cpu"},Me=class extends L.PluginSettingTab{constructor(e,t){super(e,t);this.currentTab="general";this.plugin=t}display(){qe();let{containerEl:e}=this;e.empty();let t=this.plugin;e.createEl("h2",{text:k(t,"settingsTitle")});let n=e.createEl("div",{cls:"lumislate-settings-tabs"}),o=[{id:"general",label:k(t,"tabGeneral"),icon:"settings"},{id:"ai",label:k(t,"tabAi"),icon:"bot"}];for(let r of o){let l=n.createEl("button",{cls:`lumislate-settings-tab ${r.id===this.currentTab?"active":""}`});(0,L.setIcon)(l.createSpan(),r.icon),l.appendText(" "+r.label),l.addEventListener("click",()=>{this.currentTab=r.id,this.display()})}let s=e.createEl("div",{cls:"lumislate-settings-content"});switch(this.currentTab){case"general":this.renderGeneralTab(s);break;case"ai":this.renderAiTab(s);break}}renderGeneralTab(e){let t=this.plugin;new L.Setting(e).setName(k(t,"language")).setDesc(k(t,"languageDesc")).addDropdown(n=>{n.addOption("zh-cn",k(t,"langZhCn")),n.addOption("en",k(t,"langEn")),n.setValue(t.settings.language).onChange(o=>x(this,null,function*(){t.settings.language=o,yield t.saveSettings(),this.display()}))}),new L.Setting(e).setName(k(t,"defaultExportFolder")).setDesc(k(t,"defaultExportFolderDesc")).addText(n=>n.setPlaceholder(k(t,"defaultExportFolderPlaceholder")).setValue(t.settings.defaultExportFolder).onChange(o=>x(this,null,function*(){t.settings.defaultExportFolder=o.trim(),yield t.saveSettings()}))),new L.Setting(e).setName(k(t,"htmlDefaultSaveFolder")).setDesc(k(t,"htmlDefaultSaveFolderDesc")).addText(n=>n.setPlaceholder(k(t,"htmlDefaultSaveFolderPlaceholder")).setValue(t.settings.htmlDefaultSaveFolder).onChange(o=>x(this,null,function*(){t.settings.htmlDefaultSaveFolder=o.trim(),yield t.saveSettings()}))),e.createEl("h3",{text:k(t,"sectionCustomStyle"),cls:"lumislate-settings-subsection-title"}),new L.Setting(e).setName(k(t,"customBaseFontSize")).setDesc(k(t,"customBaseFontSizeDesc")).addSlider(n=>n.setLimits(12,24,1).setValue(t.settings.customBaseFontSize).setDynamicTooltip().onChange(o=>x(this,null,function*(){t.settings.customBaseFontSize=o,yield t.saveSettings()}))),new L.Setting(e).setName(k(t,"customTextColor")).setDesc(k(t,"customTextColorDesc")).addText(n=>n.setPlaceholder("#e2e8f0").setValue(t.settings.customTextColor).onChange(o=>x(this,null,function*(){t.settings.customTextColor=o.trim()||"#e2e8f0",yield t.saveSettings()}))),new L.Setting(e).setName(k(t,"customFontFamily")).setDesc(k(t,"customFontFamilyDesc")).addText(n=>n.setPlaceholder("system-ui, -apple-system, sans-serif").setValue(t.settings.customFontFamily).onChange(o=>x(this,null,function*(){t.settings.customFontFamily=o.trim()||'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',yield t.saveSettings()})))}renderAiTab(e){let t=this.plugin;this.renderCollapsibleSection(e,k(t,"sectionAiAccess"),n=>{if(new L.Setting(n).setName(k(t,"aiProvider")).setDesc(k(t,"aiProviderDesc")).addDropdown(o=>{o.addOption("local",k(t,"aiProviderLocal")).addOption("http",k(t,"aiProviderHttp")),o.setValue(t.settings.aiProvider).onChange(s=>x(this,null,function*(){t.settings.aiProvider=s,yield t.saveSettings(),this.display()}))}),new L.Setting(n).setName(k(t,"disableAiExtras")).setDesc(k(t,"disableAiExtrasDesc")).addToggle(o=>o.setValue(t.settings.disableAiExtras).onChange(s=>x(this,null,function*(){t.settings.disableAiExtras=s,yield t.saveSettings()}))),t.settings.aiProvider==="local"&&(n.createEl("h3",{text:k(t,"localAgentTitle")}),this.renderAgentCards(n),new L.Setting(n).setName(k(t,"customBinPath")).setDesc(k(t,"customBinPathDesc")).addText(o=>o.setPlaceholder(k(t,"customBinPathPlaceholder")).setValue(t.settings.localAgentBinOverride).onChange(s=>x(this,null,function*(){t.settings.localAgentBinOverride=s.trim(),yield t.saveSettings()}))),new L.Setting(n).setName(k(t,"redetect")).setDesc(k(t,"redetectDesc")).addButton(o=>{o.setButtonText(k(t,"redetectBtn")),o.onClick(()=>{t.detectLocalAgents(),this.display()})}),new L.Setting(n).setName(k(t,"testConnection")).setDesc(k(t,"testConnectionDesc")).addButton(o=>{o.setButtonText(k(t,"testConnectionBtn")),o.onClick(()=>x(this,null,function*(){let s=me(t.settings.localAgent);s!=null&&s.available?new L.Notice(`${k(t,"connectionOk")}: ${s.label}`):new L.Notice(`${k(t,"connectionFailed")}: ${t.settings.localAgent||"\u672A\u9009\u62E9 Agent"}`)}))})),t.settings.aiProvider==="http"){n.createEl("h3",{text:k(t,"httpApiTitle")}),new L.Setting(n).setName(k(t,"apiBaseUrl")).setDesc(k(t,"apiBaseUrlDesc")).addText(s=>s.setPlaceholder("https://api.moonshot.cn/v1/chat/completions").setValue(t.settings.apiBaseUrl).onChange(r=>x(this,null,function*(){t.settings.apiBaseUrl=r.trim(),yield t.saveSettings()}))),new L.Setting(n).setName(k(t,"apiKey")).setDesc(k(t,"apiKeyDesc")).addText(s=>{s.inputEl.type="password",s.setPlaceholder("sk-...").setValue(t.settings.apiKey).onChange(r=>x(this,null,function*(){t.settings.apiKey=r.trim(),yield t.saveSettings()}))}),new L.Setting(n).setName(k(t,"model")).setDesc(k(t,"modelDesc")).addText(s=>s.setPlaceholder("kimi-latest").setValue(t.settings.model).onChange(r=>x(this,null,function*(){t.settings.model=r.trim(),yield t.saveSettings()}))),n.createEl("h4",{text:k(t,"apiRefTitle")});let o=n.createEl("ul");o.createEl("li",{text:"Kimi: https://api.moonshot.cn/v1/chat/completions"}),o.createEl("li",{text:"DeepSeek: https://api.deepseek.com/v1/chat/completions"}),o.createEl("li",{text:"OpenRouter: https://openrouter.ai/api/v1/chat/completions"}),o.createEl("li",{text:"SiliconFlow: https://api.siliconflow.cn/v1/chat/completions"}),new L.Setting(n).setName(k(t,"testConnection")).setDesc(k(t,"testConnectionDesc")).addButton(s=>{s.setButtonText(k(t,"testConnectionBtn")),s.onClick(()=>x(this,null,function*(){let r=yield ft({apiKey:t.settings.apiKey,baseURL:t.settings.apiBaseUrl,model:t.settings.model});r.success?new L.Notice(k(t,"connectionOk")):new L.Notice(`${k(t,"connectionFailed")}: ${r.message}`)}))})}},!0),this.renderCollapsibleSection(e,k(t,"sectionSystemPrompts"),n=>{n.createEl("h3",{text:k(t,"cssDesignTitle"),cls:"lumislate-settings-subsection-title"}),n.createEl("p",{text:k(t,"cssDesignDesc"),cls:"setting-item-description"}),this.renderSystemPromptBlock(n,{label:k(t,"cssDesignTitle"),getValue:()=>t.settings.cssSystemPrompt,setValue:o=>{t.settings.cssSystemPrompt=o},defaultValue:ue})},!1)}renderSystemPromptBlock(e,t){let n=this.plugin,o=e.createEl("div",{cls:"lumislate-system-prompt-block"});o.createEl("div",{text:t.label,cls:"lumislate-system-prompt-label"});let s=o.createEl("textarea",{cls:"lumislate-system-prompt-textarea"});s.value=t.getValue(),s.rows=8,s.style.width="100%",s.style.fontFamily="var(--font-monospace)";let r=o.createEl("div",{cls:"lumislate-system-prompt-skill-row"});r.createEl("span",{text:k(n,"useSkillLabel")+"\uFF1A",cls:"lumislate-system-prompt-skill-label"});let l=r.createEl("select",{cls:"lumislate-system-prompt-skill-select"});l.disabled=!0;let c=l.createEl("option");c.text=k(n,"useSkillPlaceholder"),c.value="";let d=o.createEl("div",{cls:"lumislate-system-prompt-btn-row"}),u=d.createEl("button",{text:k(n,"btnSave")});u.addClass("lumislate-btn","lumislate-btn-primary"),u.addEventListener("click",()=>x(this,null,function*(){t.setValue(s.value.trim()),yield n.saveSettings(),new L.Notice(k(n,"promptSaved"))}));let g=d.createEl("button",{text:k(n,"btnReset")});g.addClass("lumislate-btn","lumislate-btn-ghost"),g.addEventListener("click",()=>{s.value=t.defaultValue,t.setValue(t.defaultValue),n.saveSettings(),new L.Notice(k(n,"promptReset"))})}renderCollapsibleSection(e,t,n,o=!1){let s=e.createEl("div",{cls:"lumislate-collapsible-section"});o&&s.classList.add("expanded");let r=s.createEl("div",{cls:"lumislate-collapsible-header"}),l=r.createEl("span",{cls:"lumislate-collapsible-icon"});(0,L.setIcon)(l,o?"chevron-down":"chevron-right"),r.createEl("span",{cls:"lumislate-collapsible-title",text:t});let c=s.createEl("div",{cls:"lumislate-collapsible-content"});o||(c.style.display="none"),r.addEventListener("click",()=>{let d=c.style.display!=="none";c.style.display=d?"none":"block",(0,L.setIcon)(l,d?"chevron-right":"chevron-down"),s.classList.toggle("expanded",!d)}),n(c)}renderAgentCards(e){var l;let t=this.plugin,n=Te(),o=n.filter(c=>c.available),s=e.createEl("div",{cls:"lumislate-agent-summary"});o.length===0?s.createEl("p",{text:`${k(t,"noAgentDetected")}claude\u3001codex\u3001gemini\u3001cursor-agent\u3001deepseek\u3001aider\u3001opencode\u3001qwen\u3001qoder`,cls:"lumislate-status-warning"}):s.createEl("p",{text:`${Ci(t,"agentDetected",o.length)}`,cls:"lumislate-status-ok"});let r=e.createEl("div",{cls:"lumislate-agent-grid"});for(let c of n){let d=t.settings.localAgent===c.id,u=r.createEl("div",{cls:`lumislate-agent-card ${c.available?"available":"unavailable"} ${d?"selected":""}`}),g=u.createEl("div",{cls:"lumislate-agent-card-icon"}),m=(l=Ei[c.id])!=null?l:"terminal";(0,L.setIcon)(g,m);let b=u.createEl("div",{cls:"lumislate-agent-card-info"}),h=b.createEl("div",{cls:"lumislate-agent-card-header"});h.createEl("span",{cls:"lumislate-agent-card-name",text:c.label});let p=h.createEl("span",{cls:`lumislate-agent-card-badge ${c.available?"ok":"missing"}`,text:c.available?k(t,"agentAvailable"):k(t,"agentUnavailable")});if(b.createEl("div",{cls:"lumislate-agent-card-vendor",text:`${k(t,"agentVendor")}: ${c.vendor}`}),c.available&&c.path&&b.createEl("div",{cls:"lumislate-agent-card-path",text:`${k(t,"agentPath")}: ${c.path}`}),d){let f=u.createEl("div",{cls:"lumislate-agent-card-selected"});(0,L.setIcon)(f,"check-circle-2")}c.available?(u.style.cursor="pointer",u.title=k(t,"agentClickToSelect"),u.addEventListener("click",()=>x(this,null,function*(){t.settings.localAgent=c.id,yield t.saveSettings(),this.display()}))):(u.style.cursor="not-allowed",u.style.opacity="0.55")}}};var Ke=require("obsidian");function kt(i){let a={hasMermaid:!1,hasLatex:!1,mermaidBlocks:[],latexBlocks:[]},e=/```mermaid\s*\n([\s\S]*?)```/g,t;for(;(t=e.exec(i))!==null;)a.hasMermaid=!0,a.mermaidBlocks.push(t[1].trim());let n=/\$\$([\s\S]*?)\$\$/g;for(;(t=n.exec(i))!==null;)a.hasLatex=!0,a.latexBlocks.push(t[1].trim());let o=i.replace(/\$\$[\s\S]*?\$\$/g,""),s=/\$([^\$\n]+?)\$/g;for(;(t=s.exec(o))!==null;){a.hasLatex=!0;break}return a}function Ti(i){return i.replace(/\.md$/i,"_preprocessed.md")}function Ai(i,a){return x(this,null,function*(){let e=Ti(a.path),t=i.getAbstractFileByPath(e);return t instanceof Ke.TFile?t:null})}function St(i,a){return i===a||a==="custom"&&i==="marp"}function Ct(i,a,e){return x(this,null,function*(){let t=yield i.read(a),{frontmatter:n}=F(t);if(n){let s=D(n,"lumislate_preprocessed")==="true",r=D(n,"lumislate_preprocessed_for");if(s&&St(r,e))return{preprocessed:!0,file:a,skillId:e}}let o=yield Ai(i,a);if(o){let s=yield i.read(o),{frontmatter:r}=F(s);if(r){let l=D(r,"lumislate_preprocessed")==="true",c=D(r,"lumislate_preprocessed_for");if(l&&St(c,e))return{preprocessed:!0,file:o,skillId:e}}}return{preprocessed:!1,file:null,skillId:null}})}function Li(i,a){return i[13]=1,i[14]=a>>8,i[15]=a&255,i[16]=a>>8,i[17]=a&255,i}var Dt=112,Ht=72,Bt=89,Nt=115,Xe;function Pi(){let i=new Int32Array(256);for(let a=0;a<256;a++){let e=a;for(let t=0;t<8;t++)e=e&1?3988292384^e>>>1:e>>>1;i[a]=e}return i}function Ii(i){let a=-1;Xe||(Xe=Pi());for(let e=0;e<i.length;e++)a=Xe[(a^i[e])&255]^a>>>8;return a^-1}function Mi(i){let a=i.length-1;for(let e=a;e>=4;e--)if(i[e-4]===9&&i[e-3]===Dt&&i[e-2]===Ht&&i[e-1]===Bt&&i[e]===Nt)return e-3;return 0}function Di(i,a,e=!1){let t=new Uint8Array(13);a*=39.3701,t[0]=Dt,t[1]=Ht,t[2]=Bt,t[3]=Nt,t[4]=a>>>24,t[5]=a>>>16,t[6]=a>>>8,t[7]=a&255,t[8]=t[4],t[9]=t[5],t[10]=t[6],t[11]=t[7],t[12]=1;let n=Ii(t),o=new Uint8Array(4);if(o[0]=n>>>24,o[1]=n>>>16,o[2]=n>>>8,o[3]=n&255,e){let s=Mi(i);return i.set(t,s),i.set(o,s+13),i}else{let s=new Uint8Array(4);s[0]=0,s[1]=0,s[2]=0,s[3]=9;let r=new Uint8Array(54);return r.set(i,0),r.set(s,33),r.set(t,37),r.set(o,50),r}}var $t="[modern-screenshot]",ee=typeof window!="undefined",Hi=ee&&"Worker"in window,Bi=ee&&"atob"in window,Aa=ee&&"btoa"in window,Mt,Qe=ee?(Mt=window.navigator)==null?void 0:Mt.userAgent:"",Ft=Qe.includes("Chrome"),De=Qe.includes("AppleWebKit")&&!Ft,Ze=Qe.includes("Firefox"),Ni=i=>i&&"__CONTEXT__"in i,$i=i=>i.constructor.name==="CSSFontFaceRule",Fi=i=>i.constructor.name==="CSSImportRule",Ri=i=>i.constructor.name==="CSSLayerBlockRule",K=i=>i.nodeType===1,fe=i=>typeof i.className=="object",Rt=i=>i.tagName==="image",zi=i=>i.tagName==="use",pe=i=>K(i)&&typeof i.style!="undefined"&&!fe(i),Oi=i=>i.nodeType===8,_i=i=>i.nodeType===3,se=i=>i.tagName==="IMG",He=i=>i.tagName==="VIDEO",Vi=i=>i.tagName==="CANVAS",Ui=i=>i.tagName==="TEXTAREA",qi=i=>i.tagName==="INPUT",ji=i=>i.tagName==="STYLE",Gi=i=>i.tagName==="SCRIPT",Wi=i=>i.tagName==="SELECT",Ki=i=>i.tagName==="SLOT",Xi=i=>i.tagName==="IFRAME",Yi=(...i)=>console.warn($t,...i);function Ji(i){var e;let a=(e=i==null?void 0:i.createElement)==null?void 0:e.call(i,"canvas");return a&&(a.height=a.width=1),!!a&&"toDataURL"in a&&!!a.toDataURL("image/webp").includes("image/webp")}var Ye=i=>i.startsWith("data:");function zt(i,a){if(i.match(/^[a-z]+:\/\//i))return i;if(ee&&i.match(/^\/\//))return window.location.protocol+i;if(i.match(/^[a-z]+:/i)||!ee)return i;let e=Be().implementation.createHTMLDocument(),t=e.createElement("base"),n=e.createElement("a");return e.head.appendChild(t),e.body.appendChild(n),a&&(t.href=a),n.href=i,n.href}function Be(i){var a;return(a=i&&K(i)?i==null?void 0:i.ownerDocument:i)!=null?a:window.document}var Ne="http://www.w3.org/2000/svg";function Qi(i,a,e){let t=Be(e).createElementNS(Ne,"svg");return t.setAttributeNS(null,"width",i.toString()),t.setAttributeNS(null,"height",a.toString()),t.setAttributeNS(null,"viewBox",`0 0 ${i} ${a}`),t}function Zi(i,a){let e=new XMLSerializer().serializeToString(i);return a&&(e=e.replace(/[\u0000-\u0008\v\f\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/gu,"")),`data:image/svg+xml;charset=utf-8,${encodeURIComponent(e)}`}function en(i,a="image/png",e=1){return x(this,null,function*(){try{return yield new Promise((t,n)=>{i.toBlob(o=>{o?t(o):n(new Error("Blob is null"))},a,e)})}catch(t){if(Bi)return tn(i.toDataURL(a,e));throw t}})}function tn(i){var r,l;let[a,e]=i.split(","),t=(l=(r=a.match(/data:(.+);/))==null?void 0:r[1])!=null?l:void 0,n=window.atob(e),o=n.length,s=new Uint8Array(o);for(let c=0;c<o;c+=1)s[c]=n.charCodeAt(c);return new Blob([s],{type:t})}function Ot(i,a){return new Promise((e,t)=>{let n=new FileReader;n.onload=()=>e(n.result),n.onerror=()=>t(n.error),n.onabort=()=>t(new Error(`Failed read blob to ${a}`)),a==="dataUrl"?n.readAsDataURL(i):a==="arrayBuffer"&&n.readAsArrayBuffer(i)})}var nn=i=>Ot(i,"dataUrl"),an=i=>Ot(i,"arrayBuffer");function oe(i,a){let e=Be(a).createElement("img");return e.decoding="sync",e.loading="eager",e.src=i,e}function ge(i,a){return new Promise(e=>{let{timeout:t,ownerDocument:n,onError:o,onWarn:s}=a!=null?a:{},r=typeof i=="string"?oe(i,Be(n)):i,l=null,c=null;function d(){e(r),l&&clearTimeout(l),c==null||c()}if(t&&(l=setTimeout(d,t)),He(r)){let u=r.currentSrc||r.src;if(!u)return r.poster?ge(r.poster,a).then(e):d();if(r.readyState>=2)return d();let g=d,m=b=>{s==null||s("Failed video load",u,b),o==null||o(b),d()};c=()=>{r.removeEventListener("loadeddata",g),r.removeEventListener("error",m)},r.addEventListener("loadeddata",g,{once:!0}),r.addEventListener("error",m,{once:!0})}else{let u=Rt(r)?r.href.baseVal:r.currentSrc||r.src;if(!u)return d();let g=()=>x(null,null,function*(){if(se(r)&&"decode"in r)try{yield r.decode()}catch(b){s==null||s("Failed to decode image, trying to render anyway",r.dataset.originalSrc||u,b)}d()}),m=b=>{s==null||s("Failed image load",r.dataset.originalSrc||u,b),d()};if(se(r)&&r.complete)return g();c=()=>{r.removeEventListener("load",g),r.removeEventListener("error",m)},r.addEventListener("load",g,{once:!0}),r.addEventListener("error",m,{once:!0})}})}function on(i,a){return x(this,null,function*(){pe(i)&&(se(i)||He(i)?yield ge(i,a):yield Promise.all(["img","video"].flatMap(e=>Array.from(i.querySelectorAll(e)).map(t=>ge(t,a)))))})}var _t=(function(){let a=0,e=()=>`0000${(Math.random()*lt(36,4)<<0).toString(36)}`.slice(-4);return()=>(a+=1,`u${e()}${a}`)})();function Vt(i){return i==null?void 0:i.split(",").map(a=>a.trim().replace(/"|'/g,"").toLowerCase()).filter(Boolean)}var Et=0;function sn(i){let a=`${$t}[#${Et}]`;return Et++,{time:e=>i&&console.time(`${a} ${e}`),timeEnd:e=>i&&console.timeEnd(`${a} ${e}`),warn:(...e)=>i&&Yi(...e)}}function rn(i){return{cache:i?"no-cache":"force-cache"}}function et(i,a){return x(this,null,function*(){return Ni(i)?i:ln(i,Q(U({},a),{autoDestruct:!0}))})}function ln(i,a){return x(this,null,function*(){var m,b,h,p,f;let{scale:e=1,workerUrl:t,workerNumber:n=1}=a||{},o=!!(a!=null&&a.debug),s=(m=a==null?void 0:a.features)!=null?m:!0,r=(b=i.ownerDocument)!=null?b:ee?window.document:void 0,l=(p=(h=i.ownerDocument)==null?void 0:h.defaultView)!=null?p:ee?window:void 0,c=new Map,d=Q(U({width:0,height:0,quality:1,type:"image/png",scale:e,backgroundColor:null,style:null,filter:null,maximumCanvasSize:0,timeout:3e4,progress:null,debug:o,fetch:U({requestInit:rn((f=a==null?void 0:a.fetch)==null?void 0:f.bypassingCache),placeholderImage:"data:image/png;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",bypassingCache:!1},a==null?void 0:a.fetch),fetchFn:null,font:{},drawImageInterval:100,workerUrl:null,workerNumber:n,onCloneEachNode:null,onCloneNode:null,onEmbedNode:null,onCreateForeignObjectSvg:null,includeStyleProperties:null,autoDestruct:!1},a),{__CONTEXT__:!0,log:sn(o),node:i,ownerDocument:r,ownerWindow:l,dpi:e===1?null:96*e,svgStyleElement:Ut(r),svgDefsElement:r==null?void 0:r.createElementNS(Ne,"defs"),svgStyles:new Map,defaultComputedStyles:new Map,workers:[...Array.from({length:Hi&&t&&n?n:0})].map(()=>{try{let w=new Worker(t);return w.onmessage=v=>x(null,null,function*(){var E,N,H,q;let{url:S,result:C}=v.data;C?(N=(E=c.get(S))==null?void 0:E.resolve)==null||N.call(E,C):(q=(H=c.get(S))==null?void 0:H.reject)==null||q.call(H,new Error(`Error receiving message from worker: ${S}`))}),w.onmessageerror=v=>{var C,E;let{url:S}=v.data;(E=(C=c.get(S))==null?void 0:C.reject)==null||E.call(C,new Error(`Error receiving message from worker: ${S}`))},w}catch(w){return d.log.warn("Failed to new Worker",w),null}}).filter(Boolean),fontFamilies:new Map,fontCssTexts:new Map,acceptOfImage:`${[Ji(r)&&"image/webp","image/svg+xml","image/*","*/*"].filter(Boolean).join(",")};q=0.8`,requests:c,drawImageCount:0,tasks:[],features:s,isEnable:w=>{var v,S;return w==="restoreScrollPosition"?typeof s=="boolean"?!1:(v=s[w])!=null?v:!1:typeof s=="boolean"?s:(S=s[w])!=null?S:!0},shadowRoots:[]});d.log.time("wait until load"),yield on(i,{timeout:d.timeout,onWarn:d.log.warn}),d.log.timeEnd("wait until load");let{width:u,height:g}=cn(i,d);return d.width=u,d.height=g,d})}function Ut(i){if(!i)return;let a=i.createElement("style"),e=a.ownerDocument.createTextNode(`
.______background-clip--text {
  background-clip: text;
  -webkit-background-clip: text;
}
`);return a.appendChild(e),a}function cn(i,a){let{width:e,height:t}=a;if(K(i)&&(!e||!t)){let n=i.getBoundingClientRect();e=e||n.width||Number(i.getAttribute("width"))||0,t=t||n.height||Number(i.getAttribute("height"))||0}return{width:e,height:t}}function dn(i,a){return x(this,null,function*(){let{log:e,timeout:t,drawImageCount:n,drawImageInterval:o}=a;e.time("image to canvas");let s=yield ge(i,{timeout:t,onWarn:a.log.warn}),{canvas:r,context2d:l}=mn(i.ownerDocument,a),c=()=>{try{l==null||l.drawImage(s,0,0,r.width,r.height)}catch(d){a.log.warn("Failed to drawImage",d)}};if(c(),a.isEnable("fixSvgXmlDecode"))for(let d=0;d<n;d++)yield new Promise(u=>{setTimeout(()=>{l==null||l.clearRect(0,0,r.width,r.height),c(),u()},d+o)});return a.drawImageCount=0,e.timeEnd("image to canvas"),r})}function mn(i,a){let{width:e,height:t,scale:n,backgroundColor:o,maximumCanvasSize:s}=a,r=i.createElement("canvas");r.width=Math.floor(e*n),r.height=Math.floor(t*n),r.style.width=`${e}px`,r.style.height=`${t}px`,s&&(r.width>s||r.height>s)&&(r.width>s&&r.height>s?r.width>r.height?(r.height*=s/r.width,r.width=s):(r.width*=s/r.height,r.height=s):r.width>s?(r.height*=s/r.width,r.width=s):(r.width*=s/r.height,r.height=s));let l=r.getContext("2d");return l&&o&&(l.fillStyle=o,l.fillRect(0,0,r.width,r.height)),{canvas:r,context2d:l}}function qt(i,a){if(i.ownerDocument)try{let o=i.toDataURL();if(o!=="data:,")return oe(o,i.ownerDocument)}catch(o){a.log.warn("Failed to clone canvas",o)}let e=i.cloneNode(!1),t=i.getContext("2d"),n=e.getContext("2d");try{return t&&n&&n.putImageData(t.getImageData(0,0,i.width,i.height),0,0),e}catch(o){a.log.warn("Failed to clone canvas",o)}return e}function un(i,a){var e;try{if((e=i==null?void 0:i.contentDocument)!=null&&e.documentElement)return tt(i.contentDocument.documentElement,a)}catch(t){a.log.warn("Failed to clone iframe",t)}return i.cloneNode(!1)}function pn(i){let a=i.cloneNode(!1);return i.currentSrc&&i.currentSrc!==i.src&&(a.src=i.currentSrc,a.srcset=""),a.loading==="lazy"&&(a.loading="eager"),a}function gn(i,a){return x(this,null,function*(){if(i.ownerDocument&&!i.currentSrc&&i.poster)return oe(i.poster,i.ownerDocument);let e=i.cloneNode(!1);e.crossOrigin="anonymous",i.currentSrc&&i.currentSrc!==i.src&&(e.src=i.currentSrc);let t=e.ownerDocument;if(t){let n=!0;if(yield ge(e,{onError:()=>n=!1,onWarn:a.log.warn}),!n)return i.poster?oe(i.poster,i.ownerDocument):e;e.currentTime=i.currentTime,yield new Promise(s=>{e.addEventListener("seeked",s,{once:!0})});let o=t.createElement("canvas");o.width=i.offsetWidth,o.height=i.offsetHeight;try{let s=o.getContext("2d");s&&s.drawImage(e,0,0,o.width,o.height)}catch(s){return a.log.warn("Failed to clone video",s),i.poster?oe(i.poster,i.ownerDocument):e}return qt(o,a)}return e})}function hn(i,a){return Vi(i)?qt(i,a):Xi(i)?un(i,a):se(i)?pn(i):He(i)?gn(i,a):i.cloneNode(!1)}function fn(i){let a=i.sandbox;if(!a){let{ownerDocument:e}=i;try{e&&(a=e.createElement("iframe"),a.id=`__SANDBOX__${_t()}`,a.width="0",a.height="0",a.style.visibility="hidden",a.style.position="fixed",e.body.appendChild(a),a.srcdoc='<!DOCTYPE html><meta charset="UTF-8"><title></title><body>',i.sandbox=a)}catch(t){i.log.warn("Failed to getSandBox",t)}}return a}var bn=["width","height","-webkit-text-fill-color"],yn=["stroke","fill"];function jt(i,a,e){let{defaultComputedStyles:t}=e,n=i.nodeName.toLowerCase(),o=fe(i)&&n!=="svg",s=o?yn.map(h=>[h,i.getAttribute(h)]).filter(([,h])=>h!==null):[],r=[o&&"svg",n,s.map((h,p)=>`${h}=${p}`).join(","),a].filter(Boolean).join(":");if(t.has(r))return t.get(r);let l=fn(e),c=l==null?void 0:l.contentWindow;if(!c)return new Map;let d=c==null?void 0:c.document,u,g;o?(u=d.createElementNS(Ne,"svg"),g=u.ownerDocument.createElementNS(u.namespaceURI,n),s.forEach(([h,p])=>{g.setAttributeNS(null,h,p)}),u.appendChild(g)):u=g=d.createElement(n),g.textContent=" ",d.body.appendChild(u);let m=c.getComputedStyle(g,a),b=new Map;for(let h=m.length,p=0;p<h;p++){let f=m.item(p);bn.includes(f)||b.set(f,m.getPropertyValue(f))}return d.body.removeChild(u),t.set(r,b),b}function Gt(i,a,e){var r;let t=new Map,n=[],o=new Map;if(e)for(let l of e)s(l);else for(let l=i.length,c=0;c<l;c++){let d=i.item(c);s(d)}for(let l=n.length,c=0;c<l;c++)(r=o.get(n[c]))==null||r.forEach((d,u)=>t.set(u,d));function s(l){let c=i.getPropertyValue(l),d=i.getPropertyPriority(l),u=l.lastIndexOf("-"),g=u>-1?l.substring(0,u):void 0;if(g){let m=o.get(g);m||(m=new Map,o.set(g,m)),m.set(l,[c,d])}a.get(l)===c&&!d||(g?n.push(g):t.set(l,[c,d]))}return t}function vn(i,a,e,t){var u,g,m,b;let{ownerWindow:n,includeStyleProperties:o,currentParentNodeStyle:s}=t,r=a.style,l=n.getComputedStyle(i),c=jt(i,null,t);s==null||s.forEach((h,p)=>{c.delete(p)});let d=Gt(l,c,o);d.delete("transition-property"),d.delete("all"),d.delete("d"),d.delete("content"),e&&(d.delete("position"),d.delete("margin-top"),d.delete("margin-right"),d.delete("margin-bottom"),d.delete("margin-left"),d.delete("margin-block-start"),d.delete("margin-block-end"),d.delete("margin-inline-start"),d.delete("margin-inline-end"),d.set("box-sizing",["border-box",""])),((u=d.get("background-clip"))==null?void 0:u[0])==="text"&&a.classList.add("______background-clip--text"),Ft&&(d.has("font-kerning")||d.set("font-kerning",["normal",""]),(((g=d.get("overflow-x"))==null?void 0:g[0])==="hidden"||((m=d.get("overflow-y"))==null?void 0:m[0])==="hidden")&&((b=d.get("text-overflow"))==null?void 0:b[0])==="ellipsis"&&i.scrollWidth===i.clientWidth&&d.set("text-overflow",["clip",""]));for(let h=r.length,p=0;p<h;p++)r.removeProperty(r.item(p));return d.forEach(([h,p],f)=>{r.setProperty(f,h,p)}),d}function xn(i,a){(Ui(i)||qi(i)||Wi(i))&&a.setAttribute("value",i.value)}var wn=["::before","::after"],Sn=["::-webkit-scrollbar","::-webkit-scrollbar-button","::-webkit-scrollbar-thumb","::-webkit-scrollbar-track","::-webkit-scrollbar-track-piece","::-webkit-scrollbar-corner","::-webkit-resizer"];function kn(i,a,e,t,n){let{ownerWindow:o,svgStyleElement:s,svgStyles:r,currentNodeStyle:l}=t;if(!s||!o)return;function c(d){var v;let u=o.getComputedStyle(i,d),g=u.getPropertyValue("content");if(!g||g==="none")return;n==null||n(g),g=g.replace(/(')|(")|(counter\(.+\))/g,"");let m=[_t()],b=jt(i,d,t);l==null||l.forEach((S,C)=>{b.delete(C)});let h=Gt(u,b,t.includeStyleProperties);h.delete("content"),h.delete("-webkit-locale"),((v=h.get("background-clip"))==null?void 0:v[0])==="text"&&a.classList.add("______background-clip--text");let p=[`content: '${g}';`];if(h.forEach(([S,C],E)=>{p.push(`${E}: ${S}${C?" !important":""};`)}),p.length===1)return;try{a.className=[a.className,...m].join(" ")}catch(S){t.log.warn("Failed to copyPseudoClass",S);return}let f=p.join(`
  `),w=r.get(f);w||(w=[],r.set(f,w)),w.push(`.${m[0]}${d}`)}wn.forEach(c),e&&Sn.forEach(c)}var Tt=new Set(["symbol"]);function At(i,a,e,t,n){return x(this,null,function*(){if(K(e)&&(ji(e)||Gi(e))||t.filter&&!t.filter(e))return;Tt.has(a.nodeName)||Tt.has(e.nodeName)?t.currentParentNodeStyle=void 0:t.currentParentNodeStyle=t.currentNodeStyle;let o=yield tt(e,t,!1,n);t.isEnable("restoreScrollPosition")&&Cn(i,o),a.appendChild(o)})}function Lt(i,a,e,t){return x(this,null,function*(){var o;let n=i.firstChild;K(i)&&i.shadowRoot&&(n=(o=i.shadowRoot)==null?void 0:o.firstChild,e.shadowRoots.push(i.shadowRoot));for(let s=n;s;s=s.nextSibling)if(!Oi(s))if(K(s)&&Ki(s)&&typeof s.assignedNodes=="function"){let r=s.assignedNodes();for(let l=0;l<r.length;l++)yield At(i,a,r[l],e,t)}else yield At(i,a,s,e,t)})}function Cn(i,a){if(!pe(i)||!pe(a))return;let{scrollTop:e,scrollLeft:t}=i;if(!e&&!t)return;let{transform:n}=a.style,o=new DOMMatrix(n),{a:s,b:r,c:l,d:c}=o;o.a=1,o.b=0,o.c=0,o.d=1,o.translateSelf(-t,-e),o.a=s,o.b=r,o.c=l,o.d=c,a.style.transform=o.toString()}function En(i,a){let{backgroundColor:e,width:t,height:n,style:o}=a,s=i.style;if(e&&s.setProperty("background-color",e,"important"),t&&s.setProperty("width",`${t}px`,"important"),n&&s.setProperty("height",`${n}px`,"important"),o)for(let r in o)s[r]=o[r]}var Tn=/^[\w-:]+$/;function tt(i,a,e=!1,t){return x(this,null,function*(){var c,d,u,g;let{ownerDocument:n,ownerWindow:o,fontFamilies:s,onCloneEachNode:r}=a;if(n&&_i(i))return t&&/\S/.test(i.data)&&t(i.data),n.createTextNode(i.data);if(n&&o&&K(i)&&(pe(i)||fe(i))){let m=yield hn(i,a);if(a.isEnable("removeAbnormalAttributes")){let v=m.getAttributeNames();for(let S=v.length,C=0;C<S;C++){let E=v[C];Tn.test(E)||m.removeAttribute(E)}}let b=a.currentNodeStyle=vn(i,m,e,a);e&&En(m,a);let h=!1;if(a.isEnable("copyScrollbar")){let v=[(c=b.get("overflow-x"))==null?void 0:c[0],(d=b.get("overflow-y"))==null?void 0:d[0]];h=v.includes("scroll")||(v.includes("auto")||v.includes("overlay"))&&(i.scrollHeight>i.clientHeight||i.scrollWidth>i.clientWidth)}let p=(u=b.get("text-transform"))==null?void 0:u[0],f=Vt((g=b.get("font-family"))==null?void 0:g[0]),w=f?v=>{p==="uppercase"?v=v.toUpperCase():p==="lowercase"?v=v.toLowerCase():p==="capitalize"&&(v=v[0].toUpperCase()+v.substring(1)),f.forEach(S=>{let C=s.get(S);C||s.set(S,C=new Set),v.split("").forEach(E=>C.add(E))})}:void 0;return kn(i,m,h,a,w),xn(i,m),He(i)||(yield Lt(i,m,a,w)),yield r==null?void 0:r(m),m}let l=i.cloneNode(!1);return yield Lt(i,l,a),yield r==null?void 0:r(l),l})}function An(i){if(i.ownerDocument=void 0,i.ownerWindow=void 0,i.svgStyleElement=void 0,i.svgDefsElement=void 0,i.svgStyles.clear(),i.defaultComputedStyles.clear(),i.sandbox){try{i.sandbox.remove()}catch(a){i.log.warn("Failed to destroyContext",a)}i.sandbox=void 0}i.workers=[],i.fontFamilies.clear(),i.fontCssTexts.clear(),i.requests.clear(),i.tasks=[],i.shadowRoots=[]}function Ln(i){let r=i,{url:a,timeout:e,responseType:t}=r,n=ct(r,["url","timeout","responseType"]),o=new AbortController,s=e?setTimeout(()=>o.abort(),e):void 0;return fetch(a,U({signal:o.signal},n)).then(l=>{if(!l.ok)throw new Error("Failed fetch, not 2xx response",{cause:l});switch(t){case"arrayBuffer":return l.arrayBuffer();case"dataUrl":return l.blob().then(nn);default:return l.text()}}).finally(()=>clearTimeout(s))}function he(i,a){let{url:e,requestType:t="text",responseType:n="text",imageDom:o}=a,s=e,{timeout:r,acceptOfImage:l,requests:c,fetchFn:d,fetch:{requestInit:u,bypassingCache:g,placeholderImage:m},font:b,workers:h,fontFamilies:p}=i;t==="image"&&(De||Ze)&&i.drawImageCount++;let f=c.get(e);if(!f){g&&g instanceof RegExp&&g.test(s)&&(s+=(/\?/.test(s)?"&":"?")+new Date().getTime());let w=t.startsWith("font")&&b&&b.minify,v=new Set;w&&t.split(";")[1].split(",").forEach(N=>{p.has(N)&&p.get(N).forEach(H=>v.add(H))});let S=w&&v.size,C=U({url:s,timeout:r,responseType:S?"arrayBuffer":n,headers:t==="image"?{accept:l}:void 0},u);f={type:t,resolve:void 0,reject:void 0,response:null},f.response=x(null,null,function*(){if(d&&t==="image"){let E=yield d(e);if(E)return E}return!De&&e.startsWith("http")&&h.length?new Promise((E,N)=>{h[c.size&h.length-1].postMessage(U({rawUrl:e},C)),f.resolve=E,f.reject=N}):Ln(C)}).catch(E=>{if(c.delete(e),t==="image"&&m)return i.log.warn("Failed to fetch image base64, trying to use placeholder image",s),typeof m=="string"?m:m(o);throw E}),c.set(e,f)}return f.response}function Wt(i,a,e,t){return x(this,null,function*(){if(!Kt(i))return i;for(let[n,o]of Pn(i,a))try{let s=yield he(e,{url:o,requestType:t?"image":"text",responseType:"dataUrl"});i=i.replace(In(n),`$1${s}$3`)}catch(s){e.log.warn("Failed to fetch css data url",n,s)}return i})}function Kt(i){return/url\((['"]?)([^'"]+?)\1\)/.test(i)}var Xt=/url\((['"]?)([^'"]+?)\1\)/g;function Pn(i,a){let e=[];return i.replace(Xt,(t,n,o)=>(e.push([o,zt(o,a)]),t)),e.filter(([t])=>!Ye(t))}function In(i){let a=i.replace(/([.*+?^${}()|\[\]\/\\])/g,"\\$1");return new RegExp(`(url\\(['"]?)(${a})(['"]?\\))`,"g")}var Mn=["background-image","border-image-source","-webkit-border-image","-webkit-mask-image","list-style-image"];function Dn(i,a){return Mn.map(e=>{let t=i.getPropertyValue(e);return!t||t==="none"?null:((De||Ze)&&a.drawImageCount++,Wt(t,null,a,!0).then(n=>{!n||t===n||i.setProperty(e,n,i.getPropertyPriority(e))}))}).filter(Boolean)}function Hn(i,a){if(se(i)){let e=i.currentSrc||i.src;if(!Ye(e))return[he(a,{url:e,imageDom:i,requestType:"image",responseType:"dataUrl"}).then(t=>{t&&(i.srcset="",i.dataset.originalSrc=e,i.src=t||"")})];(De||Ze)&&a.drawImageCount++}else if(fe(i)&&!Ye(i.href.baseVal)){let e=i.href.baseVal;return[he(a,{url:e,imageDom:i,requestType:"image",responseType:"dataUrl"}).then(t=>{t&&(i.dataset.originalSrc=e,i.href.baseVal=t||"")})]}return[]}function Bn(i,a){var r;let{ownerDocument:e,svgDefsElement:t}=a,n=(r=i.getAttribute("href"))!=null?r:i.getAttribute("xlink:href");if(!n)return[];let[o,s]=n.split("#");if(s){let l=`#${s}`,c=a.shadowRoots.reduce((d,u)=>d!=null?d:u.querySelector(`svg ${l}`),e==null?void 0:e.querySelector(`svg ${l}`));if(o&&i.setAttribute("href",l),t!=null&&t.querySelector(l))return[];if(c)return t==null||t.appendChild(c.cloneNode(!0)),[];if(o)return[he(a,{url:o,responseType:"text"}).then(d=>{t==null||t.insertAdjacentHTML("beforeend",d)})]}return[]}function Yt(i,a){let{tasks:e}=a;K(i)&&((se(i)||Rt(i))&&e.push(...Hn(i,a)),zi(i)&&e.push(...Bn(i,a))),pe(i)&&e.push(...Dn(i.style,a)),i.childNodes.forEach(t=>{Yt(t,a)})}function Nn(i,a){return x(this,null,function*(){let{ownerDocument:e,svgStyleElement:t,fontFamilies:n,fontCssTexts:o,tasks:s,font:r}=a;if(!(!e||!t||!n.size))if(r&&r.cssText){let l=It(r.cssText,a);t.appendChild(e.createTextNode(`${l}
`))}else{let l=Array.from(e.styleSheets).filter(m=>{try{return"cssRules"in m&&!!m.cssRules.length}catch(b){return a.log.warn(`Error while reading CSS rules from ${m.href}`,b),!1}}),c=e.implementation.createHTMLDocument(""),d=c.createElement("style");c.head.appendChild(d);let u=d.sheet;yield Promise.all(l.flatMap(m=>Array.from(m.cssRules).map(b=>x(null,null,function*(){if(Fi(b)){let h=b.href,p="";try{p=yield he(a,{url:h,requestType:"text",responseType:"text"})}catch(w){a.log.warn(`Error fetch remote css import from ${h}`,w)}let f=p.replace(Xt,(w,v,S)=>w.replace(S,zt(S,h)));for(let w of Fn(f))try{u.insertRule(w,u.cssRules.length)}catch(v){a.log.warn("Error inserting rule from remote css import",{rule:w,error:v})}}})))),u.cssRules.length&&l.push(u);let g=[];l.forEach(m=>{Je(m.cssRules,g)}),g.filter(m=>{var b;return $i(m)&&Kt(m.style.getPropertyValue("src"))&&((b=Vt(m.style.getPropertyValue("font-family")))==null?void 0:b.some(h=>n.has(h)))}).forEach(m=>{let b=m,h=o.get(b.cssText);h?t.appendChild(e.createTextNode(`${h}
`)):s.push(Wt(b.cssText,b.parentStyleSheet?b.parentStyleSheet.href:null,a).then(p=>{p=It(p,a),o.set(b.cssText,p),t.appendChild(e.createTextNode(`${p}
`))}))})}})}var $n=/(\/\*[\s\S]*?\*\/)/g,Pt=/((@.*?keyframes [\s\S]*?){([\s\S]*?}\s*?)})/gi;function Fn(i){if(i==null)return[];let a=[],e=i.replace($n,"");for(;;){let o=Pt.exec(e);if(!o)break;a.push(o[0])}e=e.replace(Pt,"");let t=/@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi,n=new RegExp("((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})","gi");for(;;){let o=t.exec(e);if(o)n.lastIndex=t.lastIndex;else if(o=n.exec(e),o)t.lastIndex=n.lastIndex;else break;a.push(o[0])}return a}var Rn=/url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g,zn=/src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;function It(i,a){let{font:e}=a,t=e?e==null?void 0:e.preferredFormat:void 0;return t?i.replace(zn,n=>{for(;;){let[o,,s]=Rn.exec(n)||[];if(!s)return"";if(s===t)return`src: ${o};`}}):i}function Je(i,a=[]){for(let e of Array.from(i))Ri(e)?a.push(...Je(e.cssRules)):"cssRules"in e?Je(e.cssRules,a):a.push(e);return a}var On=/\bx?link:?href\s*=\s*["'](?!data:)[^"']+["']/i;function _n(i){return On.test(i.innerHTML)}function Vn(i,a){return x(this,null,function*(){let e=yield et(i,a);if(K(e.node)&&fe(e.node)&&!_n(e.node))return e.node;let{ownerDocument:t,log:n,tasks:o,svgStyleElement:s,svgDefsElement:r,svgStyles:l,font:c,progress:d,autoDestruct:u,onCloneNode:g,onEmbedNode:m,onCreateForeignObjectSvg:b}=e;n.time("clone node");let h=yield tt(e.node,e,!0);if(s&&t){let S="";l.forEach((C,E)=>{S+=`${C.join(`,
`)} {
  ${E}
}
`}),s.appendChild(t.createTextNode(S))}n.timeEnd("clone node"),yield g==null?void 0:g(h),c!==!1&&K(h)&&(n.time("embed web font"),yield Nn(h,e),n.timeEnd("embed web font")),n.time("embed node"),Yt(h,e);let p=o.length,f=0,w=()=>x(null,null,function*(){for(;;){let S=o.pop();if(!S)break;try{yield S}catch(C){e.log.warn("Failed to run task",C)}d==null||d(++f,p)}});d==null||d(f,p),yield Promise.all([...Array.from({length:4})].map(w)),n.timeEnd("embed node"),yield m==null?void 0:m(h);let v=Un(h,e);return r&&v.insertBefore(r,v.children[0]),s&&v.insertBefore(s,v.children[0]),u&&An(e),yield b==null?void 0:b(v),v})}function Un(i,a){let{width:e,height:t}=a,n=Qi(e,t,i.ownerDocument),o=n.ownerDocument.createElementNS(n.namespaceURI,"foreignObject");return o.setAttributeNS(null,"x","0%"),o.setAttributeNS(null,"y","0%"),o.setAttributeNS(null,"width","100%"),o.setAttributeNS(null,"height","100%"),o.append(i),n.appendChild(o),n}function qn(i,a){return x(this,null,function*(){var s;let e=yield et(i,a),t=yield Vn(e),n=Zi(t,e.isEnable("removeControlCharacter"));e.autoDestruct||(e.svgStyleElement=Ut(e.ownerDocument),e.svgDefsElement=(s=e.ownerDocument)==null?void 0:s.createElementNS(Ne,"defs"),e.svgStyles.clear());let o=oe(n,t.ownerDocument);return yield dn(o,e)})}function Jt(i,a){return x(this,null,function*(){let e=yield et(i,a),{log:t,type:n,quality:o,dpi:s}=e,r=yield qn(e);t.time("canvas to blob");let l=yield en(r,n,o);if(["image/png","image/jpeg"].includes(n)&&s){let c=yield an(l.slice(0,33)),d=new Uint8Array(c);return n==="image/png"?d=Di(d,s):n==="image/jpeg"&&(d=Li(d,s)),t.timeEnd("canvas to blob"),new Blob([d,l.slice(33)],{type:n})}return t.timeEnd("canvas to blob"),l})}var be=require("obsidian");function Qt(i,a){let e=new Blob([i],{type:"text/html;charset=utf-8"});Zt(e,`${a}.html`),new be.Notice("HTML \u4E0B\u8F7D\u5DF2\u5F00\u59CB")}function Zt(i,a){let e=URL.createObjectURL(i),t=document.createElement("a");t.href=e,t.download=a,document.body.appendChild(t),t.click(),t.remove(),setTimeout(()=>URL.revokeObjectURL(e),1e3)}function ei(i,a){return x(this,null,function*(){var e;try{let t=i.contentDocument||((e=i.contentWindow)==null?void 0:e.document);if(!t||!t.body)throw new Error("iframe \u5185\u5BB9\u672A\u52A0\u8F7D");let n=yield Jt(t.body,{scale:2,backgroundColor:"#ffffff"});if(!n)throw new Error("\u622A\u56FE\u5931\u8D25");Zt(n,`${a}.png`),new be.Notice("PNG \u5BFC\u51FA\u6210\u529F")}catch(t){let n=t instanceof Error?t.message:String(t);throw new be.Notice(`PNG \u5BFC\u51FA\u5931\u8D25: ${n}`),t}})}function ti(i,a,e){return x(this,null,function*(){let t=i.vault.adapter,n=e.split("/").slice(0,-1).join("/");n&&!(yield t.exists(n))&&(yield t.mkdir(n)),yield t.write(e,a),new be.Notice(`HTML \u5DF2\u4FDD\u5B58\u5230: ${e}`)})}var re=require("obsidian"),$e=class extends re.Modal{constructor(e,t){super(e);this.onExport=t}onOpen(){let{contentEl:e}=this;e.empty(),e.createEl("h3",{text:"\u5BFC\u51FA"});let t=e.createEl("div",{cls:"lumislate-export-menu"});this.createMenuItem(t,"file-code","\u4E0B\u8F7D HTML","\u4E0B\u8F7D\u4E3A\u5355\u6587\u4EF6 HTML",()=>{this.onExport("html-download"),this.close()}),this.createMenuItem(t,"image","\u4E0B\u8F7D PNG","\u5BFC\u51FA\u4E3A\u9AD8\u6E05\u56FE\u7247",()=>{this.onExport("png-download"),this.close()}),this.createMenuItem(t,"save","\u4FDD\u5B58\u5230 Vault","\u4FDD\u5B58 HTML \u5230 Obsidian \u4ED3\u5E93",()=>{this.onExport("html-vault"),this.close()})}createMenuItem(e,t,n,o,s){let r=e.createEl("div",{cls:"lumislate-export-item"}),l=r.createEl("div",{cls:"lumislate-export-item-title"});(0,re.setIcon)(l.createSpan(),t),l.appendText(" "+n),r.createEl("div",{cls:"lumislate-export-item-desc",text:o}),r.addEventListener("click",s)}};var Fe=class extends re.Modal{constructor(e,t,n,o){super(e);this.skill=t;this.onConfirm=n;this.onCancel=o}onOpen(){let{contentEl:e}=this;e.empty();let t=e.createEl("div",{cls:"lumislate-skill-confirm-header"}),n=t.createEl("div",{cls:"lumislate-skill-confirm-icon"});(0,re.setIcon)(n,this.skill.icon),t.createEl("div",{cls:"lumislate-skill-confirm-name",text:this.skill.name}),this.skill.description&&e.createEl("p",{cls:"lumislate-skill-confirm-desc",text:this.skill.description});let o=e.createEl("div",{cls:"lumislate-modal-buttons"});o.createEl("button",{text:"\u53D6\u6D88",cls:"lumislate-btn lumislate-btn-ghost"}).addEventListener("click",()=>{this.onCancel(),this.close()}),o.createEl("button",{text:"\u786E\u8BA4\u6E32\u67D3",cls:"lumislate-btn lumislate-btn-primary"}).addEventListener("click",()=>{this.onConfirm(),this.close()})}onClose(){let{contentEl:e}=this;e.empty()}};var ie="lumislate-canvas-view";function X(i){return i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function jn(i,a,e){let t=i.replace(/!\[\[([^\]]+?)\]\]/g,(n,o)=>{let s=o.indexOf("|"),r=s>=0?o.slice(0,s).trim():o,l=a.metadataCache.getFirstLinkpathDest(r,e);return l instanceof y.TFile?`![${r}](${a.vault.getResourcePath(l)})`:n});return t=t.replace(/!\[([^\]]*?)\]\(([^)]+?)\)/g,(n,o,s)=>{if(/^(https?:|data:|app:|obsidian:)/i.test(s))return n;let r=a.vault.getAbstractFileByPath(s);if(r instanceof y.TFile)return`![${o}](${a.vault.getResourcePath(r)})`;let l=e.includes("/")?e.substring(0,e.lastIndexOf("/")):"",c=l?`${l}/${s}`:s,d=a.vault.getAbstractFileByPath(c);return d instanceof y.TFile?`![${o}](${a.vault.getResourcePath(d)})`:n}),t}function ve(i){let a=i.split(`
`),e="",t=!1,n=null,o=!1;function s(){o&&(e+="</p>",o=!1)}function r(){t&&(e+="</ul>",t=!1,n=null)}function l(){o?e+="<br>":(e+="<p>",o=!0)}function c(h){return X(h).replace(/&lt;u&gt;(.+?)&lt;\/u&gt;/g,"<u>$1</u>").replace(/==(.+?)==/g,"<mark>$1</mark>").replace(/~~(.+?)~~/g,"<del>$1</del>").replace(/`([^`]+?)`/g,"<code>$1</code>").replace(/!\[([^\]]*?)\]\(([^)]+?)\)/g,'<img alt="$1" src="$2">').replace(/!\[\[([^\]]+?)\]\]/g,'<img alt="$1" src="$1">').replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/\*(.+?)\*/g,"<em>$1</em>")}function d(h){let p=h.trim(),f=p.match(/^!\[([^\]]*?)\]\((.*)\)$/);if(f)return`<img alt="${X(f[1])}" src="${X(f[2])}">`;let w=p.match(/^!\[\[([^\]]+?)\]\]$/);return w?`<img alt="${X(w[1])}" src="${X(w[1])}">`:null}function u(h){let p=h,f=[],w=!1;for(;p<a.length;){let S=a[p].trim();if(!S.includes("|"))break;if(/^\|?[\s\-:|]+\|?$/.test(S)&&S.includes("-")){w=!0,p++;continue}let C=S.split("|").map(E=>E.trim()).filter((E,N,H)=>!(N===0&&S.startsWith("|")&&E===""||N===H.length-1&&S.endsWith("|")&&E===""));if(C.length===0)break;f.push(C),p++}if(f.length===0||f.length===1&&!w)return null;let v="<table>";if(w){v+="<thead><tr>";for(let S of f[0])v+=`<th>${c(S)}</th>`;v+="</tr></thead><tbody>";for(let S=1;S<f.length;S++){v+="<tr>";for(let C of f[S])v+=`<td>${c(C)}</td>`;v+="</tr>"}v+="</tbody>"}else{v+="<tbody>";for(let S of f){v+="<tr>";for(let C of S)v+=`<td>${c(C)}</td>`;v+="</tr>"}v+="</tbody>"}return v+="</table>",{html:v,end:p-1}}function g(h){let f=a[h].trim().match(/^```(\w*)/);if(!f)return null;let w=f[1]||"",v=h+1,S=[];for(;v<a.length;){if(a[v].trim()==="```"){v++;break}S.push(a[v]),v++}let C=X(S.join(`
`));return{html:`<pre><code${w?` class="language-${w}"`:""}>${C}</code></pre>`,end:v-1}}function m(h){let p=h,f=[];for(;p<a.length;){let C=a[p];if(!C.trim().startsWith(">"))break;f.push(C.replace(/^>\s?/,"")),p++}if(f.length===0)return null;let v=f[0].trim().match(/^\[!([\w-]+)\]\s*(.*)$/);if(v){let C=v[1].toLowerCase(),E=v[2]||C.charAt(0).toUpperCase()+C.slice(1),N=f.slice(1),H=N.length>0?N.map(q=>c(q)).join("<br>"):"";return{html:`<div class="callout callout-${C}"><div class="callout-title">${c(E)}</div>${H?`<div class="callout-content">${H}</div>`:""}</div>`,end:p-1}}return{html:`<blockquote>${f.map(C=>c(C)).join("<br>")}</blockquote>`,end:p-1}}function b(h){let p=h+1,f=[];for(;p<a.length;){if(a[p].trim()==="$$"){p++;break}f.push(a[p]),p++}return f.length===0?null:{html:`<div class="math-block">${X(f.join(`
`))}</div>`,end:p-1}}for(let h=0;h<a.length;h++){let p=a[h],f=p.trim();if(f==="---"){s(),r(),e+="<hr>";continue}if(f===""){s(),r();continue}if(f.startsWith("```")){let w=g(h);if(w){s(),r(),e+=w.html,h=w.end;continue}}if(f==="$$"){let w=b(h);if(w){s(),r(),e+=w.html,h=w.end;continue}}if(f.includes("|")){let w=u(h);if(w){s(),r(),e+=w.html,h=w.end;continue}}if(f.startsWith(">")){let w=m(h);if(w){s(),r(),e+=w.html,h=w.end;continue}}if(f.startsWith("# "))s(),r(),e+=`<h1>${c(f.slice(2))}</h1>`;else if(f.startsWith("## "))s(),r(),e+=`<h2>${c(f.slice(3))}</h2>`;else if(f.startsWith("### "))s(),r(),e+=`<h3>${c(f.slice(4))}</h3>`;else if(f.startsWith("#### "))s(),r(),e+=`<h4>${c(f.slice(5))}</h4>`;else if(f.startsWith("##### "))s(),r(),e+=`<h5>${c(f.slice(6))}</h5>`;else if(f.startsWith("###### "))s(),r(),e+=`<h6>${c(f.slice(7))}</h6>`;else if(f.startsWith("- ")){s();let w=/^- \[[ xX]\] /.test(f),v=w?"task":"normal";if((!t||n!==v)&&(r(),e+=w?'<ul class="task-list">':"<ul>",t=!0,n=v),w){let S=f[3]==="x"||f[3]==="X",C=f.slice(6);e+=`<li class="task-list-item"><input type="checkbox" disabled${S?" checked":""}> ${c(C)}</li>`}else e+=`<li>${c(f.slice(2))}</li>`}else{let w=d(p);if(w){s(),r();let v=[w],S=h+1;for(;S<a.length;){if(a[S].trim()===""){S++;continue}let E=d(a[S]);if(E)v.push(E),S++;else break}v.length>1?e+=`<div class="image-group">${v.join("")}</div>`:e+=`<div class="image-group">${w}</div>`,h=S-1}else r(),l(),e+=c(p)}}return s(),r(),e}function Gn(i){return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 100%; min-height: 100%; }
body {
  background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
  color: #e2e8f0;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  padding: 2.5rem;
  line-height: 1.75;
}
h1 { font-size: 1.875rem; font-weight: 800; margin-bottom: 1rem; letter-spacing: -0.02em; }
h2 { font-size: 1.5rem; font-weight: 700; margin: 1.5rem 0 0.75rem; }
h3 { font-size: 1.25rem; font-weight: 600; margin: 1.25rem 0 0.5rem; }
p  { margin-bottom: 0.75rem; }
ul { margin-left: 1.5rem; margin-bottom: 0.75rem; }
li { margin-bottom: 0.25rem; }
hr { border: none; border-top: 1px solid #334155; margin: 1.5rem 0; }
mark { background: rgba(250, 204, 21, 0.3); color: inherit; padding: 0.1em 0.25em; border-radius: 3px; }
u { text-decoration: underline; text-decoration-color: rgba(96, 165, 250, 0.6); text-underline-offset: 3px; }
h4 { font-size: 1.125rem; font-weight: 600; margin: 1rem 0 0.5rem; }
h5 { font-size: 1rem; font-weight: 600; margin: 0.875rem 0 0.5rem; }
h6 { font-size: 0.875rem; font-weight: 600; margin: 0.75rem 0 0.5rem; color: rgba(226, 232, 240, 0.8); }
.task-list { list-style: none; margin-left: 0; padding-left: 0; }
.task-list-item { display: flex; align-items: flex-start; gap: 0.5rem; margin-bottom: 0.35rem; }
.task-list-item input[type="checkbox"] { margin-top: 0.25rem; accent-color: #60a5fa; }
.math-block { background: rgba(0,0,0,0.15); padding: 0.75rem 1rem; border-radius: 8px; overflow-x: auto; font-family: 'KaTeX_Math', 'Times New Roman', serif; text-align: center; margin: 0.75rem 0; }
.lumislate-hover {
  background: rgba(96, 165, 250, 0.12);
  cursor: text;
  border-radius: 2px;
  transition: background 0.15s ease;
}
.lumislate-editing {
  outline: none;
  border: none;
  border-radius: 0;
  background: transparent;
  cursor: text;
  caret-color: currentColor;
}
</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>
</head>
<body>
${i}
<script>
(function() {
  function initMath() {
    if (typeof renderMathInElement === 'undefined') {
      setTimeout(initMath, 100);
      return;
    }
    renderMathInElement(document.body, {
      delimiters: [
        {left: '$$', right: '$$', display: true},
        {left: '$', right: '$', display: false}
      ],
      throwOnError: false
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMath);
  } else {
    initMath();
  }
})();
</script>
</body>
</html>`}function Wn(i){let a=i.match(/^(\d+):(\d+)$/);if(!a)return{width:1280,height:720};let e=parseInt(a[1],10),t=parseInt(a[2],10),n=1280,o=Math.round(n*(t/e));return{width:n,height:o}}var Kn=new Set(["layout","class","backgroundcolor","backgroundimage","backgroundsize","backgroundposition","backgroundrepeat","color","header","footer","theme","paginate","size","headingdivider","math","lang","style"]);function Xn(i){let a=i.split(`
`).filter(t=>t.trim()!=="");return a.length===0||!a.every(t=>t.match(/^[a-zA-Z_]\w*:\s*.+$/))?!1:a.some(t=>{var o;let n=(o=t.match(/^([a-zA-Z_]\w*):/))==null?void 0:o[1].toLowerCase();return n&&Kn.has(n)})}function it(i,a){let e=new RegExp(`^${a}:\\s*(.*)$`,"im"),t=i.match(e);return t?t[1].trim().replace(/^["']|["']$/g,""):""}function Yn(i){let a=i.split(/^---\s*$/m).map(n=>n.trim()).filter(n=>n.length>0),e=[],t="";for(let n of a)Xn(n)?t=n:(e.push({frontmatter:t,content:n}),t="");return t&&e.push({frontmatter:t,content:""}),e.filter(n=>n.content.trim()||n.frontmatter.trim())}function Jn(i,a){var t;let e=`
::right::
`;if(a==="two-cols"&&i.includes(e)){let n=i.split(e),o=ve(n[0].trim()),s=ve(((t=n[1])==null?void 0:t.trim())||"");return`<div class="col-left">${o}</div><div class="col-right">${s}</div>`}return ve(i)}function Qn(i,a){let e=ve(i);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
  font-size: ${a.baseFontSize||16}px;
  --ls-body-bg: ${a.bgColor};
  --ls-body-color: ${a.textColor};
  --ls-font-family: ${a.fontFamily||"system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"};
  --ls-content-padding: 3rem 4rem;
  --ls-line-height: 1.75;
  --ls-h1-size: 2.5rem;
  --ls-h1-weight: 800;
  --ls-h1-margin: 0 0 1.5rem 0;
  --ls-h2-size: 1.75rem;
  --ls-h2-weight: 700;
  --ls-h2-margin: 1.5rem 0 1rem 0;
  --ls-h3-size: 1.25rem;
  --ls-h3-weight: 600;
  --ls-h3-margin: 1rem 0 0.5rem 0;
  --ls-p-margin: 0 0 0.75rem 0;
  --ls-list-margin: 0 0 0.75rem 2rem;
  --ls-li-margin: 0 0 0.35rem 0;
  --ls-hr-border: 1px solid rgba(255,255,255,0.1);
  --ls-hr-margin: 1.5rem 0;
  --ls-table-margin: 1rem 0;
  --ls-table-border: rgba(255,255,255,0.15);
  --ls-table-cell-padding: 0.5rem 0.75rem;
  --ls-table-head-bg: rgba(255,255,255,0.08);
  --ls-table-row-alt-bg: rgba(255,255,255,0.03);
  --ls-blockquote-margin: 1rem 0;
  --ls-blockquote-padding: 0.75rem 1rem;
  --ls-blockquote-border: 3px solid rgba(255,255,255,0.2);
  --ls-blockquote-color: rgba(255,255,255,0.8);
  --ls-callout-margin: 1rem 0;
  --ls-callout-padding: 0.75rem 1rem;
  --ls-callout-radius: 8px;
  --ls-callout-border-width: 4px;
  --ls-callout-bg: rgba(255,255,255,0.04);
  --ls-callout-title-size: 0.95rem;
  --ls-callout-title-weight: 700;
  --ls-callout-title-margin: 0 0 0.35rem 0;
  --ls-callout-content-size: 0.9rem;
  --ls-callout-content-line-height: 1.6;
  --ls-callout-note-color: #3b82f6;
  --ls-callout-tip-color: #22c55e;
  --ls-callout-warning-color: #f59e0b;
  --ls-callout-danger-color: #ef4444;
  --ls-callout-question-color: #a855f7;
  --ls-callout-example-color: #6b7280;
}
html, body { width: 100%; min-height: 100%; background: var(--ls-body-bg); color: var(--ls-body-color); font-family: var(--ls-font-family); }
#longform-content { width: 100%; min-height: 100%; padding: var(--ls-content-padding); line-height: var(--ls-line-height); }
#longform-content h1 { font-size: var(--ls-h1-size); font-weight: var(--ls-h1-weight); margin: var(--ls-h1-margin); }
#longform-content h2 { font-size: var(--ls-h2-size); font-weight: var(--ls-h2-weight); margin: var(--ls-h2-margin); }
#longform-content h3 { font-size: var(--ls-h3-size); font-weight: var(--ls-h3-weight); margin: var(--ls-h3-margin); }
#longform-content p { margin: var(--ls-p-margin); }
#longform-content ul, #longform-content ol { margin: var(--ls-list-margin); }
#longform-content li { margin: var(--ls-li-margin); }
#longform-content hr { border: none; border-top: var(--ls-hr-border); margin: var(--ls-hr-margin); }
#longform-content table { width: 100%; border-collapse: collapse; margin: var(--ls-table-margin); }
#longform-content th, #longform-content td { border: 1px solid var(--ls-table-border); padding: var(--ls-table-cell-padding); text-align: left; }
#longform-content th { background: var(--ls-table-head-bg); font-weight: 600; }
#longform-content tr:nth-child(even) { background: var(--ls-table-row-alt-bg); }
#longform-content blockquote { margin: var(--ls-blockquote-margin); padding: var(--ls-blockquote-padding); border-left: var(--ls-blockquote-border); font-style: italic; color: var(--ls-blockquote-color); }
#longform-content .callout { margin: var(--ls-callout-margin); padding: var(--ls-callout-padding); border-radius: var(--ls-callout-radius); border-left: var(--ls-callout-border-width) solid; background: var(--ls-callout-bg); }
#longform-content .callout-title { font-weight: var(--ls-callout-title-weight); margin: var(--ls-callout-title-margin); font-size: var(--ls-callout-title-size); }
#longform-content .callout-content { font-size: var(--ls-callout-content-size); line-height: var(--ls-callout-content-line-height); }
#longform-content .callout-note, #longform-content .callout-info, #longform-content .callout-todo { border-left-color: var(--ls-callout-note-color); }
#longform-content .callout-note > .callout-title, #longform-content .callout-info > .callout-title, #longform-content .callout-todo > .callout-title { color: var(--ls-callout-note-color); }
#longform-content .callout-tip, #longform-content .callout-hint, #longform-content .callout-important, #longform-content .callout-success, #longform-content .callout-check, #longform-content .callout-done { border-left-color: var(--ls-callout-tip-color); }
#longform-content .callout-tip > .callout-title, #longform-content .callout-hint > .callout-title, #longform-content .callout-important > .callout-title, #longform-content .callout-success > .callout-title, #longform-content .callout-check > .callout-title, #longform-content .callout-done > .callout-title { color: var(--ls-callout-tip-color); }
#longform-content .callout-warning, #longform-content .callout-caution, #longform-content .callout-attention { border-left-color: var(--ls-callout-warning-color); }
#longform-content .callout-warning > .callout-title, #longform-content .callout-caution > .callout-title, #longform-content .callout-attention > .callout-title { color: var(--ls-callout-warning-color); }
#longform-content .callout-danger, #longform-content .callout-error, #longform-content .callout-bug { border-left-color: var(--ls-callout-danger-color); }
#longform-content .callout-danger > .callout-title, #longform-content .callout-error > .callout-title, #longform-content .callout-bug > .callout-title { color: var(--ls-callout-danger-color); }
#longform-content .callout-question, #longform-content .callout-help, #longform-content .callout-faq { border-left-color: var(--ls-callout-question-color); }
#longform-content .callout-question > .callout-title, #longform-content .callout-help > .callout-title, #longform-content .callout-faq > .callout-title { color: var(--ls-callout-question-color); }
#longform-content .callout-example, #longform-content .callout-quote { border-left-color: var(--ls-callout-example-color); }
#longform-content .callout-example > .callout-title, #longform-content .callout-quote > .callout-title { color: var(--ls-callout-example-color); }
#longform-content img { max-width: 100%; height: auto; display: block; border-radius: 6px; margin: 0.5rem 0; object-fit: contain; }
#longform-content .image-group { display: flex; flex-wrap: wrap; gap: 1rem; justify-content: center; align-items: flex-start; margin: 0.5rem 0; }
#longform-content .image-group img { flex: 1 1 0; min-width: 0; max-width: 48%; margin: 0; }
#longform-content .image-group img:only-child { flex: 0 0 auto; max-width: 100%; }
#longform-content pre { background: rgba(0,0,0,0.2); padding: 0.75rem 1rem; border-radius: 8px; overflow-x: auto; max-width: 100%; margin: 0.5rem 0; }
#longform-content pre code { font-family: 'Fira Code', 'JetBrains Mono', 'SF Mono', Monaco, monospace; font-size: 0.8rem; line-height: 1.5; background: transparent; padding: 0; }
#longform-content code { font-family: 'Fira Code', 'JetBrains Mono', 'SF Mono', Monaco, monospace; font-size: 0.85em; background: rgba(0,0,0,0.15); padding: 0.15rem 0.35rem; border-radius: 4px; }
#longform-content del { opacity: 0.6; text-decoration: line-through; }
#longform-content mark { background: rgba(250, 204, 21, 0.3); color: inherit; padding: 0.1em 0.25em; border-radius: 3px; }
#longform-content u { text-decoration: underline; text-decoration-color: rgba(96, 165, 250, 0.6); text-underline-offset: 3px; }
#longform-content h4 { font-size: 1.125rem; font-weight: 600; margin: 1rem 0 0.5rem 0; }
#longform-content h5 { font-size: 1rem; font-weight: 600; margin: 0.875rem 0 0.5rem 0; opacity: 0.9; }
#longform-content h6 { font-size: 0.875rem; font-weight: 600; margin: 0.75rem 0 0.5rem 0; opacity: 0.8; }
#longform-content .task-list { list-style: none; margin-left: 0; padding-left: 0; }
#longform-content .task-list-item { display: flex; align-items: flex-start; gap: 0.5rem; margin-bottom: 0.35rem; }
#longform-content .task-list-item input[type="checkbox"] { margin-top: 0.25rem; accent-color: #60a5fa; }
#longform-content .math-block { background: rgba(0,0,0,0.15); padding: 0.75rem 1rem; border-radius: 8px; overflow-x: auto; font-family: 'KaTeX_Math', 'Times New Roman', serif; text-align: center; margin: 0.75rem 0; }
${a.customCss||""}
.lumislate-hover { background: rgba(96, 165, 250, 0.12); cursor: text; border-radius: 2px; transition: background 0.15s ease; }
.lumislate-editing { outline: none; border: none; border-radius: 0; background: transparent; cursor: text; caret-color: currentColor; }
</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>
</head>
<body>
<div id="longform-content">
${e}
</div>
<script>
(function() {
  function initMath() {
    if (typeof renderMathInElement === 'undefined') {
      setTimeout(initMath, 100);
      return;
    }
    renderMathInElement(document.body, {
      delimiters: [
        {left: '$$', right: '$$', display: true},
        {left: '$', right: '$', display: false}
      ],
      throwOnError: false
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMath);
  } else {
    initMath();
  }
})();
</script>
</body>
</html>`}function Zn(i,a,e,t,n){return x(this,null,function*(){let{frontmatter:o,body:s}=F(i),r=D(o,"backgroundcolor")||D(o,"backgroundColor")||"#0f172a",l=D(o,"color")||(n==null?void 0:n.textColor)||"#e2e8f0",d=D(o,"paginate")==="true",u=D(o,"size")||"16:9",g=D(o,"lumislate_css"),m="";if(g){let v=`${e}/css/${g}`;m=yield a.vault.adapter.read(v).catch(()=>"")}if(!/^---\s*$/m.test(s))return Qn(s,{bgColor:r,textColor:l,customCss:m,baseFontSize:n==null?void 0:n.baseFontSize,fontFamily:n==null?void 0:n.fontFamily});let h=Yn(s);h.length===0&&h.push({frontmatter:"",content:s.trim()||"(\u7A7A\u5E7B\u706F\u7247)"});let{width:p,height:f}=Wn(u),w=h.map((v,S)=>{let C=D(o,"layout")||"default",E=t(S)||C,N=it(v.frontmatter,"class")||"",H=it(v.frontmatter,"backgroundColor")||it(v.frontmatter,"backgroundcolor")||"",q=Jn(v.content,E),A=d?`<div class="slide-paginate">${S+1} / ${h.length}</div>`:"",P=[`class="slide ${N}"`,`data-index="${S}"`,`data-layout="${E}"`];return H&&P.push(`style="background: ${H};"`),`<div class="slide-wrapper"><section ${P.join(" ")}>${q}${A}</section></div>`}).join(`
`);return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
  font-size: ${(n==null?void 0:n.baseFontSize)||16}px;
  --ls-body-bg: ${r};
  --ls-body-color: ${l};
  --ls-font-family: ${(n==null?void 0:n.fontFamily)||"system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"};
  --ls-deck-gap: 1rem;
  --ls-deck-padding: 1rem;
  --ls-slide-padding: 3rem 4rem;
  --ls-slide-bg: rgba(255,255,255,0.03);
  --ls-slide-radius: 12px;
  --ls-slide-line-height: 1.75;
  --ls-h1-size: 2.5rem;
  --ls-h1-weight: 800;
  --ls-h1-margin: 0 0 1.5rem 0;
  --ls-h2-size: 1.75rem;
  --ls-h2-weight: 700;
  --ls-h2-margin: 1.5rem 0 1rem 0;
  --ls-h3-size: 1.25rem;
  --ls-h3-weight: 600;
  --ls-h3-margin: 1rem 0 0.5rem 0;
  --ls-p-margin: 0 0 0.75rem 0;
  --ls-list-margin: 0 0 0.75rem 2rem;
  --ls-li-margin: 0 0 0.35rem 0;
  --ls-table-font-size: 0.85rem;
  --ls-table-margin: 0.75rem 0;
  --ls-table-border: rgba(255,255,255,0.15);
  --ls-table-cell-padding: 0.35rem 0.5rem;
  --ls-table-head-bg: rgba(255,255,255,0.08);
  --ls-table-row-alt-bg: rgba(255,255,255,0.03);
  --ls-blockquote-margin: 0.5rem 0;
  --ls-blockquote-padding: 0.4rem 0.6rem;
  --ls-blockquote-border: 2px solid rgba(255,255,255,0.2);
  --ls-blockquote-color: rgba(255,255,255,0.8);
  --ls-blockquote-font-size: 0.85rem;
  --ls-callout-margin: 0.5rem 0;
  --ls-callout-padding: 0.4rem 0.6rem;
  --ls-callout-radius: 6px;
  --ls-callout-border-width: 3px;
  --ls-callout-bg: rgba(255,255,255,0.04);
  --ls-callout-title-size: 0.8rem;
  --ls-callout-title-weight: 700;
  --ls-callout-title-margin: 0 0 0.2rem 0;
  --ls-callout-content-size: 0.75rem;
  --ls-callout-content-line-height: 1.5;
  --ls-callout-note-color: #3b82f6;
  --ls-callout-tip-color: #22c55e;
  --ls-callout-warning-color: #f59e0b;
  --ls-callout-danger-color: #ef4444;
  --ls-callout-question-color: #a855f7;
  --ls-callout-example-color: #6b7280;
  --ls-paginate-font-size: 12px;
  --ls-paginate-bottom: 16px;
  --ls-paginate-right: 24px;
  --ls-paginate-opacity: 0.5;
}
html, body { width: 100%; height: 100%; overflow-x: visible; overflow-y: auto; }
body { background: var(--ls-body-bg); color: var(--ls-body-color); font-family: var(--ls-font-family); }
#custom-deck { width: 100%; min-height: 100%; overflow-x: visible; overflow-y: auto; display: flex; flex-direction: column; gap: var(--ls-deck-gap); padding: var(--ls-deck-padding); align-items: center; }
.slide-wrapper { display: flex; overflow: hidden; flex-shrink: 0; }
/* \u5FC5\u987B\u5199\u6B7B\u7684\u5E03\u5C40\u5F15\u64CE\uFF08\u7528\u6237\u4E0D\u5E94\u8986\u76D6\uFF09 */
.slide { position: relative; width: ${p}px !important; height: ${f}px !important; flex-shrink: 0; transform-origin: 0 0; overflow: hidden; }
/* \u89C6\u89C9\u6837\u5F0F\u653E\u5728 section \u4E0A\uFF0C\u7528\u6237\u5199 section { ... } \u5373\u53EF\u8986\u76D6 */
section { background: var(--ls-slide-bg); border-radius: var(--ls-slide-radius); padding: var(--ls-slide-padding); display: flex; flex-direction: column; justify-content: center; line-height: var(--ls-slide-line-height); }
section h1 { font-size: var(--ls-h1-size); font-weight: var(--ls-h1-weight); margin: var(--ls-h1-margin); }
section h2 { font-size: var(--ls-h2-size); font-weight: var(--ls-h2-weight); margin: var(--ls-h2-margin); }
section h3 { font-size: var(--ls-h3-size); font-weight: var(--ls-h3-weight); margin: var(--ls-h3-margin); }
section p { margin: var(--ls-p-margin); }
section ul, section ol { margin: var(--ls-list-margin); }
section li { margin: var(--ls-li-margin); }
section table { width: 100%; border-collapse: collapse; margin: var(--ls-table-margin); font-size: var(--ls-table-font-size); }
section th, section td { border: 1px solid var(--ls-table-border); padding: var(--ls-table-cell-padding); text-align: left; }
section th { background: var(--ls-table-head-bg); font-weight: 600; }
section tr:nth-child(even) { background: var(--ls-table-row-alt-bg); }
section blockquote { margin: var(--ls-blockquote-margin); padding: var(--ls-blockquote-padding); border-left: var(--ls-blockquote-border); font-style: italic; color: var(--ls-blockquote-color); font-size: var(--ls-blockquote-font-size); }
section .callout { margin: var(--ls-callout-margin); padding: var(--ls-callout-padding); border-radius: var(--ls-callout-radius); border-left: var(--ls-callout-border-width) solid; background: var(--ls-callout-bg); }
section .callout-title { font-weight: var(--ls-callout-title-weight); margin: var(--ls-callout-title-margin); font-size: var(--ls-callout-title-size); }
section .callout-content { font-size: var(--ls-callout-content-size); line-height: var(--ls-callout-content-line-height); }
section .callout-note, section .callout-info, section .callout-todo { border-left-color: var(--ls-callout-note-color); }
section .callout-note > .callout-title, section .callout-info > .callout-title, section .callout-todo > .callout-title { color: var(--ls-callout-note-color); }
section .callout-tip, section .callout-hint, section .callout-important, section .callout-success, section .callout-check, section .callout-done { border-left-color: var(--ls-callout-tip-color); }
section .callout-tip > .callout-title, section .callout-hint > .callout-title, section .callout-important > .callout-title, section .callout-success > .callout-title, section .callout-check > .callout-title, section .callout-done > .callout-title { color: var(--ls-callout-tip-color); }
section .callout-warning, section .callout-caution, section .callout-attention { border-left-color: var(--ls-callout-warning-color); }
section .callout-warning > .callout-title, section .callout-caution > .callout-title, section .callout-attention > .callout-title { color: var(--ls-callout-warning-color); }
section .callout-danger, section .callout-error, section .callout-bug { border-left-color: var(--ls-callout-danger-color); }
section .callout-danger > .callout-title, section .callout-error > .callout-title, section .callout-bug > .callout-title { color: var(--ls-callout-danger-color); }
section .callout-question, section .callout-help, section .callout-faq { border-left-color: var(--ls-callout-question-color); }
section .callout-question > .callout-title, section .callout-help > .callout-title, section .callout-faq > .callout-title { color: var(--ls-callout-question-color); }
section .callout-example, section .callout-quote { border-left-color: var(--ls-callout-example-color); }
section .callout-example > .callout-title, section .callout-quote > .callout-title { color: var(--ls-callout-example-color); }
section img { max-width: 100%; max-height: 280px; height: auto; display: block; border-radius: 6px; margin: 0.5rem auto; object-fit: contain; }
section .image-group { display: flex; flex-wrap: wrap; gap: 0.75rem; justify-content: center; align-items: center; margin: 0.5rem 0; }
section .image-group img { max-height: 220px; flex: 1 1 0; min-width: 0; margin: 0; }
section .image-group img:only-child { flex: 0 0 auto; max-width: 100%; max-height: 280px; }
section pre { background: rgba(0,0,0,0.2); padding: 0.75rem 1rem; border-radius: 8px; overflow-x: auto; overflow-y: auto; max-width: 100%; max-height: 45%; margin: 0.5rem 0; }
section pre code { font-family: 'Fira Code', 'JetBrains Mono', 'SF Mono', Monaco, monospace; font-size: 0.8rem; line-height: 1.5; background: transparent; padding: 0; }
section code { font-family: 'Fira Code', 'JetBrains Mono', 'SF Mono', Monaco, monospace; font-size: 0.85em; background: rgba(0,0,0,0.15); padding: 0.15rem 0.35rem; border-radius: 4px; }
section del { opacity: 0.6; text-decoration: line-through; }
section mark { background: rgba(250, 204, 21, 0.3); color: inherit; padding: 0.1em 0.25em; border-radius: 3px; }
section u { text-decoration: underline; text-decoration-color: rgba(96, 165, 250, 0.6); text-underline-offset: 3px; }
section h4 { font-size: 1.1rem; font-weight: 600; margin: 0.75rem 0 0.4rem 0; }
section h5 { font-size: 1rem; font-weight: 600; margin: 0.65rem 0 0.35rem 0; opacity: 0.9; }
section h6 { font-size: 0.9rem; font-weight: 600; margin: 0.55rem 0 0.3rem 0; opacity: 0.8; }
section .task-list { list-style: none; margin-left: 0; padding-left: 0; }
section .task-list-item { display: flex; align-items: flex-start; gap: 0.4rem; margin-bottom: 0.25rem; font-size: 0.85rem; }
section .task-list-item input[type="checkbox"] { margin-top: 0.15rem; accent-color: #60a5fa; }
section .math-block { background: rgba(0,0,0,0.15); padding: 0.5rem 0.75rem; border-radius: 6px; overflow-x: auto; font-family: 'KaTeX_Math', 'Times New Roman', serif; text-align: center; margin: 0.5rem 0; font-size: 0.85rem; }
.slide-paginate { position: absolute; bottom: var(--ls-paginate-bottom); right: var(--ls-paginate-right); font-size: var(--ls-paginate-font-size); opacity: var(--ls-paginate-opacity); }
/* ===== \u7248\u5F0F\u6A21\u677F\u7CFB\u7EDF\uFF08Layout System\uFF09===== */
section[data-layout="cover"] { text-align: center; justify-content: center; align-items: center; }
section[data-layout="cover"] h1 { margin-bottom: 0.75rem; }
section[data-layout="cover"] h2 { opacity: 0.75; font-weight: 400; margin-top: 0; }
section[data-layout="cover"] p { opacity: 0.7; }

section[data-layout="center"] { text-align: center; justify-content: center; align-items: center; }
section[data-layout="center"] * { text-align: center; }

section[data-layout="two-cols"] { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; align-items: start; align-content: center; }
section[data-layout="two-cols"] .col-left, section[data-layout="two-cols"] .col-right { overflow: hidden; min-width: 0; }
section[data-layout="two-cols"] h1, section[data-layout="two-cols"] h2 { grid-column: 1 / -1; margin-bottom: 0.5rem; }

section[data-layout="statement"] { text-align: center; justify-content: center; align-items: center; }
section[data-layout="statement"] blockquote { border: none; font-style: italic; padding: 0; margin: 0; }
section[data-layout="statement"] blockquote::before { content: '\\201C'; font-size: 3rem; opacity: 0.3; line-height: 1; display: block; margin-bottom: 0.5rem; }
section[data-layout="statement"] p { opacity: 0.6; margin-top: 1.5rem; }

section[data-layout="section"] { text-align: center; justify-content: center; align-items: center; }
section[data-layout="section"] h1 { letter-spacing: -0.02em; }
section[data-layout="section"] h1::after { content: ''; display: block; width: 80px; height: 4px; background: linear-gradient(90deg, #6366f1, #a78bfa); margin: 1.5rem auto 0; border-radius: 2px; }
section[data-layout="section"] h2 { opacity: 0.6; font-weight: 400; margin-top: 1rem; }
section[data-layout="section"] *:not(h1):not(h2) { display: none; }
${m}
.lumislate-hover { background: rgba(96, 165, 250, 0.12); cursor: text; border-radius: 2px; transition: background 0.15s ease; }
.lumislate-editing { outline: none; border: none; border-radius: 0; background: transparent; cursor: text; caret-color: currentColor; }
</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>
</head>
<body>
<div id="custom-deck">
${w}
</div>
<script>
(function() {
  function fitSlides() {
    var deck = document.getElementById('custom-deck');
    if (!deck) return;
    var deckWidth = deck.clientWidth - 32;
    var slides = document.querySelectorAll('.slide');
    for (var i = 0; i < slides.length; i++) {
      var slide = slides[i];
      var wrapper = slide.parentElement;
      slide.style.transform = 'none';
      var w0 = slide.offsetWidth;
      var h0 = slide.offsetHeight;
      var scale = Math.min(1, deckWidth / w0);
      slide.style.transform = 'scale(' + scale + ')';
      wrapper.style.width = (w0 * scale) + 'px';
      wrapper.style.height = (h0 * scale) + 'px';
    }
  }
  window.addEventListener('resize', fitSlides);
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fitSlides);
  } else {
    fitSlides();
  }
  setTimeout(fitSlides, 50);
})();
</script>
<script>
(function() {
  function initMath() {
    if (typeof renderMathInElement === 'undefined') {
      setTimeout(initMath, 100);
      return;
    }
    renderMathInElement(document.body, {
      delimiters: [
        {left: '$$', right: '$$', display: true},
        {left: '$', right: '$', display: false}
      ],
      throwOnError: false
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMath);
  } else {
    initMath();
  }
})();
</script>
</body>
</html>`})}function ea(i,a){return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 100%; height: 100%; overflow: hidden; }
body {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%);
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  color: #e2e8f0;
}
.loading-wrap {
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
  animation: fadeIn 0.4s ease-out;
}
.spinner-ring {
  position: relative;
  width: 56px;
  height: 56px;
}
.spinner-ring svg {
  width: 100%; height: 100%;
  animation: spin 1.2s linear infinite;
}
.spinner-ring circle {
  fill: none;
  stroke: url(#spinnerGrad);
  stroke-width: 4;
  stroke-linecap: round;
  stroke-dasharray: 120;
  stroke-dashoffset: 30;
}
.loading-title {
  font-size: 1.15rem;
  font-weight: 600;
  color: #e2e8f0;
  letter-spacing: 0.02em;
}
.loading-meta {
  font-size: 0.8rem;
  color: #64748b;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.loading-meta .dot {
  width: 6px; height: 6px;
  border-radius: 50%;
  background: #22c55e;
  animation: pulse 1.5s ease-in-out infinite;
}
.loading-hint {
  font-size: 0.75rem;
  color: #475569;
  max-width: 260px;
  line-height: 1.5;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.4; transform: scale(0.7); }
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>
<div class="loading-wrap">
  <div class="spinner-ring">
    <svg viewBox="0 0 56 56">
      <defs>
        <linearGradient id="spinnerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="#6366f1" />
          <stop offset="100%" stop-color="#a78bfa" />
        </linearGradient>
      </defs>
      <circle cx="28" cy="28" r="24" />
    </svg>
  </div>
  <div class="loading-title">AI \u6B63\u5728\u601D\u8003\u4E2D\u2026</div>
  <div class="loading-meta"><span class="dot"></span><span>${X(a)} \xB7 ${X(i)}</span></div>
  <div class="loading-hint">\u8BBE\u8BA1\u751F\u6210\u53EF\u80FD\u9700\u8981\u51E0\u79D2\u5230\u51E0\u5341\u79D2\uFF0C\u53D6\u51B3\u4E8E\u5185\u5BB9\u957F\u5EA6\u548C\u6A21\u578B\u54CD\u5E94\u901F\u5EA6</div>
</div>
</body>
</html>`}function ii(){return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 100%; height: 100%; overflow: hidden; }
body {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%);
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  color: #e2e8f0;
}
.welcome {
  text-align: center;
  animation: fadeIn 0.8s ease-out;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
}
.logo-area {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
}
.logo-area h1 {
  font-size: 3rem; font-weight: 800; letter-spacing: -0.02em;
  color: #e2e8f0;
}
.logo-area .subtitle {
  font-size: 0.85rem; color: #64748b; letter-spacing: 0.02em;
}
.mode-buttons {
  display: flex;
  gap: 1.5rem;
  flex-wrap: wrap;
  justify-content: center;
}
.mode-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  padding: 1.5rem 2rem;
  border-radius: 12px;
  border: 1px solid rgba(148,163,184,0.15);
  background: rgba(15,23,42,0.6);
  backdrop-filter: blur(8px);
  cursor: pointer;
  transition: all 0.2s ease;
  min-width: 160px;
  position: relative;
}
.mode-btn:hover {
  border-color: rgba(96,165,250,0.4);
  background: rgba(30,41,59,0.7);
  transform: translateY(-2px);
}
.mode-btn .icon {
  font-size: 2rem;
}
.mode-btn .label {
  font-size: 1rem; font-weight: 600; color: #e2e8f0;
}
/* Tooltip */
.mode-btn .tooltip {
  position: absolute;
  top: calc(100% + 10px);
  left: 50%;
  transform: translateX(-50%) translateY(-4px);
  background: rgba(15, 23, 42, 0.95);
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 8px;
  padding: 10px 14px;
  font-size: 12px;
  color: #94a3b8;
  line-height: 1.5;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: all 0.2s ease;
  z-index: 10;
}
.mode-btn:hover .tooltip {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>
<div class="welcome">
  <div class="logo-area">
    <h1>LumiSlate</h1>
    <div class="subtitle">\u9009\u62E9 Markdown \u7B14\u8BB0\uFF0C\u5F00\u59CB\u7F16\u8BD1\u9AD8\u5B9A\u753B\u5E03</div>
  </div>
  <div class="mode-buttons">
    <div class="mode-btn" data-mode="custom" onclick="selectMode('custom')">
      <div class="tooltip">\u5C06 Markdown \u8F6C\u6362\u4E3A\u5E7B\u706F\u7247 / \u957F\u6587\u753B\u5E03<br>\u652F\u6301\u81EA\u5B9A\u4E49 CSS \u4E0E\u5B9E\u65F6\u9884\u89C8</div>
      <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg></div>
      <div class="label">\u81EA\u5B9A\u4E49\u6A21\u5F0F</div>
    </div>
    <div class="mode-btn" data-mode="design" onclick="selectMode('design')">
      <div class="tooltip">\u9009\u62E9\u8BBE\u8BA1\u98CE\u683C\uFF0C\u7531 AI \u81EA\u52A8\u751F\u6210\u7CBE\u7F8E HTML \u9875\u9762<br>\u652F\u6301\u591A\u79CD\u6392\u7248\u6A21\u677F\u4E0E\u5B9E\u65F6\u7F16\u8F91<br><span style="color:#f59e0b">\u9996\u6B21\u4F7F\u7528\u9700\u8981\u8FDB\u5165\u8BBE\u7F6E\u914D\u7F6EAI\u529F\u80FD</span></div>
      <div class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3z"/></svg></div>
      <div class="label">AI\u6A21\u5F0F</div>
    </div>
  </div>
</div>
<script>
function selectMode(mode) {
  window.parent.postMessage({ type: 'lumislate-select-mode', mode: mode }, '*');
}
</script>
</body>
</html>`}function ta(i){let a=document.createElement("div");return(0,y.setIcon)(a,i),a.innerHTML||""}function Re(i,a){let e={article:"\u6587\u7AE0",prototype:"\u539F\u578B",doc:"\u6587\u6863",email:"\u90AE\u4EF6",data:"\u6570\u636E",finance:"\u8D22\u52A1",dashboard:"\u770B\u677F",video:"\u89C6\u9891",poster:"\u6D77\u62A5",card:"\u5361\u7247",mobile:"\u79FB\u52A8\u7AEF",general:"\u901A\u7528"},t=new Map;for(let r of i){let l=r.category||"general";t.has(l)||t.set(l,[]),t.get(l).push(r)}let n=Array.from(t.keys()).sort(),o=n.map(r=>{let l=e[r]||r,c=t.get(r).length;return`<button class="skill-category-tab" data-category="${r}">${l}<span class="skill-tab-count">${c}</span></button>`}).join(""),s=n.map(r=>{let l=t.get(r),c=e[r]||r,d=l.map((m,b)=>{let h=m.id===a,p=ta(m.icon),f=b>=3?"skill-card-hidden":"";return`
				<div class="skill-card ${h?"active":""} ${f}" data-skill-id="${m.id}" data-category="${r}">
					<div class="skill-card-icon">${p}</div>
					<div class="skill-card-name">${m.name}</div>
					<div class="skill-card-desc">${m.description}</div>
					<div class="skill-card-badge">${c}</div>
				</div>
			`}).join(""),g=l.length>3?`<button class="skill-expand-btn" data-category="${r}">\u5C55\u5F00\u66F4\u591A (${l.length-3})</button>`:"";return`
			<div class="skill-category-section" data-category="${r}">
				<div class="skill-category-header">
					<div class="skill-category-header-left">
						<span class="skill-category-title">${c}</span>
						<span class="skill-category-count">${l.length}</span>
					</div>
					<button class="skill-category-toggle" data-category="${r}" aria-label="\u6298\u53E0/\u5C55\u5F00">
						<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>
					</button>
				</div>
				<div class="skill-grid skill-grid-collapsible">
					${d}
				</div>
				${g}
			</div>
		`}).join("");return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 100%; height: 100%; }
body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%);
  color: #e2e8f0;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 24px;
  min-height: 100vh;
}
.launcher {
  width: 100%;
  max-width: 720px;
  animation: fadeIn 0.5s ease-out;
}
.launcher-header {
  text-align: center;
  margin-bottom: 20px;
}
.launcher-header h1 {
  font-size: 1.6rem;
  font-weight: 700;
  color: #e2e8f0;
  margin-bottom: 6px;
}
.launcher-header p {
  font-size: 0.9rem;
  color: #94a3b8;
}
.skill-search-wrap {
  margin-bottom: 14px;
}
.skill-search-input {
  width: 100%;
  padding: 10px 14px;
  border-radius: 8px;
  border: 1px solid rgba(148, 163, 184, 0.2);
  background: rgba(15, 23, 42, 0.6);
  color: #e2e8f0;
  font-size: 14px;
  outline: none;
  transition: all 0.15s ease;
}
.skill-search-input::placeholder {
  color: #64748b;
}
.skill-search-input:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.15);
}
.skill-category-tabs {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  overflow-x: auto;
  padding-bottom: 4px;
  scrollbar-width: thin;
  scrollbar-color: rgba(148,163,184,0.3) transparent;
}
.skill-category-tabs::-webkit-scrollbar {
  height: 4px;
}
.skill-category-tabs::-webkit-scrollbar-thumb {
  background: rgba(148,163,184,0.3);
  border-radius: 2px;
}
.skill-category-tab {
  flex-shrink: 0;
  padding: 6px 14px;
  border-radius: 20px;
  border: 1px solid rgba(148, 163, 184, 0.2);
  background: rgba(15, 23, 42, 0.5);
  color: #94a3b8;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.15s ease;
  display: flex;
  align-items: center;
  gap: 6px;
}
.skill-category-tab:hover {
  border-color: rgba(99, 102, 241, 0.4);
  color: #c7d2fe;
}
.skill-category-tab.active {
  border-color: #6366f1;
  background: rgba(99, 102, 241, 0.15);
  color: #c7d2fe;
}
.skill-tab-count {
  font-size: 11px;
  padding: 1px 6px;
  border-radius: 10px;
  background: rgba(148, 163, 184, 0.15);
  color: #64748b;
}
.skill-category-tab.active .skill-tab-count {
  background: rgba(99, 102, 241, 0.2);
  color: #818cf8;
}
.skill-content {
  max-height: calc(100vh - 260px);
  overflow-y: auto;
  padding-right: 4px;
  scrollbar-width: thin;
  scrollbar-color: rgba(148,163,184,0.3) transparent;
}
.skill-content::-webkit-scrollbar {
  width: 4px;
}
.skill-content::-webkit-scrollbar-thumb {
  background: rgba(148,163,184,0.3);
  border-radius: 2px;
}
.skill-category-section {
  margin-bottom: 16px;
}
.skill-category-section.collapsed .skill-grid-collapsible,
.skill-category-section.collapsed .skill-expand-btn {
  display: none;
}
.skill-category-section.collapsed .skill-category-toggle svg {
  transform: rotate(180deg);
}
.skill-category-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 10px;
  margin-bottom: 10px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s ease;
  user-select: none;
}
.skill-category-header:hover {
  background: rgba(148, 163, 184, 0.08);
}
.skill-category-header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}
.skill-category-title {
  font-size: 14px;
  font-weight: 600;
  color: #e2e8f0;
}
.skill-category-count {
  font-size: 11px;
  padding: 1px 7px;
  border-radius: 10px;
  background: rgba(148, 163, 184, 0.12);
  color: #64748b;
}
.skill-category-toggle {
  background: none;
  border: none;
  color: #64748b;
  cursor: pointer;
  padding: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  transition: all 0.15s ease;
}
.skill-category-toggle:hover {
  background: rgba(148, 163, 184, 0.12);
  color: #94a3b8;
}
.skill-category-toggle svg {
  transition: transform 0.2s ease;
}
.skill-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 12px;
}
.skill-card {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 16px;
  border-radius: 10px;
  border: 1px solid rgba(148, 163, 184, 0.15);
  background: rgba(15, 23, 42, 0.6);
  backdrop-filter: blur(8px);
  cursor: pointer;
  transition: all 0.15s ease;
}
.skill-card:hover {
  border-color: #6366f1;
  box-shadow: 0 2px 12px rgba(99, 102, 241, 0.2);
  transform: translateY(-2px);
}
.skill-card.active {
  border-color: #6366f1;
  background: rgba(99, 102, 241, 0.1);
  box-shadow: 0 0 0 1px #6366f1, 0 2px 12px rgba(99, 102, 241, 0.15);
}
.skill-card.skill-card-hidden {
  display: none;
}
.skill-card-icon {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  background: rgba(30, 41, 59, 0.8);
  color: #818cf8;
  margin-bottom: 4px;
}
.skill-card-icon svg {
  width: 20px;
  height: 20px;
  stroke-width: 2;
}
.skill-card-name {
  font-size: 14px;
  font-weight: 600;
  color: #e2e8f0;
}
.skill-card-desc {
  font-size: 12px;
  color: #94a3b8;
  line-height: 1.45;
  flex: 1;
}
.skill-card-badge {
  align-self: flex-start;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  background: rgba(30, 41, 59, 0.8);
  color: #64748b;
}
.skill-expand-btn {
  width: 100%;
  margin-top: 10px;
  padding: 8px;
  border-radius: 8px;
  border: 1px dashed rgba(148, 163, 184, 0.25);
  background: rgba(15, 23, 42, 0.3);
  color: #94a3b8;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.15s ease;
}
.skill-expand-btn:hover {
  border-color: #6366f1;
  color: #c7d2fe;
  background: rgba(99, 102, 241, 0.08);
}
.skill-empty-state {
  text-align: center;
  padding: 48px 24px;
}
.skill-empty-icon {
  margin-bottom: 12px;
  opacity: 0.6;
}
.skill-empty-title {
  font-size: 15px;
  font-weight: 600;
  color: #e2e8f0;
  margin-bottom: 6px;
}
.skill-empty-desc {
  font-size: 13px;
  color: #64748b;
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to   { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>
<div class="launcher">
  <div class="launcher-header">
    <h1>\u9009\u62E9\u8BBE\u8BA1\u6837\u5F0F</h1>
    <p>\u70B9\u51FB\u5361\u7247\u9009\u62E9\u6A21\u677F\uFF0CAI \u5C06\u7ACB\u5373\u5F00\u59CB\u6E32\u67D3</p>
  </div>
  <div class="skill-search-wrap">
    <input type="text" class="skill-search-input" placeholder="\u641C\u7D22\u6837\u5F0F\u540D\u79F0\u6216\u63CF\u8FF0..." />
  </div>
  <div class="skill-category-tabs">
    <button class="skill-category-tab active" data-category="all">\u5168\u90E8<span class="skill-tab-count">${i.length}</span></button>
    ${o}
  </div>
  <div class="skill-content">
    ${s}
    <div class="skill-empty-state" style="display:none;">
      <div class="skill-empty-icon">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color:#475569;"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path><line x1="11" y1="8" x2="11" y2="11"></line><line x1="11" y1="11" x2="14" y2="11"></line></svg>
      </div>
      <div class="skill-empty-title">\u672A\u627E\u5230\u5339\u914D\u7684\u6837\u5F0F</div>
      <div class="skill-empty-desc">\u5C1D\u8BD5\u4F7F\u7528\u5176\u4ED6\u5173\u952E\u8BCD\u641C\u7D22</div>
    </div>
  </div>
</div>
<script>
(function() {
  var searchInput = document.querySelector('.skill-search-input');
  var tabs = document.querySelectorAll('.skill-category-tab');
  var sections = document.querySelectorAll('.skill-category-section');
  var emptyState = document.querySelector('.skill-empty-state');

  function resetToDefault() {
    emptyState.style.display = 'none';
    sections.forEach(function(sec) {
      sec.style.display = '';
      sec.classList.remove('collapsed');
      var cards = sec.querySelectorAll('.skill-card');
      cards.forEach(function(card, idx) {
        card.style.display = '';
        if (idx >= 3) {
          card.classList.add('skill-card-hidden');
        } else {
          card.classList.remove('skill-card-hidden');
        }
      });
      var expandBtn = sec.querySelector('.skill-expand-btn');
      if (expandBtn) {
        var total = cards.length;
        expandBtn.style.display = total > 3 ? '' : 'none';
        expandBtn.textContent = '\u5C55\u5F00\u66F4\u591A (' + (total - 3) + ')';
      }
    });
  }

  function updateEmptyState() {
    var anyVisible = false;
    sections.forEach(function(sec) {
      if (sec.style.display !== 'none') anyVisible = true;
    });
    emptyState.style.display = anyVisible ? 'none' : '';
  }

  // \u641C\u7D22\u8FC7\u6EE4
  searchInput.addEventListener('input', function() {
    var query = this.value.trim().toLowerCase();
    if (!query) {
      resetToDefault();
      return;
    }

    sections.forEach(function(sec) {
      var cards = sec.querySelectorAll('.skill-card');
      var sectionVisible = false;
      cards.forEach(function(card) {
        var name = card.querySelector('.skill-card-name').textContent.toLowerCase();
        var desc = card.querySelector('.skill-card-desc').textContent.toLowerCase();
        var match = name.indexOf(query) !== -1 || desc.indexOf(query) !== -1;
        card.style.display = match ? '' : 'none';
        if (match) {
          card.classList.remove('skill-card-hidden');
          sectionVisible = true;
        }
      });
      sec.style.display = sectionVisible ? '' : 'none';
      var expandBtn = sec.querySelector('.skill-expand-btn');
      if (expandBtn) expandBtn.style.display = 'none';
      sec.classList.remove('collapsed');
    });
    updateEmptyState();
  });

  // \u5206\u7C7B\u6807\u7B7E\u5207\u6362
  tabs.forEach(function(tab) {
    tab.addEventListener('click', function() {
      var cat = this.dataset.category;
      tabs.forEach(function(t) { t.classList.remove('active'); });
      this.classList.add('active');

      searchInput.value = '';
      resetToDefault();

      if (cat !== 'all') {
        sections.forEach(function(sec) {
          sec.style.display = sec.dataset.category === cat ? '' : 'none';
        });
      }
    });
  });

  // \u5206\u7C7B\u6298\u53E0/\u5C55\u5F00
  document.querySelectorAll('.skill-category-header').forEach(function(header) {
    header.addEventListener('click', function() {
      var section = this.closest('.skill-category-section');
      section.classList.toggle('collapsed');
    });
  });

  document.querySelectorAll('.skill-category-toggle').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      var section = this.closest('.skill-category-section');
      section.classList.toggle('collapsed');
    });
  });

  // \u5C55\u5F00\u66F4\u591A
  document.querySelectorAll('.skill-expand-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var cat = this.dataset.category;
      var section = document.querySelector('.skill-category-section[data-category="' + cat + '"]');
      if (!section) return;
      var hiddenCards = section.querySelectorAll('.skill-card-hidden');
      hiddenCards.forEach(function(card) {
        card.classList.remove('skill-card-hidden');
      });
      this.style.display = 'none';
    });
  });

  // \u5361\u7247\u70B9\u51FB
  document.querySelectorAll('.skill-card').forEach(function(card) {
    card.addEventListener('click', function() {
      var skillId = this.dataset.skillId;
      if (skillId && window.parent !== window) {
        window.parent.postMessage({ type: 'lumislate-skill-select', skillId: skillId }, '*');
      }
    });
  });
})();
</script>
</body>
</html>`}function ia(){return`<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 100%; height: 100%; overflow: hidden; }
body {
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%);
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  color: #e2e8f0;
}
.guide {
  text-align: center;
  animation: fadeIn 0.6s ease-out;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
  max-width: 480px;
  padding: 2rem;
}
.guide h1 {
  font-size: 1.5rem; font-weight: 700; color: #e2e8f0;
}
.guide p {
  font-size: 0.85rem; color: #94a3b8; line-height: 1.6;
}
.guide-steps {
  display: flex;
  flex-direction: column;
  gap: 12px;
  width: 100%;
  text-align: left;
}
.step {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 12px 16px;
  border-radius: 8px;
  background: rgba(15, 23, 42, 0.6);
  border: 1px solid rgba(148, 163, 184, 0.15);
}
.step-num {
  width: 24px; height: 24px;
  display: flex; align-items: center; justify-content: center;
  border-radius: 50%;
  background: rgba(99, 102, 241, 0.2);
  color: #818cf8;
  font-size: 12px; font-weight: 700;
  flex-shrink: 0;
}
.step-body {
  font-size: 13px; color: #cbd5e1; line-height: 1.5;
}
.step-body strong {
  color: #e2e8f0; font-weight: 600;
}
.guide-btn {
  margin-top: 0.5rem;
  padding: 10px 24px;
  border-radius: 8px;
  border: 1px solid rgba(99, 102, 241, 0.4);
  background: rgba(99, 102, 241, 0.12);
  color: #c7d2fe;
  font-size: 14px; font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
}
.guide-btn:hover {
  background: rgba(99, 102, 241, 0.2);
  border-color: rgba(99, 102, 241, 0.6);
}
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>
<div class="guide">
  <h1>\u{1F916} \u5F53\u524D\u65E0\u53EF\u7528AI</h1>
  <p>AI \u6A21\u5F0F\u9700\u8981\u914D\u7F6E\u672C\u5730 CLI Agent \u6216\u5728\u7EBF API \u624D\u80FD\u751F\u6210\u7CBE\u7F8E\u6392\u7248\u3002\u8BF7\u6309\u4EE5\u4E0B\u6B65\u9AA4\u5B8C\u6210\u914D\u7F6E\uFF1A</p>
  <div class="guide-steps">
    <div class="step">
      <div class="step-num">1</div>
      <div class="step-body"><strong>\u672C\u5730\u63A5\u5165</strong>\uFF1A\u5B89\u88C5 claude / codex / gemini \u7B49 CLI \u5DE5\u5177\u5E76\u786E\u4FDD\u5728 PATH \u4E2D\u53EF\u7528</div>
    </div>
    <div class="step">
      <div class="step-num">2</div>
      <div class="step-body"><strong>\u5728\u7EBF API</strong>\uFF1A\u5728\u8BBE\u7F6E\u4E2D\u586B\u5165 API Key \u548C Base URL\uFF08\u652F\u6301 Kimi\u3001DeepSeek\u3001OpenRouter \u7B49\uFF09</div>
    </div>
    <div class="step">
      <div class="step-num">3</div>
      <div class="step-body"><strong>\u6D4B\u8BD5\u8FDE\u63A5</strong>\uFF1A\u914D\u7F6E\u5B8C\u6210\u540E\u70B9\u51FB\u300CAI \u63A5\u5165\u300D\u6309\u94AE\u68C0\u67E5\u72B6\u6001</div>
    </div>
  </div>
  <button class="guide-btn" onclick="openSettings()">\u6253\u5F00\u8BBE\u7F6E</button>
</div>
<script>
function openSettings() {
  window.parent.postMessage({ type: 'lumislate-open-settings' }, '*');
}
</script>
</body>
</html>`}function na(){return`<script>
(function() {
  'use strict';

  // \u6CE8\u5165 I \u578B\u95EA\u70C1\u5149\u6807\u6837\u5F0F
  var cursorStyle = document.createElement('style');
  cursorStyle.textContent =
    '.lumislate-cursor{' +
    'display:inline-block;width:2px;height:1.1em;' +
    'background-color:currentColor;vertical-align:text-bottom;margin-left:1px;' +
    'animation:lumislate-blink 1.1s step-end infinite' +
    '}' +
    '@keyframes lumislate-blink{' +
    '0%,100%{opacity:1}' +
    '50%{opacity:0}' +
    '}';
  document.head.appendChild(cursorStyle);

  var EDITABLE_TAGS = ['P','H1','H2','H3','H4','H5','H6','LI','SPAN','STRONG','EM','TD','TH','A','BLOCKQUOTE'];
  var HOVER_CLASS = 'lumislate-hover';
  var EDIT_CLASS  = 'lumislate-editing';
  var currentEdit = null;

  function getTextNodeAtPoint(x, y) {
    if (document.caretPositionFromPoint) {
      var pos = document.caretPositionFromPoint(x, y);
      return pos ? pos.offsetNode : null;
    }
    if (document.caretRangeFromPoint) {
      var range = document.caretRangeFromPoint(x, y);
      return range ? range.startContainer : null;
    }
    return null;
  }

  function isEditableElement(el) {
    if (!el || el.nodeType !== 1) return false;
    if (el.isContentEditable) return false;
    return EDITABLE_TAGS.indexOf(el.tagName) !== -1;
  }

  function getPath(el) {
    var path = [];
    while (el && el !== document.body) {
      var parent = el.parentElement;
      if (!parent) break;
      var siblings = Array.from(parent.children);
      var idx = siblings.indexOf(el);
      path.unshift(el.tagName.toLowerCase() + '[' + idx + ']');
      el = parent;
    }
    return path.join('>');
  }

  function getContext(el) {
    return (el.textContent || '').slice(0, 80);
  }

  function clearHover() {
    document.querySelectorAll('.' + HOVER_CLASS).forEach(function(e) {
      e.classList.remove(HOVER_CLASS);
    });
  }

  function setHover(el) {
    clearHover();
    if (el) el.classList.add(HOVER_CLASS);
  }

  function startEdit(textNode, parent) {
    if (currentEdit) finishEdit();

    currentEdit = {
      parent: parent,
      textNode: textNode,
      oldText: textNode.textContent,
      path: getPath(parent)
    };

    var span = document.createElement('span');
    span.contentEditable = 'true';
    span.className = EDIT_CLASS;
    span.textContent = textNode.textContent;

    parent.replaceChild(span, textNode);
    span.focus();

    var sel = window.getSelection();
    var range = document.createRange();
    range.selectNodeContents(span);
    sel.removeAllRanges();
    sel.addRange(range);
  }

  function finishEdit() {
    if (!currentEdit) return;

    var edit = currentEdit;
    var span = edit.parent.querySelector('.' + EDIT_CLASS);
    if (!span) { currentEdit = null; return; }

    var newText = span.textContent;
    var newNode = document.createTextNode(newText);
    edit.parent.replaceChild(newNode, span);
    clearHover();

    if (newText !== edit.oldText) {
      window.parent.postMessage({
        type: 'lumislate-text-change',
        oldText: edit.oldText,
        newText: newText,
        tagName: edit.parent.tagName,
        path: edit.path,
        context: getContext(edit.parent)
      }, '*');
    }

    currentEdit = null;
  }

  function cancelEdit() {
    if (!currentEdit) return;

    var edit = currentEdit;
    var span = edit.parent.querySelector('.' + EDIT_CLASS);
    if (span) {
      var newNode = document.createTextNode(edit.oldText);
      edit.parent.replaceChild(newNode, span);
    }
    clearHover();
    currentEdit = null;
  }

  document.body.addEventListener('mousemove', function(e) {
    if (currentEdit) return;

    var node = getTextNodeAtPoint(e.clientX, e.clientY);
    if (!node) { clearHover(); return; }

    var parent = node.nodeType === 3 ? node.parentElement : node;
    if (!parent || !isEditableElement(parent)) { clearHover(); return; }

    setHover(parent);
  });

  document.body.addEventListener('click', function(e) {
    if (currentEdit) {
      if (!currentEdit.parent.contains(e.target)) {
        finishEdit();
      }
      return;
    }

    var node = getTextNodeAtPoint(e.clientX, e.clientY);
    if (!node || node.nodeType !== 3) return;

    var parent = node.parentElement;
    if (!parent || !isEditableElement(parent)) return;

    startEdit(node, parent);
  });

  document.addEventListener('keydown', function(e) {
    if (!currentEdit) return;

    if (e.key === 'Enter') {
      e.preventDefault();
      finishEdit();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      cancelEdit();
    }
  });

  // Slide tracking \u2014 \u70B9\u51FB slide \u901A\u77E5\u7236\u7A97\u53E3\u9009\u4E2D\u8BE5\u9875\uFF0C\u540C\u65F6\u63A5\u6536\u7236\u7A97\u53E3\u6EDA\u52A8\u6307\u4EE4
  var slides = document.querySelectorAll('section.slide, section[data-layout]');
  var selectedIdx = 0;

  function updateSelection(idx) {
    selectedIdx = idx;
    if (slides.length === 0) return;
    slides.forEach(function(s, i) {
      s.style.outline = (i === idx) ? '2px solid #3b82f6' : 'none';
      s.style.outlineOffset = (i === idx) ? '-2px' : '0';
    });
  }

  function scrollToSlide(idx) {
    if (slides.length === 0) return;
    var target = slides[idx];
    if (!target) return;
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    updateSelection(idx);
    placeCursorInSlide(target);
  }

  function placeCursorInSlide(slide) {
    // \u79FB\u9664\u4E4B\u524D\u7684\u5149\u6807
    var oldCursor = document.querySelector('.lumislate-cursor');
    if (oldCursor) oldCursor.remove();

    // \u627E\u5230 slide \u5185\u7B2C\u4E00\u4E2A\u6709\u6587\u672C\u5185\u5BB9\u7684\u53EF\u7F16\u8F91\u5143\u7D20
    var editableTags = ['P','H1','H2','H3','H4','H5','H6','LI','SPAN','STRONG','EM','TD','TH','BLOCKQUOTE'];
    var elements = slide.querySelectorAll(editableTags.join(','));
    for (var i = 0; i < elements.length; i++) {
      var el = elements[i];
      if (el.textContent.trim()) {
        var cursor = document.createElement('span');
        cursor.className = 'lumislate-cursor';
        cursor.setAttribute('aria-hidden', 'true');
        el.appendChild(cursor);
        return;
      }
    }
  }

  if (slides.length > 0) {
    slides.forEach(function(s, i) {
      s.style.cursor = 'pointer';
      s.addEventListener('click', function(e) {
        // \u5982\u679C\u70B9\u51FB\u7684\u662F\u53EF\u7F16\u8F91\u5143\u7D20\u6216\u4EA4\u4E92\u5143\u7D20\uFF0C\u4E0D\u89E6\u53D1\u9009\u9875
        var tag = e.target.tagName;
        if (['INPUT','TEXTAREA','SELECT','A','BUTTON'].indexOf(tag) !== -1) return;
        updateSelection(i);
        window.parent.postMessage({
          type: 'lumislate-slide-click',
          index: i
        }, '*');
      });
    });
    // \u9ED8\u8BA4\u9009\u4E2D\u7B2C\u4E00\u9875
    updateSelection(0);
  }

  // \u63A5\u6536\u7236\u7A97\u53E3\u6EDA\u52A8\u6307\u4EE4
  window.addEventListener('message', function(event) {
    if (event.data && event.data.type === 'lumislate-scroll-to-slide') {
      var idx = event.data.index;
      if (typeof idx === 'number' && idx >= 0) {
        scrollToSlide(idx);
      }
    }
  });
})();
</script>`}function aa(){return`<script>
(function() {
	'use strict';

	var activeImage = null;
	var handlesContainer = null;
	var dragOverlay = null;
	var isDragging = false;
	var isResizing = false;
	var dragStart = { x: 0, y: 0, tx: 0, ty: 0 };
	var resizeStart = { x: 0, y: 0, w: 0, h: 0, handle: '' };

	function getTransformValues(el) {
		var style = window.getComputedStyle(el).transform;
		if (style === 'none') return { x: 0, y: 0 };
		var m = style.match(/matrix(([^,]+),[^,]+,[^,]+,[^,]+, *([^,]+), *([^)]+))/);
		if (m) return { x: parseFloat(m[2]) || 0, y: parseFloat(m[3]) || 0 };
		return { x: 0, y: 0 };
	}

	/** \u83B7\u53D6\u56FE\u7247\u7684\u7EA6\u675F\u5BB9\u5668\uFF08slide \u6216\u9875\u9762\u4E3B\u4F53\uFF09 */
	function getConstraintContainer(img) {
		return img.closest('section.slide') || img.closest('.slide') || img.closest('#longform-content') || img.closest('section') || document.body;
	}

	/** \u9650\u5236\u62D6\u62FD translate \u503C\uFF0C\u4F7F\u56FE\u7247\u81F3\u5C11\u4FDD\u7559 minVis \u50CF\u7D20\u5728\u5BB9\u5668\u5185 */
	function constrainTranslate(img, tx, ty) {
		var container = getConstraintContainer(img);
		var cRect = container.getBoundingClientRect();
		var iRect = img.getBoundingClientRect();
		var cur = getTransformValues(img);
		// \u56FE\u7247\u539F\u59CB\u4F4D\u7F6E\uFF08\u4E0D\u542B\u5F53\u524D transform\uFF09
		var rawLeft = iRect.left - cur.x;
		var rawTop = iRect.top - cur.y;
		var minVis = 40;
		var maxTx = cRect.right - minVis - rawLeft;
		var minTx = cRect.left + minVis - rawLeft - iRect.width;
		var maxTy = cRect.bottom - minVis - rawTop;
		var minTy = cRect.top + minVis - rawTop - iRect.height;
		return {
			x: Math.max(minTx, Math.min(maxTx, tx)),
			y: Math.max(minTy, Math.min(maxTy, ty))
		};
	}

	/** \u9650\u5236 resize \u5C3A\u5BF8\uFF08\u5F3A\u5236\u4FDD\u6301\u6BD4\u4F8B\uFF09\uFF0C\u4E0D\u8D85\u8FC7\u5BB9\u5668\u8FB9\u754C */
	function constrainResize(img, w, h, aspect) {
		var container = getConstraintContainer(img);
		var cRect = container.getBoundingClientRect();
		var minSize = 40;
		var maxW = Math.round(cRect.width);
		var maxH = Math.round(cRect.height);

		// \u9650\u5236\u6700\u5C0F\u5C3A\u5BF8
		if (w < minSize) { w = minSize; h = w / aspect; }
		if (h < minSize) { h = minSize; w = h * aspect; }
		// \u9650\u5236\u6700\u5927\u5C3A\u5BF8
		if (w > maxW) { w = maxW; h = w / aspect; }
		if (h > maxH) { h = maxH; w = h * aspect; }
		// \u9650\u5236\u540E\u53EF\u80FD\u518D\u6B21\u8D85\u51FA\u6700\u5C0F\uFF0C\u91CD\u65B0\u515C\u5E95
		if (w < minSize) { w = minSize; h = w / aspect; }
		if (h < minSize) { h = minSize; w = h * aspect; }

		return { w: w, h: h };
	}

	/** \u5224\u65AD\u70B9 (x,y) \u662F\u5426\u5728\u5143\u7D20 el \u7684 bounding rect \u5185\uFF08\u542B 10px \u8FB9\u7F18\u5BB9\u9519\uFF09 */
	function isPointInEl(x, y, el) {
		if (!el) return false;
		var r = el.getBoundingClientRect();
		var tolerance = 10;
		return x >= r.left - tolerance && x <= r.right + tolerance &&
		       y >= r.top - tolerance && y <= r.bottom + tolerance;
	}

	function createDragOverlay() {
		if (dragOverlay) return;
		dragOverlay = document.createElement('div');
		dragOverlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:9998;cursor:grabbing;display:none;';
		document.body.appendChild(dragOverlay);
	}

	function createHandles() {
		if (handlesContainer) return;
		handlesContainer = document.createElement('div');
		handlesContainer.className = 'lumislate-img-handles';
		var positions = ['nw','n','ne','e','se','s','sw','w'];
		var cursors = {
			nw: 'nw-resize', n: 'ns-resize', ne: 'ne-resize',
			e: 'ew-resize', se: 'se-resize', s: 'ns-resize',
			sw: 'sw-resize', w: 'ew-resize'
		};
		positions.forEach(function(pos) {
			var h = document.createElement('div');
			h.className = 'lumislate-handle lumislate-handle-' + pos;
			h.dataset.handle = pos;
			var size = 14;
			var half = size / 2;
			var base = 'position:absolute;width:'+size+'px;height:'+size+'px;background:#3b82f6;border:2px solid #fff;border-radius:50%;pointer-events:auto;cursor:'+cursors[pos]+';box-shadow:0 1px 4px rgba(0,0,0,0.4);transition:transform 0.1s,background 0.1s;';
			switch(pos) {
				case 'nw': h.style.cssText = base + 'top:-'+half+'px;left:-'+half+'px;'; break;
				case 'n':  h.style.cssText = base + 'top:-'+half+'px;left:50%;transform:translateX(-50%);'; break;
				case 'ne': h.style.cssText = base + 'top:-'+half+'px;right:-'+half+'px;'; break;
				case 'e':  h.style.cssText = base + 'top:50%;right:-'+half+'px;transform:translateY(-50%);'; break;
				case 'se': h.style.cssText = base + 'bottom:-'+half+'px;right:-'+half+'px;'; break;
				case 's':  h.style.cssText = base + 'bottom:-'+half+'px;left:50%;transform:translateX(-50%);'; break;
				case 'sw': h.style.cssText = base + 'bottom:-'+half+'px;left:-'+half+'px;'; break;
				case 'w':  h.style.cssText = base + 'top:50%;left:-'+half+'px;transform:translateY(-50%);'; break;
			}
			handlesContainer.appendChild(h);
		});
		document.body.appendChild(handlesContainer);
	}

	function updateHandlesPosition() {
		if (!activeImage || !handlesContainer) return;
		var rect = activeImage.getBoundingClientRect();
		handlesContainer.style.left = rect.left + 'px';
		handlesContainer.style.top = rect.top + 'px';
		handlesContainer.style.width = rect.width + 'px';
		handlesContainer.style.height = rect.height + 'px';
		handlesContainer.style.display = 'block';
	}

	function activateImage(img) {
		if (activeImage === img) return;
		deactivateImage();
		activeImage = img;
		img.classList.remove('lumislate-img-hover');
		img.classList.add('lumislate-img-active');

		var computedPos = window.getComputedStyle(img).position;
		if (computedPos === 'static') {
			img.style.position = 'relative';
		}

		createHandles();
		createDragOverlay();
		updateHandlesPosition();
	}

	function deactivateImage() {
		if (!activeImage) return;
		activeImage.classList.remove('lumislate-img-active');
		activeImage.classList.remove('lumislate-img-hover');
		activeImage = null;
		if (handlesContainer) handlesContainer.style.display = 'none';
		if (dragOverlay) dragOverlay.style.display = 'none';
		isDragging = false;
		isResizing = false;
	}

	// \u6CE8\u5165\u6837\u5F0F
	var style = document.createElement('style');
	style.textContent = '.lumislate-img-hover{outline:2px dashed #3b82f6;outline-offset:2px;cursor:grab;} .lumislate-img-active{outline:2px solid #3b82f6;outline-offset:2px;cursor:grab;} .lumislate-img-handles{position:fixed;z-index:9999;display:none;pointer-events:none;} .lumislate-handle:hover{background:#60a5fa;transform:scale(1.2);}';
	document.head.appendChild(style);

	// mouseover: \u7ED9\u56FE\u7247\u6DFB\u52A0 hover \u6548\u679C
	document.body.addEventListener('mouseover', function(e) {
		if (isDragging || isResizing) return;
		var img = e.target.closest('img');
		if (img && img !== activeImage) {
			img.classList.add('lumislate-img-hover');
		}
	}, true);

	document.body.addEventListener('mouseout', function(e) {
		var img = e.target.closest('img');
		if (img && img !== activeImage) {
			img.classList.remove('lumislate-img-hover');
		}
	}, true);

	// click: \u6FC0\u6D3B/\u53D6\u6D88\u56FE\u7247\u7F16\u8F91
	document.body.addEventListener('click', function(e) {
		var handle = e.target.closest('.lumislate-handle');
		if (handle) {
			e.stopPropagation();
			return;
		}

		var img = e.target.closest('img');
		if (img) {
			e.stopPropagation();
			e.preventDefault();
			activateImage(img);
			return;
		}

		// \u70B9\u51FB\u7A7A\u767D\u5904\uFF08\u4E14\u4E0D\u5728 activeImage \u8303\u56F4\u5185\uFF09\u5219\u9000\u51FA
		if (!isPointInEl(e.clientX, e.clientY, activeImage)) {
			deactivateImage();
		}
	}, true);

	// mousedown: \u5F00\u59CB\u62D6\u62FD\u6216\u8C03\u6574\u5927\u5C0F
	document.body.addEventListener('mousedown', function(e) {
		// \u4F18\u5148\u68C0\u6D4B\u624B\u67C4\uFF08resize\uFF09
		var handle = e.target.closest('.lumislate-handle');
		if (handle && activeImage) {
			isResizing = true;
			resizeStart = {
				x: e.clientX, y: e.clientY,
				w: activeImage.offsetWidth,
				h: activeImage.offsetHeight,
				handle: handle.dataset.handle
			};
			e.preventDefault();
			e.stopPropagation();
			return;
		}

		// \u68C0\u6D4B\u662F\u5426\u5728 activeImage \u533A\u57DF\u5185\uFF08\u652F\u6301 pointer-events \u7A7F\u900F\u573A\u666F\uFF09
		if (activeImage && isPointInEl(e.clientX, e.clientY, activeImage)) {
			isDragging = true;
			var tv = getTransformValues(activeImage);
			dragStart = { x: e.clientX, y: e.clientY, tx: tv.x, ty: tv.y };
			activeImage.style.cursor = 'grabbing';
			if (dragOverlay) dragOverlay.style.display = 'block';
			e.preventDefault();
			e.stopPropagation();
			return;
		}

		// \u70B9\u51FB\u975E activeImage \u533A\u57DF\uFF0C\u53D6\u6D88\u6FC0\u6D3B
		if (activeImage && !isPointInEl(e.clientX, e.clientY, activeImage)) {
			deactivateImage();
		}
	}, true);

	// mousemove: \u62D6\u62FD\u6216\u8C03\u6574\u5927\u5C0F\u4E2D
	document.body.addEventListener('mousemove', function(e) {
		if (isDragging && activeImage) {
			var dx = e.clientX - dragStart.x;
			var dy = e.clientY - dragStart.y;
			var rawTx = dragStart.tx + dx;
			var rawTy = dragStart.ty + dy;
			var constrained = constrainTranslate(activeImage, rawTx, rawTy);
			activeImage.style.transform = 'translate(' + constrained.x + 'px, ' + constrained.y + 'px)';
			updateHandlesPosition();
			return;
		}

		if (isResizing && activeImage) {
			var dx = e.clientX - resizeStart.x;
			var dy = e.clientY - resizeStart.y;
			var aspect = resizeStart.w / resizeStart.h;
			var handle = resizeStart.handle;
			var newW, newH;

			// \u5F3A\u5236\u7B49\u6BD4\u4F8B resize\uFF1A\u6839\u636E\u624B\u67C4\u65B9\u5411\u9009\u62E9\u57FA\u51C6\u8F74
			if (handle === 'n' || handle === 's') {
				// \u5782\u76F4\u624B\u67C4\uFF1A\u4EE5\u9AD8\u5EA6\u53D8\u5316\u4E3A\u51C6
				newH = resizeStart.h + (handle === 's' ? dy : -dy);
				newW = newH * aspect;
			} else if (handle === 'e' || handle === 'w') {
				// \u6C34\u5E73\u624B\u67C4\uFF1A\u4EE5\u5BBD\u5EA6\u53D8\u5316\u4E3A\u51C6
				newW = resizeStart.w + (handle === 'e' ? dx : -dx);
				newH = newW / aspect;
			} else {
				// \u89D2\u70B9\uFF1A\u53D6\u9F20\u6807\u79FB\u52A8\u7EDD\u5BF9\u503C\u8F83\u5927\u7684\u65B9\u5411\u4E3A\u57FA\u51C6
				var ddx = (handle.indexOf('e') !== -1) ? dx : -dx;
				var ddy = (handle.indexOf('s') !== -1) ? dy : -dy;
				if (Math.abs(ddx) >= Math.abs(ddy)) {
					newW = resizeStart.w + ddx;
					newH = newW / aspect;
				} else {
					newH = resizeStart.h + ddy;
					newW = newH * aspect;
				}
			}

			var constrained = constrainResize(activeImage, newW, newH, aspect);
			var rw = Math.round(constrained.w) + 'px';
			var rh = Math.round(constrained.h) + 'px';
			activeImage.style.width = rw;
			activeImage.style.height = rh;
			activeImage.style.maxWidth = rw;
			activeImage.style.maxHeight = rh;
			updateHandlesPosition();
		}
	}, true);

	// mouseup: \u7ED3\u675F\u64CD\u4F5C
	document.body.addEventListener('mouseup', function(e) {
		if (isDragging) {
			isDragging = false;
			if (activeImage) activeImage.style.cursor = 'grab';
			if (dragOverlay) dragOverlay.style.display = 'none';
		}
		if (isResizing) {
			isResizing = false;
		}
	}, true);

	// Escape \u53D6\u6D88
	document.addEventListener('keydown', function(e) {
		if (e.key === 'Escape' && activeImage) {
			deactivateImage();
		}
	});

	// \u6EDA\u52A8/resize \u65F6\u66F4\u65B0\u624B\u67C4\u4F4D\u7F6E
	window.addEventListener('scroll', function() {
		if (activeImage) updateHandlesPosition();
	}, true);
	window.addEventListener('resize', function() {
		if (activeImage) updateHandlesPosition();
	});

	// \u89C2\u5BDF\u56FE\u7247\u52A0\u8F7D\u5B8C\u6210\uFF0C\u66F4\u65B0\u624B\u67C4\u4F4D\u7F6E
	var imgObserver = new MutationObserver(function(mutations) {
		var img = activeImage;
		if (img && !img.complete) {
			img.addEventListener('load', function onLoad() {
				img.removeEventListener('load', onLoad);
				updateHandlesPosition();
			});
		}
	});
	imgObserver.observe(document.body, { childList: true, subtree: true });
})();
</script>`}function ye(i){let a=na(),e=aa(),t=i.lastIndexOf("</body>");return t!==-1?i.slice(0,t)+a+`
`+e+`
`+i.slice(t):i+`
`+a+`
`+e+`
</body>
</html>`}var ze=[{id:"default",name:"\u6807\u51C6\u9875",icon:"file-text"},{id:"cover",name:"\u5C01\u9762",icon:"image"},{id:"center",name:"\u5C45\u4E2D",icon:"align-center"},{id:"two-cols",name:"\u53CC\u680F",icon:"columns-2"},{id:"statement",name:"\u91D1\u53E5",icon:"quote"},{id:"section",name:"\u7AE0\u8282",icon:"heading-1"}],ni,xe=class extends y.ItemView{constructor(e){super(e);this.iframe=null;this.toolbarEl=null;this.metricsEl=null;this.currentMode="design";this._isHomePage=!0;this.exportBtn=null;this.settingsBtn=null;this.customSizeSelect=null;this.customCssBtn=null;this.customCssNameEl=null;this.layoutBtn=null;this.saveBtn=null;this.clearCacheBtn=null;this.toolbarActionsEl=null;this.homeBtn=null;this.statusBarEl=null;this.statusFileEl=null;this.statusAgentEl=null;this._isRendering=!1;this._hasCache=!1;this._isPreprocessed=!1;this._hasDividers=!1;this._hasAccumulated=!1;this._currentFileName=null;this._selectedSkillId=((ni=G[0])==null?void 0:ni.id)||"";this._currentSlideIndex=0;this.onModeChange=null;this.onSkillChange=null;this.onAiRender=null;this.onAiCancel=null;this.onOpenSettings=null;this.onExport=null;this.onCustomSizeChange=null;this.onCustomCss=null;this.onSlideLayoutChange=null;this.onSaveHtml=null;this.onGoHome=null;this.onClearCache=null}getViewType(){return ie}getDisplayText(){return"LumiSlate Canvas"}onOpen(){return x(this,null,function*(){let e=this.containerEl.children[1];e.empty(),e.addClass("lumislate-canvas-container"),this.toolbarEl=e.createEl("div",{cls:"lumislate-toolbar"});let t=this.toolbarEl.createEl("div",{cls:"lumislate-context-group"});this.homeBtn=t.createEl("button",{cls:`lumislate-btn lumislate-btn-ghost lumislate-btn-icon ${this._isHomePage?"active":""}`,attr:{"aria-label":"\u8FD4\u56DE\u4E3B\u9875"}}),(0,y.setIcon)(this.homeBtn,"home"),this.homeBtn.addEventListener("click",()=>{var r;return(r=this.onGoHome)==null?void 0:r.call(this)}),this.settingsBtn=t.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost lumislate-btn-icon",attr:{"aria-label":"\u8BBE\u7F6E"}}),(0,y.setIcon)(this.settingsBtn,"settings"),this.settingsBtn.addEventListener("click",()=>{var r;return(r=this.onOpenSettings)==null?void 0:r.call(this)});let n=t.createEl("div",{cls:"lumislate-mode-tabs"});for(let r of vt){let l=n.createEl("button",{cls:`lumislate-mode-tab ${r.id===this.currentMode?"active":""}`,attr:{"data-mode-id":r.id}});(0,y.setIcon)(l.createSpan(),r.icon),l.appendText(" "+r.name),l.addEventListener("click",()=>{var c;this.currentMode!==r.id&&(this.currentMode=r.id,(c=this.onModeChange)==null||c.call(this,r.id),n.querySelectorAll(".lumislate-mode-tab").forEach(d=>{d.toggleClass("active",d.getAttribute("data-mode-id")===r.id)}),this.rebuildToolbarActions())})}let o=this.toolbarEl.createEl("div",{cls:"lumislate-context-group"});this.toolbarActionsEl=o.createEl("div",{cls:"lumislate-toolbar-actions"}),this.rebuildToolbarActions(),this.metricsEl=e.createEl("div",{cls:"lumislate-metrics-bar"}),this.metricsEl.style.display="none";let s=e.createEl("div",{cls:"lumislate-main"});this.iframe=s.createEl("iframe",{cls:"lumislate-canvas-iframe"}),this.iframe.setAttribute("srcdoc",ii()),this.iframe.setAttribute("sandbox","allow-scripts allow-same-origin"),this.statusBarEl=e.createEl("div",{cls:"lumislate-status-bar"}),this.buildStatusBar(this.statusBarEl)})}onClose(){return x(this,null,function*(){this.iframe&&(this.iframe.srcdoc=""),this.iframe=null,this.toolbarEl=null,this.toolbarActionsEl=null,this.homeBtn=null,this.metricsEl=null,this.statusBarEl=null,this.statusFileEl=null,this.statusAgentEl=null,this.exportBtn=null,this.settingsBtn=null,this.customSizeSelect=null,this.customCssBtn=null,this.customCssNameEl=null,this.customPreprocessBtn=null,this.layoutBtn=null,this.saveBtn=null,this.clearCacheBtn=null})}rebuildToolbarActions(){this.toolbarActionsEl&&(this.toolbarActionsEl.empty(),this.currentMode==="custom"?this.buildCustomActions(this.toolbarActionsEl):this.buildDesignActions(this.toolbarActionsEl),this.toolbarActionsEl.style.display=this._isHomePage?"none":"flex",this.updateActionBarState())}buildStatusBar(e){e.empty();let t=e.createEl("div",{cls:"lumislate-status-left"});this.statusFileEl=t.createEl("span",{cls:"lumislate-status-item lumislate-status-file"}),this.statusFileEl.textContent="\u5F53\u524D\u6587\u4EF6\uFF1A\u672A\u6253\u5F00";let n=e.createEl("div",{cls:"lumislate-status-right"});this.statusAgentEl=n.createEl("span",{cls:"lumislate-status-item lumislate-status-agent"}),this.statusAgentEl.textContent="Agent\uFF1A\u672A\u914D\u7F6E"}setStatusBarInfo(e,t,n){this.statusFileEl&&(this.statusFileEl.textContent=e?`\u5F53\u524D\u6587\u4EF6\uFF1A${e}`:"\u5F53\u524D\u6587\u4EF6\uFF1A\u672A\u6253\u5F00"),this.statusAgentEl&&(this.statusAgentEl.textContent=`Agent\uFF1A${t}`,this.statusAgentEl.toggleClass("status-error",!!n))}buildCustomActions(e){this.customSizeSelect=e.createEl("select",{cls:"lumislate-skill-select"});let t=[{label:"16:9",value:"16:9"},{label:"4:3",value:"4:3"},{label:"1:1",value:"1:1"}];for(let n of t)this.customSizeSelect.createEl("option",{text:n.label,value:n.value});this.customSizeSelect.addEventListener("change",()=>{var n;(n=this.onCustomSizeChange)==null||n.call(this,this.customSizeSelect.value)}),this.layoutBtn=e.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost"}),(0,y.setIcon)(this.layoutBtn.createSpan(),"layout"),this.layoutBtn.appendText(" \u7248\u5F0F"),this.layoutBtn.addEventListener("click",n=>this.showLayoutMenu(n)),this.saveBtn=e.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost"}),(0,y.setIcon)(this.saveBtn.createSpan(),"save"),this.saveBtn.appendText(" \u4FDD\u5B58"),this.saveBtn.addEventListener("click",()=>{var n;return(n=this.onSaveHtml)==null?void 0:n.call(this)}),this.customCssBtn=e.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost"}),(0,y.setIcon)(this.customCssBtn.createSpan(),"palette"),this.customCssBtn.appendText(" CSS"),this.customCssBtn.addEventListener("click",()=>{var n;return(n=this.onCustomCss)==null?void 0:n.call(this)}),this.customCssNameEl=e.createEl("span",{cls:"lumislate-context-item"}),this.customCssNameEl.style.display="none",this.exportBtn=e.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost"}),(0,y.setIcon)(this.exportBtn.createSpan(),"download"),this.exportBtn.appendText(" \u5BFC\u51FA"),this.exportBtn.addEventListener("click",()=>{var n;return(n=this.onExport)==null?void 0:n.call(this)})}buildDesignActions(e){this.exportBtn=e.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost"}),(0,y.setIcon)(this.exportBtn.createSpan(),"download"),this.exportBtn.appendText(" \u5BFC\u51FA"),this.exportBtn.addEventListener("click",()=>{var t;return(t=this.onExport)==null?void 0:t.call(this)}),this.clearCacheBtn=e.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost"}),(0,y.setIcon)(this.clearCacheBtn.createSpan(),"eraser"),this.clearCacheBtn.appendText(" \u6E05\u9664\u6392\u7248"),this.clearCacheBtn.addEventListener("click",()=>{var t;return(t=this.onClearCache)==null?void 0:t.call(this)})}setMode(e){var t;this.currentMode!==e&&(this.currentMode=e,(t=this.toolbarEl)==null||t.querySelectorAll(".lumislate-mode-tab").forEach(n=>{n.toggleClass("active",n.getAttribute("data-mode-id")===e)}),this.rebuildToolbarActions())}setHomePage(e){this._isHomePage!==e&&(this._isHomePage=e,this.toolbarActionsEl&&(this.toolbarActionsEl.style.display=e?"none":"flex"),this.homeBtn&&this.homeBtn.toggleClass("active",e))}getMode(){return this.currentMode}isHomePage(){return this._isHomePage}setSelectedSkill(e){this._selectedSkillId=e}getSelectedSkill(){var e;return this._selectedSkillId||((e=G[0])==null?void 0:e.id)||""}setCurrentSlideIndex(e){this._currentSlideIndex=e}getCurrentSlideIndex(){return this._currentSlideIndex}setLayoutSelectValue(e){if(!this.layoutBtn)return;let t=ze.find(n=>n.id===e);this.layoutBtn.empty(),(0,y.setIcon)(this.layoutBtn.createSpan(),(t==null?void 0:t.icon)||"layout"),this.layoutBtn.appendText(` ${(t==null?void 0:t.name)||"\u7248\u5F0F"}`)}showLayoutMenu(e){let t=new y.Menu;for(let n of ze)t.addItem(o=>{o.setTitle(n.name).setIcon(n.icon).onClick(()=>{var s;return(s=this.onSlideLayoutChange)==null?void 0:s.call(this,n.id)})});t.showAtMouseEvent(e)}setCustomSize(e){this.customSizeSelect&&(this.customSizeSelect.value=e)}setCustomCssName(e){this.customCssNameEl&&(e?(this.customCssNameEl.empty(),(0,y.setIcon)(this.customCssNameEl.createSpan(),"palette"),this.customCssNameEl.appendText(" "+e),this.customCssNameEl.style.display="inline-flex"):this.customCssNameEl.style.display="none")}setContextInfo(e,t,n,o){this._currentFileName=e,this._hasCache=t,this._isPreprocessed=n,o!==void 0&&(this._hasDividers=o),this.updateActionBarState()}setHasAccumulated(e){this._hasAccumulated=e,this.updateActionBarState()}setRenderingState(e){this._isRendering=e,this.updateActionBarState()}setExportEnabled(e){this.exportBtn&&(this.exportBtn.disabled=!e)}updateActionBarState(){this._isRendering?(this.exportBtn&&(this.exportBtn.disabled=!0),this.customSizeSelect&&(this.customSizeSelect.disabled=!0),this.layoutBtn&&(this.layoutBtn.disabled=!0),this.customCssBtn&&(this.customCssBtn.disabled=!0),this.saveBtn&&(this.saveBtn.disabled=!0),this.settingsBtn&&(this.settingsBtn.disabled=!0),this.clearCacheBtn&&(this.clearCacheBtn.disabled=!0)):(this.exportBtn&&(this.exportBtn.disabled=this.currentMode==="design"?!this._hasCache&&!this._hasAccumulated:!1),this.customSizeSelect&&(this.customSizeSelect.disabled=!this._hasDividers),this.layoutBtn&&(this.layoutBtn.disabled=!this._hasDividers),this.customCssBtn&&(this.customCssBtn.disabled=!1),this.saveBtn&&(this.saveBtn.disabled=!1),this.settingsBtn&&(this.settingsBtn.disabled=!1),this.clearCacheBtn&&(this.clearCacheBtn.disabled=!(this._hasCache||this._hasAccumulated)))}setStatus(e){var n;let t=(n=this.toolbarEl)==null?void 0:n.querySelector(".lumislate-status");t&&(t.textContent=e)}renderCanvas(e){this.iframe&&(this.iframe.srcdoc=e,this.setHomePage(!1))}renderStream(e){this.iframe&&(this.iframe.srcdoc=e,this.setHomePage(!1))}resetToWelcome(){this.iframe&&(this.iframe.srcdoc=ii(),this.setHomePage(!0))}updateMetrics(e){if(!this.metricsEl)return;let t=e.endedAt?((e.endedAt-e.startedAt)/1e3).toFixed(1):((Date.now()-e.startedAt)/1e3).toFixed(1),n=(e.outputBytes/1024).toFixed(1),o=!e.endedAt,s=o?"\u6E32\u67D3\u4E2D":"\u5B8C\u6210",r=o?"status-running":"status-done",l="";if(l+=`<div class="lumislate-metric-status ${r}"><span class="lumislate-pulse-dot"></span><span>${s}</span></div>`,l+=`<div class="lumislate-metric"><span class="lumislate-metric-label">\u8017\u65F6</span><span class="lumislate-metric-value ${o?"live":""}">${t}s</span></div>`,l+=`<div class="lumislate-metric"><span class="lumislate-metric-label">\u5927\u5C0F</span><span class="lumislate-metric-value">${n} KB</span></div>`,l+=`<div class="lumislate-metric"><span class="lumislate-metric-label">\u5757\u6570</span><span class="lumislate-metric-value">${e.deltaCount}</span></div>`,e.model&&(l+=`<div class="lumislate-metric"><span class="lumislate-metric-label">\u6A21\u578B</span><span class="lumislate-metric-value" title="${e.model}">${e.model}</span></div>`),e.inputTokens!==void 0||e.outputTokens!==void 0){let c=[];e.inputTokens!==void 0&&c.push(`in ${e.inputTokens}`),e.outputTokens!==void 0&&c.push(`out ${e.outputTokens}`),l+=`<div class="lumislate-metric"><span class="lumislate-metric-label">Token</span><span class="lumislate-metric-value">${c.join(" / ")}</span></div>`}e.skillName&&(l+=`<div class="lumislate-metric"><span class="lumislate-metric-label">\u6837\u5F0F</span><span class="lumislate-metric-value">${X(e.skillName)}</span></div>`),this.metricsEl.innerHTML=l,this.metricsEl.style.display="flex"}hideMetrics(){this.metricsEl&&(this.metricsEl.style.display="none")}getIframeWindow(){var e,t;return(t=(e=this.iframe)==null?void 0:e.contentWindow)!=null?t:null}getIframe(){return this.iframe}scrollToSlide(e){let t=this.getIframeWindow();t&&t.postMessage({type:"lumislate-scroll-to-slide",index:e},"*")}},Oe=class extends y.Plugin{constructor(){super(...arguments);this.settings=We;this.aiAbortCtl=null;this.aiCancelled=!1;this.aiAccumulated="";this.currentRunStats=null;this.metricsTimer=null;this.customRenderDebounceTimer=null;this.cursorSyncInterval=null;this.lastCursorSlideIndex=-1;this.reverseMappingHandler=null}onload(){return x(this,null,function*(){console.log("LumiSlate (\u6D41\u5149\u77F3\u677F) \u63D2\u4EF6\u5DF2\u52A0\u8F7D"),yield this.loadSettings(),this.cacheManager=new ke(this.app,this.manifest.dir),console.log(`[LumiSlate] \u5185\u7F6E skills \u5DF2\u5C31\u7EEA\uFF0C\u5171 ${G.length} \u4E2A`),!Pe(this.settings.defaultSkill)&&G.length>0&&(this.settings.defaultSkill=G[0].id,yield this.saveSettings()),this.registerView(ie,e=>{let t=new xe(e);t.onModeChange=o=>x(this,null,function*(){if(this.settings.defaultMode=o,this.saveSettings(),o==="custom")yield this.renderCurrentNote();else{let s=this.app.workspace.getActiveFile();if(s&&s.extension==="md"){let r=yield this.app.vault.read(s),{frontmatter:l}=F(r),c=D(l,"lumislate_prompt"),d=yield this.cacheManager.readCache(s.path,r,c);d?t.renderCanvas(ye(d)):t.renderCanvas(Re(G,this.settings.defaultSkill))}else t.renderCanvas(Re(G,this.settings.defaultSkill))}yield this.refreshViewContext()}),t.onSkillChange=o=>{this.settings.defaultSkill=o,this.saveSettings()},t.onAiRender=()=>this.aiRenderCurrentNote(),t.onAiCancel=()=>this.cancelAiRender(),t.onOpenSettings=()=>{this.app.setting.open(),this.app.setting.openTabById(this.manifest.id)},t.onExport=()=>this.showExportMenu(),t.onSaveHtml=()=>this.saveCustomHtml(),t.onCustomSizeChange=o=>this.handleCustomSizeChange(o),t.onCustomCss=()=>this.showCustomCssModal(),t.onSlideLayoutChange=o=>this.applySlideLayout(o),t.onGoHome=()=>t.resetToWelcome(),t.onClearCache=()=>this.handleClearLayout(),t.setMode(this.settings.defaultMode),t.setSelectedSkill(this.settings.defaultSkill);let n=this.getAgentDisplayText();return t.setStatusBarInfo(null,n.text,n.isError),this.refreshViewContext().catch(()=>{}),t}),this.addSettingTab(new Me(this.app,this)),this.detectLocalAgents(),this.addRibbonIcon("sparkles","\u6253\u5F00 LumiSlate \u753B\u5E03",()=>x(this,null,function*(){yield this.activateView()})),this.addCommand({id:"open-lumislate-canvas",name:"\u6253\u5F00 LumiSlate \u753B\u5E03",callback:()=>x(this,null,function*(){yield this.activateView()})}),this.addCommand({id:"ai-render-current-note",name:"LumiSlate\uFF1AAI \u6E32\u67D3\u5F53\u524D\u7B14\u8BB0",callback:()=>x(this,null,function*(){yield this.aiRenderCurrentNote()})}),this.addCommand({id:"clear-lumislate-cache",name:"LumiSlate\uFF1A\u6E05\u9664\u5F53\u524D\u7B14\u8BB0\u7F13\u5B58",callback:()=>x(this,null,function*(){yield this.clearCurrentNoteCache()})}),this.registerEvent(this.app.workspace.on("active-leaf-change",()=>{this.refreshViewContext().catch(()=>{}),this.lastCursorSlideIndex=-1;let e=this.getLumiSlateView();e&&e.getMode()==="custom"&&!e.isHomePage()&&this.renderCurrentNote().catch(()=>{})})),this.registerEvent(this.app.vault.on("modify",e=>{let t=this.app.workspace.getActiveFile();if(!t||t.path!==e.path)return;let n=this.getLumiSlateView();!n||n.getMode()!=="custom"||(this.customRenderDebounceTimer&&clearTimeout(this.customRenderDebounceTimer),this.customRenderDebounceTimer=window.setTimeout(()=>{this.customRenderDebounceTimer=null,this.renderCurrentNote()},200))})),this.setupReverseMapping(),this.cursorSyncInterval=window.setInterval(()=>{let e=this.getSlideIndexAtCursor();e!==this.lastCursorSlideIndex&&(this.lastCursorSlideIndex=e,this.syncCursorToSlide())},200)})}onunload(){console.log("LumiSlate \u63D2\u4EF6\u5DF2\u5378\u8F7D"),this.cancelAiRender(),this.customRenderDebounceTimer&&(clearTimeout(this.customRenderDebounceTimer),this.customRenderDebounceTimer=null),this.cursorSyncInterval&&(clearInterval(this.cursorSyncInterval),this.cursorSyncInterval=null),this.stopMetricsTimer(),this.reverseMappingHandler&&(window.removeEventListener("message",this.reverseMappingHandler),this.reverseMappingHandler=null),this.aiAccumulated="",this.aiCancelled=!1,this.currentRunStats=null,this.app.workspace.detachLeavesOfType(ie)}loadSettings(){return x(this,null,function*(){var e;this.settings=Object.assign({},We,yield this.loadData()),this.settings.defaultMode==="marp"&&(this.settings.defaultMode="custom"),(e=this.settings.cssSystemPrompt)!=null&&e.trim()||(this.settings.cssSystemPrompt=ue),yield this.saveSettings()})}saveSettings(){return x(this,null,function*(){yield this.saveData(this.settings)})}detectLocalAgents(){let e=je();if(e.length===0){console.log("[LumiSlate] \u672A\u68C0\u6D4B\u5230\u4EFB\u4F55\u672C\u5730 CLI Agent");return}console.log("[LumiSlate] \u68C0\u6D4B\u5230\u672C\u5730 Agent:",e.map(t=>t.id).join(", ")),this.settings.localAgent||(this.settings.localAgent=e[0].id,this.saveSettings())}resolveAIProvider(){if(this.settings.aiProvider==="local"){let e=this.settings.localAgent?me(this.settings.localAgent):void 0;if(e!=null&&e.available)return{provider:"local",agentId:e.id,reason:`\u672C\u5730 ${e.label}`};let t=je()[0];return t?{provider:"local",agentId:t.id,reason:`\u81EA\u52A8\u56DE\u9000\u5230 ${t.label}`}:this.settings.apiKey?{provider:"http",reason:"\u672C\u5730 Agent \u672A\u5B89\u88C5\uFF0C\u56DE\u9000\u5230 HTTP API"}:{provider:"http",reason:"\u672C\u5730 Agent \u672A\u5B89\u88C5\uFF0C\u4E14\u672A\u914D\u7F6E HTTP API"}}return{provider:"http",reason:"HTTP API"}}getAgentDisplayText(){let e=this.resolveAIProvider();if(e.provider==="local"&&e.agentId){let t=me(e.agentId);return{text:(t==null?void 0:t.label)||e.agentId,isError:!1}}return e.provider==="http"?this.settings.apiKey?{text:this.settings.model||"HTTP API",isError:!1}:{text:"\u672A\u914D\u7F6E",isError:!0}:{text:"\u672A\u914D\u7F6E",isError:!0}}activateView(){return x(this,null,function*(){let{workspace:e}=this.app,t=null,n=e.getLeavesOfType(ie);n.length>0?t=n[0]:(t=e.getRightLeaf(!1),t&&(yield t.setViewState({type:ie,active:!0}))),t&&e.revealLeaf(t)})}getLumiSlateView(){let e=this.app.workspace.getLeavesOfType(ie);if(e.length===0)return null;let t=e[0].view;return!t||!(t instanceof xe)?null:t}refreshViewContext(){return x(this,null,function*(){let e=this.getLumiSlateView();if(!e)return;let t=this.getAgentDisplayText(),n=this.app.workspace.getActiveFile();if(!n||n.extension!=="md"){e.setContextInfo(null,!1,!1,!1),e.setExportEnabled(!1),e.setStatusBarInfo(null,t.text,t.isError);return}let o=e.getMode(),s=yield this.app.vault.read(n),{frontmatter:r,body:l}=F(s),c=/^---\s*$/m.test(l),d=D(r,"size")||"16:9";if(e.setCustomSize(d),o==="custom"){let m=yield Ct(this.app.vault,n,"custom");e.setContextInfo(n.basename,!1,m.preprocessed,c),e.setCustomCssName(D(r,"lumislate_css")),e.setExportEnabled(!0),e.setHasAccumulated(!0),e.setStatusBarInfo(n.basename,t.text,t.isError);return}let u=D(r,"lumislate_prompt"),g=yield this.cacheManager.readCache(n.path,s,u);e.setContextInfo(n.basename,!!g,!1,c),e.setExportEnabled(!!g||!!this.aiAccumulated),e.setStatusBarInfo(n.basename,t.text,t.isError)})}renderCurrentNote(){return x(this,null,function*(){let e=this.app.workspace.getActiveFile();if(!e||e.extension!=="md"){new y.Notice("\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A Markdown \u7B14\u8BB0");return}let t=yield this.app.vault.read(e),n=e.path,{frontmatter:o}=F(t),s=D(o,"lumislate_theme"),r=D(o,"lumislate_prompt"),l=jn(t,this.app,n);this.cancelAiRender(),yield this.activateView();let c=this.getLumiSlateView();if(!c){new y.Notice("\u753B\u5E03\u89C6\u56FE\u672A\u5C31\u7EEA");return}if(c.getMode()==="custom"){let m=this.getSlideIndexAtCursor(),{savedHtmlPath:b,hasConflict:h}=yield this.checkSavedHtmlConflict(n);if(b&&!h){let w=yield this.app.vault.adapter.read(b).catch(()=>null);if(w){c.renderCanvas(w),yield this.refreshViewContext(),new y.Notice("\u5DF2\u4ECE\u4FDD\u5B58\u7684 HTML \u6062\u590D");return}}if(b&&h&&!confirm(`\u68C0\u6D4B\u5230 Markdown \u6587\u4EF6\u5DF2\u66F4\u65B0\uFF08${e.basename}.md\uFF09\u3002

\u5DF2\u4FDD\u5B58\u7684 HTML \u53EF\u80FD\u5DF2\u8FC7\u671F\uFF0C\u662F\u5426\u91CD\u65B0\u6E32\u67D3\uFF1F

\u3010\u786E\u5B9A\u3011\u91CD\u65B0\u6E32\u67D3 HTML\uFF08\u57FA\u4E8E\u6700\u65B0 Markdown\uFF09
\u3010\u53D6\u6D88\u3011\u4ECD\u52A0\u8F7D\u5DF2\u4FDD\u5B58\u7684 HTML`)){let v=yield this.app.vault.adapter.read(b).catch(()=>null);if(v){c.renderCanvas(v),yield this.refreshViewContext();return}}let p=yield Zn(l,this.app,this.manifest.dir,w=>this.getSlideLayout(n,w),{baseFontSize:this.settings.customBaseFontSize,textColor:this.settings.customTextColor,fontFamily:this.settings.customFontFamily}),f=ye(p);c.renderCanvas(f),m>0&&window.setTimeout(()=>{c.scrollToSlide(m),c.setCurrentSlideIndex(m);let w=this.getSlideLayout(n,m);c.setLayoutSelectValue(w)},80),yield this.refreshViewContext();return}let u=n?yield this.cacheManager.readCache(n,t,r):null;if(u)new y.Notice("LumiSlate\uFF1A\u5DF2\u4ECE\u7F13\u5B58\u6062\u590D\u753B\u5E03");else{let m=ve(l);u=Gn(m),n&&(yield this.cacheManager.writeCache(n,u,t,s,r)),new y.Notice("LumiSlate\uFF1A\u5DF2\u751F\u6210\u5E76\u7F13\u5B58\u753B\u5E03")}let g=ye(u);c.renderCanvas(g),yield this.refreshViewContext()})}aiRenderCurrentNote(){return x(this,null,function*(){let e=this.app.workspace.getActiveFile();if(!e||e.extension!=="md"){new y.Notice("\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A Markdown \u7B14\u8BB0");return}let t=yield this.app.vault.read(e),n=e.path;yield this.activateView();let o=this.getLumiSlateView();if(!o){new y.Notice("\u753B\u5E03\u89C6\u56FE\u672A\u5C31\u7EEA");return}let s=o.getMode(),r=o.getSelectedSkill(),l=s==="design"?Pe(r):null;if(s==="design"&&!l){new y.Notice("\u672A\u627E\u5230\u9009\u4E2D\u7684 SKILL");return}if(!this.isAiConfigured()){new y.Notice("\u5F53\u524D\u65E0\u53EF\u7528AI\uFF0C\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E\u672C\u5730 Agent \u6216 HTTP API");return}let c=this.resolveAIProvider();yield((u,g)=>x(this,null,function*(){var H,q;o.setRenderingState(!0);let m,{body:b}=F(u),{hasMermaid:h,hasLatex:p,mermaidBlocks:f}=kt(b||u),w="";if(h||p){let A=[];h&&(A.push(`\u3010Mermaid \u56FE\u8868\u6E32\u67D3\u8981\u6C42\u3011
\u672C\u6587\u6863\u5305\u542B Mermaid \u56FE\u8868\u4EE3\u7801\u5757\uFF0C\u4F60\u5FC5\u987B\u5728\u751F\u6210\u7684 HTML \u4E2D\uFF1A
1. \u5F15\u5165 Mermaid CDN (https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js)
2. \u5C06\u6BCF\u4E2A mermaid \u4EE3\u7801\u5757\u7684\u5185\u5BB9\u539F\u6837\u5305\u88F9\u5728 <div class="mermaid">...</div> \u4E2D\uFF08\u4E0D\u8981\u5BF9\u5185\u5BB9\u8FDB\u884C HTML \u8F6C\u4E49\uFF09
3. \u5728\u9875\u9762\u5E95\u90E8\u6DFB\u52A0 <script>mermaid.initialize({startOnLoad:true});</script>
\u68C0\u6D4B\u5230\u7684\u56FE\u8868\u5185\u5BB9\u9884\u89C8\uFF1A`),f.forEach((P,z)=>{let O=P.split(`
`)[0].trim();A.push(`  [\u56FE\u8868${z+1}] ${O}${P.includes(`
`)?" ...":""}`)})),p&&A.push(`\u3010LaTeX \u6570\u5B66\u516C\u5F0F\u6E32\u67D3\u8981\u6C42\u3011
\u672C\u6587\u6863\u5305\u542B LaTeX \u6570\u5B66\u516C\u5F0F\uFF0C\u4F60\u5FC5\u987B\u5728\u751F\u6210\u7684 HTML \u4E2D\u786E\u4FDD\uFF1A
1. \u5DF2\u5728 <head> \u4E2D\u5F15\u5165 KaTeX CSS \u548C JS CDN
2. \u9875\u9762\u52A0\u8F7D\u540E\u6B63\u786E\u6E32\u67D3\u6240\u6709 $...$ \u548C $$...$$ \u516C\u5F0F\uFF08\u4F7F\u7528 KaTeX \u7684 renderMathInElement \u6216\u7B49\u6548\u65B9\u6CD5\uFF09`),w=A.join(`

`)}if(s==="custom"){let A="",{frontmatter:P}=F(u);if(P){let O=wt(P);O&&O!=="(\u65E0\u989D\u5916\u6307\u4EE4)"&&(A=`\u3010\u7528\u6237\u6307\u5B9A\u7684\u81EA\u5B9A\u4E49\u6A21\u5F0F\u6307\u4EE4\u3011
${O}`)}let z=this.settings.slideLayouts[g];if(z&&Object.keys(z).length>0){let R=`\u3010\u6BCF\u9875\u7248\u5F0F\u6620\u5C04 \u2014 \u7531\u7528\u6237\u5728 LumiSlate \u4E2D\u6307\u5B9A\u3011
${Object.entries(z).sort((W,ne)=>parseInt(W[0])-parseInt(ne[0])).map(([W,ne])=>`  \u7B2C ${parseInt(W)+1} \u9875 \u2192 layout: ${ne}`).join(`
`)}

\u8BF7\u4E25\u683C\u6309\u7167\u4E0A\u8FF0\u6620\u5C04\u4E3A\u6BCF\u4E00\u9875 <section> \u8BBE\u7F6E\u5BF9\u5E94\u7684 layout \u5C5E\u6027\u3002\u672A\u6307\u5B9A\u7684\u9875\u4F7F\u7528\u9ED8\u8BA4\u7248\u5F0F\uFF08default\uFF09\u3002`;A=A?`${A}

${R}`:R}w&&(A=A?`${A}

${w}`:w),m=Ge(xt,u,A||void 0)}else m=Ge(l.body,u);this.cancelAiRender();let v=new AbortController;this.aiAbortCtl=v,this.aiCancelled=!1,this.aiAccumulated="",o.setHasAccumulated(!1);let S=s==="custom"?"\u81EA\u5B9A\u4E49\u6A21\u5F0F\u5E7B\u706F\u7247":(H=l==null?void 0:l.name)!=null?H:"Design",C=ea(c.reason,S);o.renderStream(C),o.setStatus(`${c.reason} \u6E32\u67D3\u4E2D\u2026`),new y.Notice(`LumiSlate\uFF1A\u5F00\u59CB AI \u6E32\u67D3 (${S} \xB7 ${c.reason})`),this.currentRunStats={startedAt:Date.now(),deltaCount:0,outputBytes:0,skillName:l==null?void 0:l.name},this.startMetricsTimer(),o.updateMetrics(this.currentRunStats);let E=A=>{this.aiAccumulated+=A,this.currentRunStats&&(this.currentRunStats.firstByteAt||(this.currentRunStats.firstByteAt=Date.now()),this.currentRunStats.deltaCount++,this.currentRunStats.outputBytes+=new TextEncoder().encode(A).length,this.updateMetricsDisplay());let P=bt(this.aiAccumulated);o.renderStream(P)},N=()=>{if(this.aiAbortCtl=null,o.setRenderingState(!1),this.currentRunStats&&(this.currentRunStats.endedAt=Date.now(),this.updateMetricsDisplay()),this.stopMetricsTimer(),this.aiCancelled){o.setStatus("\u5DF2\u53D6\u6D88");return}let A=Le(this.aiAccumulated),P=ye(A);if(o.renderCanvas(P),o.setStatus("\u6E32\u67D3\u5B8C\u6210"),o.setExportEnabled(!0),o.setHasAccumulated(!0),g){let{frontmatter:z}=F(u),O=D(z,"lumislate_theme"),R=D(z,"lumislate_prompt");this.cacheManager.writeCache(g,P,u,O,R).then(()=>new y.Notice("LumiSlate\uFF1AAI \u6E32\u67D3\u7ED3\u679C\u5DF2\u7F13\u5B58")).catch(W=>console.error("\u7F13\u5B58\u5199\u5165\u5931\u8D25",W))}};try{yield Ae(m,{provider:c.provider,agentId:c.agentId,binOverride:this.settings.localAgentBinOverride,llmConfig:{apiKey:this.settings.apiKey,baseURL:this.settings.apiBaseUrl,model:this.settings.model},model:c.provider==="local"?void 0:this.settings.model,signal:v.signal},{onDelta:E,onHtml:A=>{this.aiAccumulated=A;let P=ye(Le(A));o.renderCanvas(P)},onMeta:(A,P)=>{var z,O;if(A==="model"&&typeof P=="string"&&(this.currentRunStats&&(this.currentRunStats.model=P,this.updateMetricsDisplay()),o.setStatus(`${c.reason} \xB7 ${P}`)),A==="usage"&&P&&typeof P=="object"){let R=P;this.currentRunStats&&(this.currentRunStats.inputTokens=(z=R.input_tokens)!=null?z:R.prompt_tokens,this.currentRunStats.outputTokens=(O=R.completion_tokens)!=null?O:R.output_tokens,this.updateMetricsDisplay())}console.log("[LumiSlate] meta:",A,P)},onStderr:A=>{console.log("[LumiSlate] stderr:",A)},onError:A=>{this.currentRunStats&&(this.currentRunStats.endedAt=Date.now(),this.updateMetricsDisplay()),this.stopMetricsTimer(),o.setStatus(`\u9519\u8BEF: ${A.slice(0,40)}`),new y.Notice(`AI \u6E32\u67D3\u5931\u8D25: ${A}`)},onDone:N})}catch(A){this.aiAbortCtl=null,o.setRenderingState(!1),this.currentRunStats&&(this.currentRunStats.endedAt=Date.now(),this.updateMetricsDisplay()),this.stopMetricsTimer();let P=String((q=A==null?void 0:A.message)!=null?q:A);o.setStatus(`\u9519\u8BEF: ${P.slice(0,40)}`),new y.Notice(`AI \u6E32\u67D3\u5931\u8D25: ${P}`)}}))(t,n)})}showExportMenu(){this.getLumiSlateView()&&new $e(this.app,t=>{switch(t){case"html-download":this.exportHtmlDownload();break;case"png-download":this.exportPngDownload();break;case"html-vault":this.saveHtmlToVaultPath();break}}).open()}getCurrentHtml(){if(this.aiAccumulated)return this.aiAccumulated;let e=this.getLumiSlateView();if(e){let t=e.getIframe();if(t&&t.srcdoc)return t.srcdoc}return""}exportHtmlDownload(){let e=this.getCurrentHtml();if(!e){new y.Notice("\u753B\u5E03\u4E3A\u7A7A\uFF0C\u65E0\u6CD5\u5BFC\u51FA");return}let t=this.app.workspace.getActiveFile(),n=t?t.basename:"lumislate-export";Qt(e,`${n}-${Date.now()}`)}exportPngDownload(){return x(this,null,function*(){let e=this.getLumiSlateView();if(!e){new y.Notice("\u753B\u5E03\u89C6\u56FE\u672A\u5C31\u7EEA");return}let t=e.getIframe();if(!t){new y.Notice("\u753B\u5E03\u672A\u52A0\u8F7D");return}let n=this.app.workspace.getActiveFile(),o=n?n.basename:"lumislate-export";yield ei(t,`${o}-${Date.now()}`)})}saveHtmlToVaultPath(){return x(this,null,function*(){var r;let e=this.getCurrentHtml();if(!e){new y.Notice("\u753B\u5E03\u4E3A\u7A7A\uFF0C\u65E0\u6CD5\u4FDD\u5B58");return}let t=this.app.workspace.getActiveFile();if(!t){new y.Notice("\u672A\u627E\u5230\u5F53\u524D\u7B14\u8BB0");return}let n=this.settings.defaultExportFolder||((r=t.parent)==null?void 0:r.path)||"",o=`${t.basename}.html`,s=n?`${n}/${o}`:o;yield ti(this.app,e,s)})}getCustomHtmlSavePath(e){var r;let t=this.settings.htmlDefaultSaveFolder,o=`${((r=e.split("/").pop())==null?void 0:r.replace(/\.md$/i,""))||"untitled"}.html`;if(t)return`${t}/${o}`;let s=e.split("/").slice(0,-1).join("/");return s?`${s}/${o}`:o}saveCustomHtml(){return x(this,null,function*(){var c,d;let e=this.getLumiSlateView();if(!e){new y.Notice("\u753B\u5E03\u89C6\u56FE\u672A\u5C31\u7EEA");return}let t=e.getIframe();if(!t||!t.srcdoc){new y.Notice("\u753B\u5E03\u4E3A\u7A7A\uFF0C\u65E0\u6CD5\u4FDD\u5B58");return}let n=this.app.workspace.getActiveFile();if(!n||n.extension!=="md"){new y.Notice("\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A Markdown \u7B14\u8BB0");return}let o=this.getCustomHtmlSavePath(n.path),s=t.srcdoc,l=`<meta name="lumislate-source-mtime" content="${((c=n.stat)==null?void 0:c.mtime)||Date.now()}">`;s.includes("<head>")?s=s.replace("<head>",`<head>
${l}`):s=s+`
`+l;try{let u=o.split("/").slice(0,-1).join("/");u&&!(yield this.app.vault.adapter.exists(u))&&(yield this.app.vault.adapter.mkdir(u)),yield this.app.vault.adapter.write(o,s),new y.Notice(`HTML \u5DF2\u4FDD\u5B58: ${o}`)}catch(u){let g=String((d=u==null?void 0:u.message)!=null?d:u);new y.Notice(`\u4FDD\u5B58\u5931\u8D25: ${g}`)}})}checkSavedHtmlConflict(e){return x(this,null,function*(){let t=this.getCustomHtmlSavePath(e);if(!(yield this.app.vault.adapter.exists(t)))return{savedHtmlPath:null,hasConflict:!1};let o=yield this.app.vault.adapter.read(t).catch(()=>null);if(!o)return{savedHtmlPath:t,hasConflict:!1};let s=o.match(/<meta name="lumislate-source-mtime" content="(\d+)">/),r=s?parseInt(s[1],10):0,l=this.app.vault.getAbstractFileByPath(e),c=0;l instanceof y.TFile&&l.stat&&(c=l.stat.mtime);let d=c>r;return{savedHtmlPath:t,hasConflict:d}})}handleCustomSizeChange(e){return x(this,null,function*(){let t=this.app.workspace.getActiveFile();if(!t||t.extension!=="md"){new y.Notice("\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A Markdown \u7B14\u8BB0");return}yield this.updateCustomFrontmatterField("size",e),yield this.renderCurrentNote()})}applySlideLayout(e){return x(this,null,function*(){var s,r;let t=this.getLumiSlateView(),n=(s=t==null?void 0:t.getCurrentSlideIndex())!=null?s:0,o=this.app.workspace.getActiveFile();if(!o||o.extension!=="md"){new y.Notice("\u672A\u627E\u5230\u5F53\u524D Markdown \u6587\u4EF6");return}this.settings.slideLayouts[o.path]||(this.settings.slideLayouts[o.path]={}),this.settings.slideLayouts[o.path][n]=e,yield this.saveSettings(),new y.Notice(`\u5DF2\u5E94\u7528\u7248\u5F0F: ${((r=ze.find(l=>l.id===e))==null?void 0:r.name)||e} (\u7B2C ${n+1} \u9875)`),yield this.renderCurrentNote()})}getSlideLayout(e,t){var n;return((n=this.settings.slideLayouts[e])==null?void 0:n[t])||"default"}loadCssSystemPrompt(){var t;return((t=this.settings.cssSystemPrompt)==null?void 0:t.trim())||ue}getCssSystemPrompt(e){let t=this.loadCssSystemPrompt();return`\u4F60\u662F LumiSlate \u63D2\u4EF6\u7684 CSS \u8BBE\u8BA1\u4E13\u5BB6\uFF0C\u4E13\u95E8\u5E2E\u52A9\u7528\u6237\u4E3A \u81EA\u5B9A\u4E49\u6A21\u5F0F\u7F16\u5199\u81EA\u5B9A\u4E49 CSS\u3002

## \u5F53\u524D CSS \u4EE3\u7801
\`\`\`css
${e||"/* \u5F53\u524D\u4E3A\u7A7A */"}
\`\`\`

${t}`}appendAiChatMessage(e,t,n){let o=e.createEl("div",{cls:`lumislate-css-ai-msg lumislate-css-ai-msg-${t}`});o.createEl("div",{cls:"lumislate-css-ai-msg-role",text:t==="user"?"\u4F60":"AI"});let s=o.createEl("div",{cls:"lumislate-css-ai-msg-content"});s.textContent=n,e.scrollTop=e.scrollHeight}sendAiCssAssist(e,t,n,o,s){return x(this,null,function*(){var h;let r=this.resolveAIProvider();if(r.provider==="http"&&!this.settings.apiKey){this.appendAiChatMessage(n,"ai","\u9519\u8BEF\uFF1A\u672A\u914D\u7F6E AI\u3002\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u9009\u62E9\u672C\u5730 Agent \u6216\u914D\u7F6E HTTP API Key\u3002");return}this.appendAiChatMessage(n,"user",e),s.textContent="\u601D\u8003\u4E2D\u2026",s.addClass("lumislate-css-ai-status-active");let c=`${this.getCssSystemPrompt(t)}

## \u7528\u6237\u7684\u8BF7\u6C42
${e}

\u8BF7\u8F93\u51FA\u4FEE\u6539\u540E\u7684\u5B8C\u6574 CSS \u4EE3\u7801\uFF1A`,d="",u=new AbortController;this.aiAbortCtl=u;let g=n.createEl("div",{cls:"lumislate-css-ai-msg lumislate-css-ai-msg-ai"});g.createEl("div",{cls:"lumislate-css-ai-msg-role",text:"AI"});let m=g.createEl("div",{cls:"lumislate-css-ai-msg-content"}),b=g.createEl("button",{text:"\u5E94\u7528\u6B64 CSS",cls:"lumislate-btn lumislate-btn-primary lumislate-btn-small"});b.style.marginTop="8px",b.style.display="none";try{yield Ae(c,{provider:r.provider,agentId:r.agentId,binOverride:this.settings.localAgentBinOverride,llmConfig:{apiKey:this.settings.apiKey,baseURL:this.settings.apiBaseUrl,model:this.settings.model},model:r.provider==="local"?void 0:this.settings.model,signal:u.signal},{onDelta:p=>{d+=p,m.textContent=d,n.scrollTop=n.scrollHeight},onHtml:p=>{d=p,m.textContent=d,n.scrollTop=n.scrollHeight},onMeta:()=>{},onStderr:()=>{},onError:p=>{m.textContent=`\u9519\u8BEF\uFF1A${p}`,s.textContent="",s.removeClass("lumislate-css-ai-status-active")},onDone:()=>{this.aiAbortCtl=null,s.textContent="",s.removeClass("lumislate-css-ai-status-active");let p=d,f=p.match(/```(?:css)?\s*([\s\S]*?)```/);f&&(p=f[1].trim()),p&&(d=p,m.textContent=d,b.style.display="inline-flex",b.onclick=()=>{o.setValue(d),new y.Notice("AI \u751F\u6210\u7684 CSS \u5DF2\u5E94\u7528\u5230\u7F16\u8F91\u5668")})}})}catch(p){this.aiAbortCtl=null,m.textContent=`\u8BF7\u6C42\u5931\u8D25\uFF1A${String((h=p==null?void 0:p.message)!=null?h:p)}`,s.textContent="",s.removeClass("lumislate-css-ai-status-active")}})}showCustomCssModal(){return x(this,null,function*(){let e=`/* LumiSlate \u9ED8\u8BA4\u5E7B\u706F\u7247\u6837\u5F0F */

/* \u5E7B\u706F\u7247\u57FA\u7840 */
section {
  background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
  color: #e2e8f0;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}

/* \u6807\u9898\u4F53\u7CFB */
section h1 {
  font-size: 2.5rem;
  font-weight: 800;
  margin-bottom: 1.5rem;
  letter-spacing: -0.02em;
  color: #f8fafc;
}

section h2 {
  font-size: 1.75rem;
  font-weight: 700;
  margin: 1.5rem 0 1rem;
  color: #e2e8f0;
}

section h3 {
  font-size: 1.25rem;
  font-weight: 600;
  margin: 1rem 0 0.5rem;
  color: #cbd5e1;
}

section h4 {
  font-size: 1.1rem;
  font-weight: 600;
  margin: 0.75rem 0 0.4rem;
  color: #94a3b8;
}

/* \u6BB5\u843D\u4E0E\u6587\u672C */
section p {
  line-height: 1.75;
  margin-bottom: 0.75rem;
}

section strong {
  font-weight: 700;
  color: #f8fafc;
}

section em {
  font-style: italic;
  color: #cbd5e1;
}

section mark {
  background: rgba(250, 204, 21, 0.25);
  color: inherit;
  padding: 0.1em 0.35em;
  border-radius: 4px;
}

section del {
  opacity: 0.6;
  text-decoration: line-through;
}

section u {
  text-decoration: underline;
  text-decoration-color: rgba(96, 165, 250, 0.6);
  text-underline-offset: 3px;
}

section a {
  color: #60a5fa;
  text-decoration: none;
  transition: color 0.2s;
}

section a:hover {
  color: #93c5fd;
  text-decoration: underline;
}

/* \u5217\u8868 */
section ul, section ol {
  margin-left: 1.5rem;
  margin-bottom: 0.75rem;
}

section li {
  margin-bottom: 0.35rem;
}

/* \u4EE3\u7801 */
section pre {
  background: rgba(0, 0, 0, 0.25);
  padding: 0.75rem 1rem;
  border-radius: 8px;
  overflow-x: auto;
  margin: 0.5rem 0;
}

section code {
  font-family: "Fira Code", "JetBrains Mono", "SF Mono", Monaco, monospace;
  font-size: 0.85em;
  background: rgba(0, 0, 0, 0.2);
  padding: 0.15rem 0.35rem;
  border-radius: 4px;
}

/* \u8868\u683C */
section table {
  width: 100%;
  border-collapse: collapse;
  margin: 0.75rem 0;
  font-size: 0.85rem;
}

section th, section td {
  border: 1px solid rgba(255, 255, 255, 0.12);
  padding: 0.4rem 0.6rem;
  text-align: left;
}

section th {
  background: rgba(255, 255, 255, 0.06);
  font-weight: 600;
}

/* \u5F15\u7528\u5757 */
section blockquote {
  margin: 0.5rem 0;
  padding: 0.5rem 0.75rem;
  border-left: 3px solid rgba(255, 255, 255, 0.2);
  font-style: italic;
  color: rgba(255, 255, 255, 0.8);
}

/* Callout */
section .callout {
  margin: 0.5rem 0;
  padding: 0.5rem 0.75rem;
  border-radius: 6px;
  border-left: 3px solid;
  background: rgba(255, 255, 255, 0.04);
}

section .callout-title {
  font-weight: 700;
  font-size: 0.85rem;
  margin-bottom: 0.25rem;
}

section .callout-note { border-left-color: #3b82f6; }
section .callout-note > .callout-title { color: #3b82f6; }
section .callout-tip { border-left-color: #22c55e; }
section .callout-tip > .callout-title { color: #22c55e; }
section .callout-warning { border-left-color: #f59e0b; }
section .callout-warning > .callout-title { color: #f59e0b; }
section .callout-danger { border-left-color: #ef4444; }
section .callout-danger > .callout-title { color: #ef4444; }

/* \u56FE\u7247 */
section img {
  max-width: 100%;
  max-height: 260px;
  height: auto;
  display: block;
  border-radius: 6px;
  margin: 0.5rem auto;
  object-fit: contain;
}

/* \u6C34\u5E73\u7EBF */
section hr {
  border: none;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  margin: 1.5rem 0;
}

/* \u4EFB\u52A1\u5217\u8868 */
section .task-list {
  list-style: none;
  margin-left: 0;
  padding-left: 0;
}

section .task-list-item {
  display: flex;
  align-items: flex-start;
  gap: 0.4rem;
  margin-bottom: 0.25rem;
  font-size: 0.85rem;
}

section .task-list-item input[type="checkbox"] {
  margin-top: 0.15rem;
  accent-color: #60a5fa;
}

/* \u6570\u5B66\u516C\u5F0F */
section .math-block {
  background: rgba(0, 0, 0, 0.15);
  padding: 0.5rem 0.75rem;
  border-radius: 6px;
  overflow-x: auto;
  text-align: center;
  margin: 0.5rem 0;
}
`,t=`${this.manifest.dir}/css`;if((yield this.app.vault.adapter.exists(t))||(yield this.app.vault.adapter.mkdir(t)),!(yield this.app.vault.adapter.list(t).catch(()=>({files:[],folders:[]}))).files.some(T=>T.endsWith(".css"))){let T=`${t}/default.css`;yield this.app.vault.adapter.write(T,e),new y.Notice("\u5DF2\u521B\u5EFA\u9ED8\u8BA4 CSS \u9884\u8BBE: default.css")}let r=new y.Modal(this.app);r.setTitle("\u81EA\u5B9A\u4E49 CSS"),r.modalEl.addClass("lumislate-css-modal");let l=r.contentEl.createEl("div",{cls:"lumislate-css-editor"}),c=l.createEl("div",{cls:"lumislate-css-left"}),d=c.createEl("div",{cls:"lumislate-css-left-header"});d.createEl("span",{text:"\u9009\u62E9\u9884\u8BBE",cls:"lumislate-css-left-title"});let u=d.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost lumislate-btn-small"});(0,y.setIcon)(u,"file-plus"),u.appendText(" \u65B0\u5EFA");let g=c.createEl("div",{cls:"lumislate-css-newfile"});g.style.display="none";let m=g.createEl("input");m.type="text",m.placeholder="\u6587\u4EF6\u540D\uFF08\u4E0D\u542B\u6269\u5C55\u540D\uFF09",m.addClass("lumislate-css-newfile-input");let b=g.createEl("button",{text:"\u521B\u5EFA",cls:"lumislate-btn lumislate-btn-primary lumislate-btn-small"}),h=g.createEl("button",{text:"\u53D6\u6D88",cls:"lumislate-btn lumislate-btn-ghost lumislate-btn-small"}),p=c.createEl("div",{cls:"lumislate-css-file-list"}),f=l.createEl("div",{cls:"lumislate-css-center"}),w=f.createEl("div",{cls:"lumislate-css-path"});w.textContent=t;let v=new y.TextAreaComponent(f).setPlaceholder("/* \u9009\u62E9\u5DE6\u4FA7\u9884\u8BBE\u6216\u65B0\u5EFA CSS \u6587\u4EF6 */").setValue("");v.inputEl.addClass("lumislate-css-textarea");let S=f.createEl("div",{cls:"lumislate-css-right-actions"}),C=S.createEl("button",{cls:"lumislate-btn lumislate-btn-danger lumislate-btn-small"});(0,y.setIcon)(C,"trash-2"),C.appendText(" \u5220\u9664");let E=S.createEl("button",{cls:"lumislate-btn lumislate-btn-primary lumislate-btn-small"});(0,y.setIcon)(E,"save"),E.appendText(" \u4FDD\u5B58");let N=S.createEl("button",{cls:"lumislate-btn lumislate-btn-ghost lumislate-btn-small"});(0,y.setIcon)(N,"check"),N.appendText(" \u5E94\u7528\u5230\u7B14\u8BB0");let H=l.createEl("div",{cls:"lumislate-css-right"}),q=H.createEl("div",{cls:"lumislate-css-ai-header"});q.createEl("span",{text:"AI \u52A9\u624B",cls:"lumislate-css-ai-title"});let A=q.createEl("span",{cls:"lumislate-css-ai-status"}),P=H.createEl("div",{cls:"lumislate-css-ai-chat"}),z=P.createEl("div",{cls:"lumislate-css-ai-msg lumislate-css-ai-msg-ai"});z.createEl("div",{cls:"lumislate-css-ai-msg-role",text:"AI"}),z.createEl("div",{cls:"lumislate-css-ai-msg-content",text:"\u4F60\u597D\uFF01\u6211\u53EF\u4EE5\u5E2E\u4F60\u8C03\u6574 CSS \u6837\u5F0F\u3002\u63CF\u8FF0\u4F60\u60F3\u8981\u7684\u89C6\u89C9\u6548\u679C\uFF0C\u6211\u4F1A\u751F\u6210\u5408\u9002\u7684 CSS \u4EE3\u7801\u3002"});let O=H.createEl("div",{cls:"lumislate-css-ai-input-wrap"}),R=O.createEl("textarea",{cls:"lumislate-css-ai-input"});R.placeholder="\u63CF\u8FF0\u4F60\u60F3\u8981\u7684\u6837\u5F0F\uFF0C\u4F8B\u5982\uFF1A\u628A\u80CC\u666F\u6539\u6210\u6D45\u8272\u6E10\u53D8\uFF0C\u6807\u9898\u7528\u6DF1\u84DD\u8272\u2026",R.rows=2;let W=O.createEl("button",{cls:"lumislate-btn lumislate-btn-primary lumislate-btn-small"});(0,y.setIcon)(W,"send"),W.style.marginTop="6px",W.style.alignSelf="flex-end";let ne=()=>{let T=R.value.trim();T&&(this.sendAiCssAssist(T,v.getValue(),P,v,A),R.value="")};W.addEventListener("click",ne),R.addEventListener("keydown",T=>{T.key==="Enter"&&!T.shiftKey&&(T.preventDefault(),ne())});let we=[],B=null,j=!1,Y=T=>`${t}/${T}`,nt=(T,I)=>{p.querySelectorAll(".lumislate-css-rename-input").forEach(V=>V.remove()),T.empty(),T.addClass("active");let $=T.createEl("input",{cls:"lumislate-css-rename-input",value:I});$.focus(),$.select();let _=()=>x(this,null,function*(){let V=$.value.trim();if($.remove(),!V||V===I){J();return}let te=V.endsWith(".css")?V:`${V}.css`;if(te===I){J();return}let le=Y(I),ae=Y(te);if(yield this.app.vault.adapter.exists(ae)){new y.Notice("\u8BE5\u6587\u4EF6\u540D\u5DF2\u5B58\u5728"),J();return}let oi=yield this.app.vault.adapter.read(le).catch(()=>"");yield this.app.vault.adapter.write(ae,oi),yield this.app.vault.adapter.remove(le),B===I&&(B=te),new y.Notice(`\u5DF2\u91CD\u547D\u540D\u4E3A ${te}`),yield J()});$.addEventListener("keydown",V=>{V.key==="Enter"&&(V.preventDefault(),_()),V.key==="Escape"&&(T.empty(),T.setText(I))}),$.addEventListener("blur",()=>_())},ai=(T,I,$)=>{document.querySelectorAll(".lumislate-context-menu").forEach(ae=>ae.remove());let _=document.createElement("div");_.addClass("lumislate-context-menu"),_.style.left=`${T.pageX}px`,_.style.top=`${T.pageY}px`;let V=_.createEl("div",{cls:"lumislate-context-menu-item",text:"\u91CD\u547D\u540D"});(0,y.setIcon)(V.createSpan(),"pencil"),V.addEventListener("click",()=>{_.remove(),nt($,I)});let te=_.createEl("div",{cls:"lumislate-context-menu-item danger",text:"\u5220\u9664"});(0,y.setIcon)(te.createSpan(),"trash-2"),te.addEventListener("click",()=>x(this,null,function*(){_.remove(),confirm(`\u786E\u5B9A\u8981\u5220\u9664 ${I} \u5417\uFF1F`)&&(yield this.app.vault.adapter.remove(Y(I)),B===I&&(B=null,j=!1,v.setValue("")),yield J(),new y.Notice("\u5DF2\u5220\u9664"))})),document.body.appendChild(_);let le=ae=>{_.contains(ae.target)||(_.remove(),document.removeEventListener("click",le))};setTimeout(()=>document.addEventListener("click",le),0)},J=()=>x(this,null,function*(){p.empty();try{we=(yield this.app.vault.adapter.list(t)).files.filter(I=>I.endsWith(".css")).map(I=>I.split("/").pop()||I).sort()}catch(T){we=[]}if(we.length===0){p.createEl("div",{text:"\u6682\u65E0 CSS \u9884\u8BBE",cls:"lumislate-css-file-item lumislate-css-file-empty"});return}for(let T of we){let I=p.createEl("div",{text:T,cls:"lumislate-css-file-item"});T===B&&I.addClass("active"),I.addEventListener("click",()=>x(this,null,function*(){if(j){g.style.display="none",new y.Notice("\u8BF7\u5148\u4FDD\u5B58\u5F53\u524D\u4FEE\u6539");return}B=T,j=!1;let $=yield this.app.vault.adapter.read(Y(T)).catch(()=>"");v.setValue($),J()})),I.addEventListener("dblclick",$=>{if($.stopPropagation(),j){new y.Notice("\u8BF7\u5148\u4FDD\u5B58\u5F53\u524D\u4FEE\u6539");return}nt(I,T)}),I.addEventListener("contextmenu",$=>{if($.preventDefault(),$.stopPropagation(),j){new y.Notice("\u8BF7\u5148\u4FDD\u5B58\u5F53\u524D\u4FEE\u6539");return}ai($,T,I)})}});u.addEventListener("click",()=>{if(j){new y.Notice("\u8BF7\u5148\u4FDD\u5B58\u5F53\u524D\u4FEE\u6539");return}g.style.display="flex",m.value="",m.focus()}),h.addEventListener("click",()=>{g.style.display="none"});let at=()=>x(this,null,function*(){let T=m.value.trim();if(!T)return;let I=T.endsWith(".css")?T:`${T}.css`,$=Y(I);if(yield this.app.vault.adapter.exists($)){new y.Notice("\u8BE5\u6587\u4EF6\u5DF2\u5B58\u5728");return}yield this.app.vault.adapter.write($,`/* \u65B0\u9884\u8BBE */
`),B=I,j=!1,v.setValue(`/* \u65B0\u9884\u8BBE */
`),g.style.display="none",yield J(),new y.Notice(`\u5DF2\u521B\u5EFA ${I}`)});if(m.addEventListener("keydown",T=>{T.key==="Enter"&&(T.preventDefault(),at()),T.key==="Escape"&&(g.style.display="none")}),b.addEventListener("click",at),E.addEventListener("click",()=>x(this,null,function*(){if(!B){new y.Notice("\u8BF7\u5148\u9009\u62E9\u6216\u65B0\u5EFA\u4E00\u4E2A\u9884\u8BBE");return}yield this.app.vault.adapter.write(Y(B),v.getValue()),j=!1,new y.Notice(`\u5DF2\u4FDD\u5B58 ${B}`)})),C.addEventListener("click",()=>x(this,null,function*(){if(!B){new y.Notice("\u8BF7\u5148\u9009\u62E9\u4E00\u4E2A\u9884\u8BBE");return}confirm(`\u786E\u5B9A\u8981\u5220\u9664 ${B} \u5417\uFF1F`)&&(yield this.app.vault.adapter.remove(Y(B)),B=null,j=!1,v.setValue(""),yield J(),new y.Notice("\u5DF2\u5220\u9664"))})),N.addEventListener("click",()=>x(this,null,function*(){if(!B){new y.Notice("\u8BF7\u5148\u9009\u62E9\u4E00\u4E2A\u9884\u8BBE");return}yield this.updateCustomFrontmatterField("lumislate_css",B),new y.Notice(`\u5DF2\u5E94\u7528 CSS \u9884\u8BBE: ${B}`),yield this.renderCurrentNote()})),v.onChange(()=>{j=!0}),yield J(),B){let T=yield this.app.vault.adapter.read(Y(B)).catch(()=>"");v.setValue(T)}let ot=r.close.bind(r);r.close=()=>{if(j&&confirm(`CSS \u4EE3\u7801\u672A\u4FDD\u5B58\uFF0C\u662F\u5426\u4FDD\u5B58\u540E\u518D\u5173\u95ED\uFF1F

\u3010\u786E\u5B9A\u3011\u4FDD\u5B58\u5E76\u5173\u95ED
\u3010\u53D6\u6D88\u3011\u76F4\u63A5\u5173\u95ED\uFF08\u4E0D\u4FDD\u5B58\uFF09`)&&B){this.app.vault.adapter.write(Y(B),v.getValue()).then(()=>{j=!1,new y.Notice(`\u5DF2\u4FDD\u5B58 ${B}`),ot()}).catch(()=>{new y.Notice("\u4FDD\u5B58\u5931\u8D25")});return}ot()},r.open()})}aiDesignCustomCss(e,t){return x(this,null,function*(){var u;let n=this.resolveAIProvider();if(n.provider==="http"&&!this.settings.apiKey){new y.Notice("\u672A\u914D\u7F6E AI\uFF1A\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u9009\u62E9\u672C\u5730 Agent \u6216\u914D\u7F6E HTTP API Key");return}let o=yield this.app.vault.read(e),{body:s}=F(o),l=`\u4F60\u662F\u4E13\u4E1A\u7684 CSS \u8BBE\u8BA1\u5E08\u3002\u8BF7\u4E3A\u4EE5\u4E0B \u81EA\u5B9A\u4E49\u6A21\u5F0F\u5185\u5BB9\u8BBE\u8BA1\u4E00\u5957\u7CBE\u7F8E\u7684 CSS \u6837\u5F0F\u3002

\u8981\u6C42\uFF1A
- \u53EA\u8F93\u51FA\u7EAF CSS \u4EE3\u7801\uFF0C\u4E0D\u8981\u4EFB\u4F55\u89E3\u91CA\u6027\u6587\u5B57
- \u4F7F\u7528 section \u9009\u62E9\u5668\u8BBE\u7F6E\u5E7B\u706F\u7247\u6837\u5F0F
- \u8003\u8651\u5185\u5BB9\u7C7B\u578B\u9009\u62E9\u5408\u9002\u914D\u8272\uFF08\u6DF1\u8272/\u6D45\u8272/\u6E10\u53D8\uFF09
- \u5305\u542B\u5B57\u4F53\u3001\u95F4\u8DDD\u3001\u6295\u5F71\u7B49\u7EC6\u8282

\u5E7B\u706F\u7247\u5185\u5BB9\u6458\u8981\uFF1A
${s.slice(0,2e3)}

\u8BF7\u8F93\u51FA CSS\uFF1A`;new y.Notice("AI \u6B63\u5728\u8BBE\u8BA1 CSS \u6837\u5F0F\u2026");let c="",d=new AbortController;this.aiAbortCtl=d;try{yield Ae(l,{provider:n.provider,agentId:n.agentId,binOverride:this.settings.localAgentBinOverride,llmConfig:{apiKey:this.settings.apiKey,baseURL:this.settings.apiBaseUrl,model:this.settings.model},model:n.provider==="local"?void 0:this.settings.model,signal:d.signal},{onDelta:g=>{c+=g},onHtml:g=>{c=g},onMeta:()=>{},onStderr:()=>{},onError:g=>{new y.Notice(`AI \u8BBE\u8BA1\u5931\u8D25: ${g}`)},onDone:()=>{this.aiAbortCtl=null;let g=c,m=g.match(/```(?:css)?\s*([\s\S]*?)```/);m&&(g=m[1].trim()),g?(t.setValue(g),new y.Notice("AI CSS \u8BBE\u8BA1\u5B8C\u6210\uFF0C\u5DF2\u586B\u5165\u7F16\u8F91\u533A")):new y.Notice("AI \u672A\u80FD\u751F\u6210\u6709\u6548 CSS\uFF0C\u8BF7\u91CD\u8BD5")}})}catch(g){this.aiAbortCtl=null,new y.Notice(`AI \u8BBE\u8BA1\u5931\u8D25: ${String((u=g==null?void 0:g.message)!=null?u:g)}`)}})}updateCustomFrontmatterField(e,t){return x(this,null,function*(){let n=this.app.workspace.getActiveFile();if(!n)return;let o=yield this.app.vault.read(n),{frontmatter:s,body:r}=F(o),l;if(s){let d=new RegExp(`^${e}:\\s*.*$`,"m");d.test(s)?l=s.replace(d,`${e}: ${t}`):l=s+`
${e}: ${t}`}else l=`${e}: ${t}`;let c=`---
${l.trim()}
---

${r}`;yield this.app.vault.modify(n,c),new y.Notice(`\u5DF2\u66F4\u65B0 ${e}: ${t}`)})}cancelAiRender(){this.aiCancelled=!0,this.aiAbortCtl&&(this.aiAbortCtl.abort(),this.aiAbortCtl=null);let e=this.getLumiSlateView();e&&(e.setRenderingState(!1),e.setStatus("\u5DF2\u53D6\u6D88"),e.hideMetrics()),this.stopMetricsTimer()}startMetricsTimer(){this.stopMetricsTimer(),this.metricsTimer=window.setInterval(()=>{this.updateMetricsDisplay()},250)}stopMetricsTimer(){this.metricsTimer!==null&&(clearInterval(this.metricsTimer),this.metricsTimer=null)}updateMetricsDisplay(){let e=this.getLumiSlateView();e&&this.currentRunStats&&e.updateMetrics(this.currentRunStats)}getSlideIndexAtCursor(){let e=this.app.workspace.getActiveViewOfType(y.MarkdownView);if(!e)return 0;let t=e.editor,n=t.getCursor(),o=t.getValue(),{frontmatter:s,body:r}=F(o),l=s?o.indexOf(r):0,c=t.posToOffset(n),u=o.slice(l,c).match(/^---\s*$/gm);return u?u.length:0}syncCursorToSlide(){let e=this.getLumiSlateView();if(!e||e.getMode()!=="custom")return;let t=this.getSlideIndexAtCursor();if(t>=0){e.scrollToSlide(t),e.setCurrentSlideIndex(t);let n=this.app.workspace.getActiveFile();if(n){let o=this.getSlideLayout(n.path,t);e.setLayoutSelectValue(o)}}}setupReverseMapping(){this.reverseMappingHandler=e=>{var t,n,o,s,r,l,c;if(((t=e.data)==null?void 0:t.type)==="lumislate-text-change"){let d=this.getLumiSlateView();if(!d||e.source!==d.getIframeWindow())return;new y.Notice("HTML \u5185\u6587\u5B57\u5DF2\u4FEE\u6539\uFF08\u4E0D\u4F1A\u540C\u6B65\u56DE Markdown \u6E90\u7801\uFF09");return}if(((n=e.data)==null?void 0:n.type)==="lumislate-skill-select"){let d=(o=e.data)==null?void 0:o.skillId,u=this.getLumiSlateView();if(!u||e.source!==u.getIframeWindow())return;this.handleSkillSelect(d);return}if(((s=e.data)==null?void 0:s.type)==="lumislate-select-mode"){let d=(r=e.data)==null?void 0:r.mode;(d==="custom"||d==="design")&&this.handleWelcomeModeSelect(d);return}if(((l=e.data)==null?void 0:l.type)==="lumislate-open-settings"){this.openSettingsTab();return}if(((c=e.data)==null?void 0:c.type)==="lumislate-slide-click"){let d=this.getLumiSlateView();if(!d||e.source!==d.getIframeWindow())return;let u=e.data.index;d.setCurrentSlideIndex(u);let g=this.app.workspace.getActiveFile();if(g){let m=this.getSlideLayout(g.path,u);d.setLayoutSelectValue(m)}return}},window.addEventListener("message",this.reverseMappingHandler)}openSettingsTab(){this.app.setting.open(),this.app.setting.openTabById(this.manifest.id)}isAiConfigured(){let e=this.resolveAIProvider();return e.provider==="local"?!!e.agentId:!!this.settings.apiKey}handleWelcomeModeSelect(e){return x(this,null,function*(){let t=this.getLumiSlateView();t&&(this.settings.defaultMode=e,yield this.saveSettings(),t.setHomePage(!1),t.setMode(e),yield this.refreshViewContext(),e==="custom"&&(yield this.renderCurrentNote()),e==="design"&&(this.isAiConfigured()?t.renderCanvas(Re(G,this.settings.defaultSkill)):t.renderCanvas(ia())))})}handleSkillSelect(e){let t=Pe(e);if(!t)return;if(!this.isAiConfigured()){new y.Notice("\u5F53\u524D\u65E0\u53EF\u7528AI\uFF0C\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u914D\u7F6E\u672C\u5730 Agent \u6216 HTTP API");return}let n=this.getLumiSlateView();n&&(n.setSelectedSkill(e),this.saveSettings()),new Fe(this.app,t,()=>{this.aiRenderCurrentNote()},()=>{}).open()}applyTextChange(e){var b;let t=this.app.workspace.getActiveViewOfType(y.MarkdownView);if(!t){new y.Notice("\u672A\u627E\u5230 Markdown \u7F16\u8F91\u5668");return}let n=t.editor,o=n.getValue(),s=e.oldText,r=e.newText,l=[],c=0;for(;(c=o.indexOf(s,c))!==-1;)l.push(c),c+=s.length;if(l.length===0){new y.Notice("\u672A\u80FD\u5728\u6E90\u7801\u4E2D\u627E\u5230\u8BE5\u6587\u672C\uFF0C\u53EF\u80FD\u5DF2\u88AB\u4FEE\u6539");return}let d;l.length===1?d=l[0]:e.context?(d=this.findBestMatchByContext(o,l,s,e.context),d===-1&&(d=l[0])):d=l[0];let u=n.offsetToPos(d),g=n.offsetToPos(d+s.length);n.replaceRange(r,u,g);let m=(b=t.file)==null?void 0:b.path;if(m){let h=n.getValue(),{frontmatter:p}=F(h),f=D(p,"lumislate_prompt");this.cacheManager.updateCacheText(m,s,r,h,f)}new y.Notice("\u5DF2\u540C\u6B65\u56DE Markdown \u6E90\u7801")}findBestMatchByContext(e,t,n,o){let s=-1,r=-1;for(let l of t){let c=Math.max(0,l-40),d=Math.min(e.length,l+n.length+40),u=e.slice(c,d),g=0;for(let m=0;m<Math.min(o.length,u.length);m++)o[m]===u[m]&&g++;g>r&&(r=g,s=l)}return s}clearCurrentNoteCache(){return x(this,null,function*(){let e=this.app.workspace.getActiveFile();e?(yield this.cacheManager.clearCache(e.path),new y.Notice(`\u5DF2\u6E05\u9664\u7F13\u5B58: ${e.name}`)):new y.Notice("\u672A\u627E\u5230\u5F53\u524D\u7B14\u8BB0")})}handleClearLayout(){return x(this,null,function*(){let e=this.app.workspace.getActiveFile();if(!e||e.extension!=="md"){new y.Notice("\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A Markdown \u7B14\u8BB0");return}let t=this.getLumiSlateView();if(!t)return;let n=yield this.app.vault.read(e),{frontmatter:o}=F(n),s=D(o,"lumislate_prompt");!(yield this.cacheManager.readCache(e.path,n,s))&&this.aiAccumulated&&confirm("\u5F53\u524D\u6392\u7248\u5C1A\u672A\u4FDD\u5B58\uFF0C\u662F\u5426\u5BFC\u51FA\u4E3A HTML \u540E\u518D\u6E05\u9664\uFF1F")&&this.exportHtmlDownload(),yield this.cacheManager.clearCache(e.path),this.aiAccumulated="",t.setHasAccumulated(!1),t.renderCanvas(Re(G,this.settings.defaultSkill)),t.setExportEnabled(!1),t.setContextInfo(e.basename,!1,!1,!1),new y.Notice("\u5DF2\u6E05\u9664\u6392\u7248")})}};0&&(module.exports={LUMISLATE_VIEW_TYPE,LumiSlateView,SLIDE_LAYOUTS});
